<?

$promissary_note = " 

<style>
<!--
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
p.MsoBodyText
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:12.0pt;
	margin-left:0in;
	line-height:150%;
	font-size:10.0pt;
	font-family:\"Times New Roman\";}
H6{page-break-after : always ; }	
-->
</style>
<meta name=\"Microsoft Border\" content=\"r, default\">

<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td valign=\"top\">
<p><h3>Promissory Note</h3></p>
<p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">
<span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoBodyText\" style=\"margin-bottom:0in;margin-bottom:.0001pt;line-height:
normal\"><span style=\"font-family:Arial\">I, __<u>$f_name $l_name</u>__, hereby 
enroll in The American Hypnosis Clinic Affiliate hypnotherapy program.&nbsp; I agree 
to pay The American Hypnosis Clinic exactly __<u>\$$amount_to_charge</u>__ for the initial deposit and 
__<u>\$$equal_payments_of</u>__ a month for __<u>$number_of_payments</u>__ months according to the schedule below with my first monthly installment being due at the time of service.&nbsp; I authorize The 
American Hypnosis Clinic to deduct the funds from my credit or debit card 
according to the schedule below.&nbsp; I agree to and am bound by all terms and 
conditions in The American Hypnosis Clinic document �Lifetime Commitment 
Guarantee &amp; Client Contract.�&nbsp; I understand that if I wish to pay with a money 
order, I must pay the entire remaining balance at the time of my appointment, 
and it must be made out to The American Hypnosis Clinic.&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\" align=\"right\" style=\"text-align:right\">
<span style=\"font-size: 10.0pt; font-family: Arial\">
______<u>ON FILE</u>_______________&nbsp;&nbsp;&nbsp; ______________</span></p>
<p class=\"MsoNormal\" align=\"right\" style=\"text-align:right\">
<span style=\"font-size: 10.0pt; font-family: Arial\">
Signature&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date</span></p>
";

// Beginning of payment schedule display:

$affiliate_deposit_amount = $amount_to_charge*.6;
$promissary_note .= "<h4>Schedule of Payment:<br></h4>
INITIAL DEPOSIT = \$$amount_to_charge _________ -- Pay Affiliate \$$affiliate_deposit_amount ________
<br><br>
<table>
<tr>
	<td  valign=\"middle\" style=\" height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Payment</span></b>
	</td>
		
	<td valign=\"bottom\" style=\" height: 15.4pt; border: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Date</span></b>
	</td>
	
			<td  valign=\"middle\" style=\"\ height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Balance Owed 
			</span></b>
	</td>
					
	<td  valign=\"middle\" style=\" height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Client Pays</span></b>
	</td>	
	
	<td  valign=\"middle\" style=\" height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Date Charged</span></b>
	</td>	

	<td valign=\"middle\" style=\"height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Pay Affiliate 
			</span></b>
	</td>
		
	<td  valign=\"middle\" style=\"\ height: 15.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
			<p class=\"MsoNormal\" align=\"center\" style=\"margin-bottom:6.0pt;text-align:center\">
			<b><span style=\"font-size: 10.0pt; font-family: Arial\">Date Paid 
			</span></b>
	</td>
	


</tr>";

//CREATE A LOOP THAT DISPLAYS THE PAYMENT SCHEDULE HERE

$i=0;
$payment_month=$apt_month;
$payment_year=$apt_year;

$balance_due = ($total_program_cost-$amount_to_charge)*1.19;
  
for ($i = 0; $i < $number_of_payments; $i++)
{
  $payment_number=$i+1;

 $affiliate_payment_amount = (($total_program_cost-$amount_to_charge)/$number_of_payments)*.6;
	

  if ($payment_month == 13){
    $payment_month=1;
    $payment_year++;
}
  $promissary_note .= 
  "<tr>
	  <td align = \"center\">#$payment_number</td>
	  <td>$payment_month/$apt_day/$payment_year </td>
	  <td align = \"right\">\$$balance_due  </td>
	  <td align = \"right\">\$$equal_payments_of</td>
	  <td>__________</td>
	  <td align = \"right\">\$$affiliate_payment_amount</td>
	  <td>__________</td>
  </tr>";
  
  $balance_due = $balance_due - $equal_payments_of;
 
 $payment_month++; 
}//End for loop

$promissary_note .= "</table>";

$promissary_note .= "
</td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>
<br><br>
Address:&nbsp; </span><b>
<span style=\"font-family:Arial\">_________________________________________________________________</span></b></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt\">Phone&nbsp;&nbsp; <b>
<span style=\"font-family:Arial\">______________________</span></b></p>
<p class=\"MsoBodyText\"><span style=\"font-family:Arial\">Type of payment&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><b><span style=\"font-size:
12.0pt;line-height:150%;font-family:Arial\">__<u>$cc_type</u>__</span></b></p>
<p class=\"MsoBodyText\"><span style=\"font-family:Arial\">Routing #/Account #/Check #</span><b>
<span style=\"font-size:12.0pt;line-height:150%;font-family:Arial\">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></b><span style=\"font-family:Arial\">__<u>$ck_routing_number</u>__&nbsp;/__<u>$ck_account_number</u>__&nbsp;/__<u>$ck_number</u>__ </span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt\">
<span style=\"font-size: 10.0pt; font-family: Arial\">Credit card 
number/Exp. Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span style=\"font-family:Arial\">__<u>$cc_number</u>__&nbsp;&nbsp; __<u>$cc_expiration_month</u>__/__<u>$cc_expiration_year</u>__ </span></b></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt\">
<span style=\"font-size: 10.0pt; font-family: Arial\">Therapist&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><b><span style=\"font-family:Arial\">__<u>$affil_f_name $affil_l_name</u>__&nbsp;

<h6></h6>";


?>