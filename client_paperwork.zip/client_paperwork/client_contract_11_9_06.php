<?

$client_contract = "


<font size=3 color=\"red\">This Document must be completed and signed for return to the American Hypnosis Clinic by your therapist.</font><br><BR>
<font size = 3 color = \"black\"><b>Lifetime Commitment Guarantee &amp; Client Contract</strong></b><br>
<font size=2>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I, $f_name $l_name, understand that The American Hypnosis Clinic, inc. (hereafter referred to as AHC) uses different types of hypnosis, waking and somnambulistic, that are customized to each client.&nbsp; I agree to be hypnotized so my AHC-assigned hypnotist can help me set specific goals and giving me suggestions to achieve them and overcome personal challenges I have chosen to work on in a self-hypnotic state.  Suggestion is the artful use of imagination within a self-hypnotic state to increase enthusiasm for self improvement and making good decisions using self-help techniques.&nbsp; Self-help techniques are thinking strategies used by normally-functioning people to remind themselves of improvements they wish to make in their lives. Hypnotists use suggestion while the client is in the self-hypnotic state to teach such strategies.&nbsp;<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand AHC offers a <u>lifetime</u> support guarantee. If more than one session is needed AHC will provide additional help <u>at no additional charge for life</u>.  AHC care-giving options may include education in self-hypnosis, NLP, stress reduction, biofeedback, practical lifestyle planning, audio recordings and/or long-distance therapy.  I understand and agree to any recording that may be deemed necessary at AHC and the reviewing of my personal information with other therapists and staff for cross-consultation, record-keeping or training purposes.  I also understand that to succeed I will have to accept the responsibility of doing my part.&nbsp; Hypnosis is a participatory therapy and cannot succeed without my full commitment and cooperation.  I agree to follow all suggestions given by my therapist, including keeping appointments, mental exercises and lifestyle advice.&nbsp; I understand that if I do not keep appointments and follow all instructions, AHC cannot and will not warranty their work.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The majority of AHC clients succeed in their goals quickly and with few sessions.&nbsp; However, for the occasional clients who have difficulty and need more sessions, our policies provide an incentive not to give up. Because clients pay for a program instead of session by session, it is to their advantage to utilize our support guarantee and stick with it until they completely succeed.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand that it is impossible to guarantee the behavior of another human being.  Sometimes there are psychological or medical issues involved and in those cases additional treatment should be sought.&nbsp; This is beyond the specialized service of hypnosis that AHC offers.&nbsp;  I understand that AHC does not do Psychotherapy.&nbsp; AHC does not prescribe drugs, diagnose any medical conditions or provide treatment for such conditions.&nbsp; AHC uses methods of hypnosis, visualization, guided imagery and relaxation (V68.20).&nbsp; All AHC hypnotherapists have training in thosee unique skills and methods and use those skills in order to coach, teach, guide, instruct, and train clients to help themselves.&nbsp;&nbsp;AHC therapists are subcontractors and it is their responsibility to operate within the laws of their state.  If psychotherapy or medical help is necessary then I will personally accept all responsibility of seeking such help on my own.&nbsp; This does not lessen the ability of AHC to help me in addition to outside psychological or medical care nor does it relieve me from my agreement with AHC.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AHC reserves the right to permanently refuse service at any time to clients who,in the sole  opinion of AHC staff, are belligerent or physically abusive towards any member of AHC staff or clients. AHC also reserves the right to refuse service at any time to clients who come to their appointments under the influence of alcohol or any other mind-altering drug.  I understand that the therapists time is valuable and sought after and I am paying for a program at the total cost of \$$total_display, This figure includes a $finance_rate_display% finance charge if it is being financed into more than one payment.  I am buying priviledges to enjoy a complete program and not paying a per-session fee.  &nbsp;&nbsp; Therefore I understand that AHC does not issue refunds under any circumstances.&nbsp; Once I enter into this contract, I am bound to its terms and must pay for the program in full.&nbsp; I agree to pay for the program in advance plus court costs and attorney fees if I am late in paying and AHC deems collection procedures are necessary.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AHC asks that if you have to cancel or reschedule an appointment please give us as much notice as possible.&nbsp; If your therapist has to cancel an appointment we will extend the same courtesy and it will not affect this fiscal agreement.  We reserve the right to charge a \$35 rescheduling fee for cancellations or absenteeism with less than 24 hours advance notice.&nbsp; If two or more appointments are missed without 24 hours notice or is more than 20 minutes late more than twice AHC can, at its discretion, permanently refuse services.  The above situations do not absolve client of agreed-upon debt.<br>
<br>
<strong>Promissory Note:</strong>&nbsp;&nbsp;

I, $f_name $l_name, hereby enroll in AHC Affiliate hypnotherapy program.&nbsp; I agree to pay The American Hypnosis Clinic exactly \$$total_display for the complete program.  My payment schedule consists of the \$$amount_to_charge non-refundable deposit I have already approved and $number_of_payments payment";

if ($number_of_payments > 1){
  $client_contract .= "s";
}

$client_contract .= " of \$$equal_payments_of";

if ($number_of_payments > 1){
  $client_contract .= " per month with my first installment";
}

$client_contract .= "&nbsp;being due at the first appointment.  If I choose to pay with a check or money order then I will pay for the entire program minus deposit at the first appointment directly to the AHC main office.  I agree to all terms and conditions in The AHC document \"Lifetime Commitment Guarantee &amp; Client Contract.\"&nbsp; I authorize The American Hypnosis Clinic to deduct the funds from the credit or debit card listed below according to this schedule.  If the payment schedule is not completed the balance of the program will be charged to the credit/debit card provided at time of deposit.  Initial therapist: $affil_f_name $affil_l_name.
<br><br>
<font size=\"2\"><font color=\"red\">***</font>Payment type:<u>$cc_type</u>____ Card Number:<u>$cc_number</u>_____________ Exp Date: <u>$cc_expiration_month/$cc_expiration_year</u>____
</font><br>

<br><font size=\"2\">I have read and agree to the above:</font><br>
<p class=\"MsoNormal\" align=\"right\" style=\"text-align:right\">
<span style=\"font-size: 9.0pt\">
<font color=\"red\">***</font>Signature: _________________________________&nbsp;&nbsp;Date: ____________</span></p>";


/*
//LOOP THAT DISPLAYS THE PAYMENT SCHEDULE AT THE BOTTOM OF PAGE
$client_contract .= "<font size=\"2\" color =\"gray\">For Clinic Use Only:<br><table>
<tr><td>By/Date</td>";

//first loop outputs a line and table cell for each date
$i=0;
$payment_month=$apt_month;
$payment_year=$apt_year;
  
for ($i = 0; $i < $number_of_payments; $i++){
 
 $client_contract .="<td><font size=\"2\" color =\"gray\">_________</font></td>";
  
}//end first for-loop

$client_contract .="</tr><tr><td><font size=\"2\" color =\"gray\">Due</font></td>";

//second loop outputs the date in a table cell
$i=0;
$payment_month=$apt_month;
$payment_year=$apt_year;
  
for ($i = 0; $i < $number_of_payments; $i++)
{
  $payment_number=$i+1;


  if ($payment_month == 13){
    $payment_month=1;
    $payment_year++;
}
  $client_contract .= "<td><font size=\"2\" color =\"gray\">$payment_month/$apt_day/$payment_year</font></td>";
 
 $payment_month++; 
}//End second for loop

$client_contract .="</tr><tr><td><font size=\"2\" color =\"gray\">Paid<br>Owed</font></td>";

//third loop to show what is paid and what is owed.
	$i=0;
	  
for ($i = 0; $i < $number_of_payments; $i++){

	$paid_calc= 100+(($i+1)*$equal_payments_of);
	$paid= money_format("%n", $paid_calc);
	$owes_calc=($total_display-100)-(($i+1)*$equal_payments_of);
	$owes=money_format("%n", $owes_calc);
 
 $client_contract .="<td><font size=\"2\" color =\"gray\">\$$paid<br>\$$owes</font></td>";
  
}//end third for-loop



$client_contract .="</tr></table>";

*/


?>
