<?


$smoking_letter = "<style>
<!--
H6{page-break-after : always ; }	
-->
</style>

<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td valign=\"top\">
<h3><p align=\"center\"> Individualized Smoking Cessation Program</p></h3>
<p  align=\"center\" style=\"text-align:center\">(All information provided is kept strictly Confidential)</p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Appointment:<u>$appointment_date at $appointment_time&nbsp;</u></span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Name <u>&nbsp;$f_name $l_name </u>
Birthdate ____/____/____&nbsp; Work # ________________ Home#________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Address __<u>_______________________ 
________________________ City____________________ State</u>___ Zip _<u>__________</u>__</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">DL Number _________________ 
SSN (if different) _____________________Age______ Marital 
Status______________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">
Occupation__________________________&nbsp; Company ______________________________ 
E-mail: <u>$email</u> </span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Favorite Hobbies 
____________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Purpose of today�s Visit: 
____________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">If you have or have had any 
of the following, please check:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table1\">
	<tr>
		<td width=\"184\" valign=\"top\" style=\"width:137.7pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Allergies</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Seizures</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Hearing problems</span></td>
		<td width=\"184\" valign=\"top\" style=\"width:137.7pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Asthma</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Epilepsy</span></td>
		<td width=\"184\" valign=\"top\" style=\"width:137.7pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Heart Trouble</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">High Blood Pressure</span></td>
		<td width=\"184\" valign=\"top\" style=\"width:137.7pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Depression</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other _____________</span></td>
	</tr>
</table>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Please list any drugs you may 
be taking or health problems you may be suffering from at this time: 
____________________________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Family Physician 
_________________________________________ Last visit __________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Name of Practice: 
______________________________________Phone 
Number:______________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%; font-family: new times roman\">
May we contact your physician and share information with him or her to provide 
you with the best possible results? ______________</span><u><span style=\"font-size: 10.0pt; line-height: 150%; font-family: Arial\">
</span></u></p>
<p>Habits:</p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table2\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Alcohol</span></p>
		</td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Coffee/Tea</span></p>
		</td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other 
		______________________</span></td>
	</tr>
</table>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">What negative effects has 
this behavior had on your life? </span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">
___________________________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">
____________________________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"line-height: 150%\">
____________________________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">

<h6></h6><!-- ############## NEW PAGE ##################### -->

Why have you chosen to quit 
at this time?_______________________________________________________________</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Which negative effects have 
you experienced from smoking?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: .95in\" id=\"table3\">
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Shortness of 
		breath____</span></td>
		<td width=\"204\" valign=\"top\" style=\"width:153.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Emphysema____</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Numbness in 
		extremities____</span></td>
	</tr>
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Coughing____</span></td>
		<td width=\"204\" valign=\"top\" style=\"width:153.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Congestion____</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Hacking/wheezing____</span></td>
	</tr>
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Lack of energy____</span></td>
		<td width=\"204\" valign=\"top\" style=\"width:153.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Circulation 
		problems____</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Other____</span></td>
	</tr>
</table>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Which other factors are 
motivating you to quit?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: .95in\" id=\"table4\">
	<tr>
		<td width=\"228\" valign=\"top\" style=\"width:171.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p><span style=\"font-size: 10.0pt\">Shortened life 
		span____</span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Quality of life being 
		effected____</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p><span style=\"font-size: 10.0pt\">Illness____ </span>
		</td>
	</tr>
	<tr>
		<td width=\"228\" valign=\"top\" style=\"width:171.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Loss of energy____</span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">Bad breath/odor____</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p><span style=\"font-size: 10.0pt\">Because you love 
		your family____</span></td>
	</tr>
	<tr>
		<td width=\"228\" valign=\"top\" style=\"width:171.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p><span style=\"font-size: 10.0pt\">Society moving away 
		from <br>
		smoking ____</span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">
		Other________________________________</span></td>
		<td width=\"199\" valign=\"top\" style=\"width:149.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></td>
	</tr>
</table>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">How long have you been 
smoking? _________ How much do you smoke? ____________ per day</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">How and why did you start 
smoking? ___________________________________________________________________</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Does anyone else in your home 
smoke? ________ Do people smoke around you at work? _________________</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Do you smoke while drinking 
alcohol? _________ Do you smoke while drinking coffee? __________</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">When/where/why do you smoke?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: .95in\" id=\"table5\">
	<tr>
		<td width=\"154\" valign=\"top\" style=\"width:1.6in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">At work____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">On the phone____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">When you wake up in 
		the morning____</span></td>
	</tr>
	<tr>
		<td width=\"154\" valign=\"top\" style=\"width:1.6in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">While you relax____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">While driving____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">While watching TV____</span></td>
	</tr>
	<tr>
		<td width=\"154\" valign=\"top\" style=\"width:1.6in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">After meals____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">In times of 
		stress____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">When you are 
		nervous____</span></td>
	</tr>
	<tr>
		<td width=\"154\" valign=\"top\" style=\"width:1.6in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">When you are 
		bored____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">For something to do 
		with your hands____</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"line-height:150%\">
		<span style=\"font-size: 10.0pt; line-height: 150%\">For something to put 
		in your mouth____</span></td>
	</tr>
</table>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p style=\"line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">What do you like about 
smoking? ______________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">What do you dislike about 
smoking? ___________________________________________________________________</span></p>
<p ><span style=\"font-size: 10.0pt\">How will you feel once you 
have accomplished your goal?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table6\">
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Proud of yourself </span>
		</p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relieved </span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Happy </span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">A good example</span></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Healthy </span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: \">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Accomplished something 
		important&nbsp; </span></td>
	</tr>
</table>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Please mention any other 
concern or question that you may have 
_______________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">
____________________________________________________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">

<p>I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional.  I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.&nbsp;&nbsp; I am accepting sole responsibility to communicate with such professionals independently, share relevent information with my therapist or go ahead with the program without involving other health care professionals as I see fit. </p>


<p>I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</p>
<p>(Patient Signature)&nbsp;_________________________________________</p>

<br><p><span style=\"font-size: 10.0pt\">(Patient Signature)&nbsp; 
_________________________________________</span></p>
<p><b><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>
<p align=\"center\" style=\"text-align:center\"><b>
<span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>
<p align=\"center\" style=\"text-align:center\"><b>
<span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>
<p align=\"center\" style=\"text-align:center\"><b>
<span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>

</td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr></table>";


?>


