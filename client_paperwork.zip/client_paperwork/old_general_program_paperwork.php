<?
$general_program_letter="<p><h3>Individualized $program_title[$program_index]&nbsp;Program</h3>(All information provided is kept strictly Confidential)</p>
<br>
<p>Appointment: <u>$appointment_date at $appointment_time</u></p>
<br>
<p>Name:&nbsp; <u>$f_name $l_name</u>&nbsp;Birthdate ____/____/____&nbsp; Work # ________________ Home#________________</p>
<p>Address _________________________________________________ City____________________ State___ Zip _____________</p>
<p>SSN _________________________ Age______ Marital Status______________________</p>
<p>Occupation__________________________&nbsp;Company ______________________________ E-mail: <u>$email</u></p>
<p>Favorite Hobbies____________________________________________________________________________________________</p>
<p>Your goals for today�s Visit: ____________________________________________________________________________________</p>
<p>If you have or have had any of the following, please check:</p>
<table width=\"100%\">
	<tr>
		<td>
			___Allergies
		</td>
		<td>
			___Asthma
		</td>
		<td>
			___Heart Trouble
		</td>
		<td>
			___Depression
		</td>
	</tr>
	<tr>
		<td>
			___Seizures
		</td>
		<td>
			___Epilepsy
		</td>
		<td>
			___High Blood Pressure
		</td>
		<td>
			Other _____________
		</td>
	</tr>
	<tr>
		<td>
		___Hearing problems
		</td>
		
		<td></td>
		<td></td>
		<td></td>
	</tr>
</table>				
<p>Please list any drugs you may be taking or health problems you may be suffering from at this time: ____________________________________________________________________________________________________________</p>
<p>Family Physician_________________________________________ Last visit __________________________</p>
<p>Name of Practice:______________________________________Phone Number:______________________________________</p>
<p>May we contact your physician and share information with him or her to provide you with the best possible results? ______________</p>

<p>Habits:</p>
<table width=\"100%\">
	<tr>
		<td>
			___Alcohol
		</td>	
		<td>
			___Tobacco
		</td>	
		<td>
			___Coffee/Tea
		</td>						
	</tr>
	<tr>
		<td>
			___Special Diet
		</td>	
		<td>
			Other ______________________
		</td>	
		<td>
			
		</td>						
	</tr>
</table>
<p>What negative effects has this behavior had on your life? </p>
<p>___________________________________________________________________________________________________________</p>
<p>___________________________________________________________________________________________________________</p>
<p>___________________________________________________________________________________________________________</p>
<p>Are your friends and family supportive of your decision to make this change?&nbsp; Are they aware of it?</p>
<p>____________________________________________________________________________________________________________</p>
<p>When and where does this problem happen?&nbsp; <br><i>(Be specific.&nbsp; Specify the days of the week, how many times per week, time of day/evening, when you do specific other things, when certain things are said, when you go particular places, when a particular event happens, etc.)</i></p>
<p>____________________________________________________________________________________________________________</p>
<p>____________________________________________________________________________________________________________</p>
<p>____________________________________________________________________________________________________________</p>
<p>What are you worried that you will miss when you change this behavior?&nbsp; </p>
<p>____________________________________________________________________________________________________________</p>
<p>What things do you imagine that motivate you to succeed when you think about them?</p>
<p>____________________________________________________________________________________________________________</p>
<p>____________________________________________________________________________________________________________</p>
<p>____________________________________________________________________________________________________________</p>
<p>How will you feel once you have accomplished your goal?</p>
<table width=\"100%\">
	<tr>
		<td>
		___Proud of yourself
		</td>
		<td>
		___Happy 
		</td>
		<td>		
		___Healthy 
		</td>				
	</tr>
	<tr>
		<td>
		___Relieved 
		</td>
		<td>
		___A good example
		</td>
		<td>
		___Accomplished something important 
		</td>				
	</tr>	
</table>
<p>Please mention any other concern or question that you may have _____________________________________________________</p>
<p>____________________________________________________________________________________________________________</p>

<p>I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional.  I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.&nbsp;&nbsp; I am accepting sole responsibility to communicate with such professionals independently, share relevent information with my therapist or go ahead with the program without involving other health care professionals as I see fit. </p>


<p>I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</p>
<br><p>(Patient Signature)&nbsp;_________________________________________</p>

";

?>