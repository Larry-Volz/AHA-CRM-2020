<?


$smoking_letter = '
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8">
<title>Smoking</title>

<style type="text/css">
<!--
H6{page-break-after : always ; }    
-->
</style>

</head>

<body style="margin-left: 10px; ">

<table  border="0" cellpadding="0" cellspacing="0" width="680">    
<tr>
<td align="center">
<b>Individualized Smoking Cessation Program<br>
<i>(All information provided is kept strictly Confidential)</i><br /><br />
</td>
</tr>
</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td valign="top" colspan="4" align="justify">
<b>
Appointment: <u>'.$appointment_date.'</u>  at  <u>'.$appointment_time.'</u>   for <u>'.$f_name .' '.$l_name.'</u> __/__/___  SSN ______________
</b>
<br />
<br /><b>Work #</b> ________________ <b>Home#</b>________________ <b>Marital Status</b>__________________________<br />
<b>Address</b> ______________________________________ <b>City</b>_________________ <b>State</b> ___ <b>Zip</b> _________

<br /><b>Occupation</b>___________________  <b>Company</b> ________________________ <b>E-mail:</b> <u>'.$email.'</u>
<br />
</u>
<b>Favorite Hobbies</b> ___________________________________________________________________________________ 
</b><br />
</td>
</tr>
</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">    
<tr>
<td>__ Allergies</td>
<td>__ Asthma</td>
<td>__ Heart Trouble</td>
<td>__ Depression</td>
</tr>
<tr>
<td>__ Seizures</td>
<td>__ Epilepsy</td>
<td>__ High Blood Pressure</td>
<td>__ Hearing Problems</td>
</tr>

</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">    
<tr>
<td>
__ Other____________________________________________________________________
</td>
</tr>

</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td valign="top" colspan="4">

<br />
<b>Drugs or health problems</b> _________________________________________________<br />
<b>Family Physician</b> ____________________________ <b>Last visit</b> ________________________<br />
<b>Name of Practice:</b> _________________________ <b>Phone Number:</b> _______________________

<br /><b>May we share information with your physician? __Yes __No &nbsp;&nbsp;&nbsp; Habits:    </b>
</b> <br />
</td>
</tr>
</table>
  <br />
<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">
<tr>
<td>__ Alcohol</td>
<td>__ Coffe/Tea</td>
<td>__ Other _________________________ </td>
</tr>
</table>
<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">
<tr>
<td valign="top" colspan="4">

<b>What negative effects has this behavior had on your life?  </b>
<br />
________________________________________________________________________________________<br />
________________________________________________________________________________________
</td>
</tr>
</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td><b>Why have you chosen to quit at this time?</b>_________________________________________<br />
<b>Which negative effects have you experienced from smoking?</b> 
<br />

</td>
</tr>
</table>

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">


<tr>
<td>Shortness of breath____</td>
<td> Emphysema____</td>
<td>Numbness in extremities____</td>
</tr>

<tr>
<td>Coughing____ </td>
<td> Congestion____ </td>
<td>Hacking/wheezing____</td>
</tr>

<tr>
<td>Lack of energy____  </td>
<td> Circulation problems____</td>
<td>Other____</td>
</tr>

</table> 

<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td>
<b>Which other factors are motivating you to quit?    </b>
</td>
</tr>
</table>


<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">
<tr>
<td>Shortened life span____</td>
<td> Quality of life being effected____ </td>
<td>Illness____</td>
</tr>

<tr>
<td>Loss of energy____ </td>
<td> Bad breath/odor____</td>
<td>Because you love your family____ </td>
</tr>

<tr>
<td>Society moving away<br /> from 
smoking ____
 </td>
<td>Other________________________________
</td>
<td>&nbsp;</td>
</tr>

</table>  


<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td>
<b>How long have you been smoking?</b> _________<b> How much do you smoke?</b> ____________ <b>per day</b><br />

<b>How and why did you start smoking?</b> ___________________________________________________<br />

<b>Does anyone else in your home smoke?</b> ________ <b>Do people smoke around you at work?</b> _________________<br />

<b>Do you smoke while drinking alcohol?</b> _________ <b>Do you smoke while drinking coffee?</b> __________<br />

<b>When/where/why do you smoke?   </b>
</td>
</tr>
</table> 



<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">
<tr>
<td>At work____ </td>
<td> On the phone____</td>
<td>When you wake up in the morning____</td>
</tr>

<tr>
<td>While you relax____ </td>
<td> While driving____</td>
<td>While watching TV____  </td>
</tr>

<tr>
<td>After meals____ </td>
<td> In times of stress____</td>
<td>When you are nervous____</td>
</tr>


<tr>
<td>When you are bored____</td>
<td> For something to do with your hands____</td>
<td>For something to put in your mouth____ </td>
</tr>

</table>
 
<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td>
<b>What do you like about smoking?</b> _______________________________________________________________ <br />

<b>What do you dislike about smoking?</b> _____________________________________________________________<br />

<b>How will you feel once you have accomplished your goal?</b> <br />

</td>
</tr>
</table> 


<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px;" cellpadding="0" cellspacing="0" width="680">
<tr>
<td>__ Proud of yourself</td>
<td>__ Happy </td>
<td>__ Healthy</td>
</tr>

<tr>
<td>__ Relieved</td>
<td> __ A good example</td>
<td>__ Accomplished something important</td>
</tr>


</table>


<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td>
<b>Other concerns or questions: </b> ___________________________________________________________________ <br />
</td>
</tr>
</table> 

 
<table  border="0"  cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td align="justify">
<font size="1">I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional. I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.   I am accepting sole responsibility to communicate with such professionals independently, share relevent information with my therapist or go ahead with the program without involving other health care professionals as I see fit. </b><br /><br />

I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</font>
</td>
</tr>
</table> 


<table  border="0" style="font-family: Times New Roman; font-size: 14px; line-height: 30px; font-weight: bold;" cellpadding="0" cellspacing="0" width="680"> 
<tr>
<td>
<br /><br />
<b>Patient Signature:</b> _________________________________________  <b>Date:</b> ____________ <br />
<br /><br /><br />
</td>
</tr>
</table> 

</body>

</html>

';


?>