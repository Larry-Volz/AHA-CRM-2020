<?

$expect_of_hypnosis = "

<style>
<!--
h1
	{margin-top:0in;
	margin-right:0in;
	margin-bottom:12.0pt;
	margin-left:0in;
	text-align:center;
	page-break-after:avoid;
	font-size:14.0pt;
	font-family:\"Times New Roman\";
	font-weight:normal}
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
 li.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
h2
	{margin-bottom:.0001pt;
	page-break-after:avoid;
	punctuation-wrap:simple;
	text-autospace:none;
	font-size:12.0pt;
	font-family:Arial;
	display:none;
	font-weight:normal; margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>

<h1><b><font size=\"5\">What To Expect Of Hypnosis</font></b></h1>
<p class=\"MsoNormal\">&nbsp;</p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;One of two things will 
happen when you use hypnosis to help you achieve your goals:</span></p>
<ul style=\"margin-top: 0in; margin-bottom: 0in\" type=\"disc\">
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">The �Magic Wand� 
	Effect</span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">The �Snowball� Effect</span></li>
</ul>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">The �Magic Wand� Effect is 
what everyone wants from hypnosis and is the most exciting and fun effect.&nbsp; 
That�s when it�s as if your therapist simply taps you over the forehead with a 
magic wand and it�s as if you simply have changed.&nbsp; Instantly, effortlessly� 
almost magically you may be free of the urge for cigarettes or alcohol or 
perhaps you�re thinking of food differently and find it easy to eat right and 
exercise.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">That happens a lot with 
hypnosis and it ONLY happens with hypnosis.&nbsp; No other treatment modality can 
ever claim that kind of success.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">But it�s not the only kind 
of success hypnosis can have nor is it necessarily the best.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">The �Snowball� Effect is 
when you work with the hypnosis � following along with your hypnotherapists 
advice (both mental exercises and practical advice) listening to your customized 
hypnotherapy recording, etc. and begin to see subtle changes.&nbsp; Little by little 
you come to new realizations and develop new habits that grow in effect like a 
snowball rolling down the mountain.&nbsp; Like a seed that�s placed in the ground, 
sometimes you may not see an immediate result but roots are forming and branches 
are waiting to pop up out of the soil.&nbsp; And just as a tiny seed can create an 
immense tree or a snowball can grow to enormous size and with unstoppable 
momentum � so does hypnosis help you make immense and PERMANENT life changes!</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><b><span style=\"font-family:Arial\">Hypnosis is always 
quicker than any other kind of therapy</span></b><span style=\"font-family:Arial\">!
</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">But, whether it�s immediate 
and dramatic or it takes a few sessions with more gradual progress doesn�t 
matter.&nbsp; What matters is that you <b>accomplish your goal once and for all</b>!</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<h2>&nbsp;</h2>
<h2>&nbsp;</h2>
<h2>What it�s Like</h2>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Many people have a very 
wrong idea of what hypnosis is supposed to feel like based on what they�ve seen 
on television and the movies.&nbsp; Light hypnosis is a state that we all experience 
to some degree every day such as:<br>
<br>
&nbsp;</span></p>
<ul style=\"margin-top: 0in; margin-bottom: 0in\" type=\"disc\">
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">When you�re driving 
	and you get so caught up in your imaginings that you miss your exit � that�s 
	a kind of hypnosis. </span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">When you are so 
	involved in a movie that you actually imagine yourself in the character�s 
	shoes and physically jump when something startling happens to that character 
	� that�s also a type of trance.</span></li>
</ul>

<h6></h6>

<ul style=\"margin-top: 0in; margin-bottom: 0in\" type=\"disc\">
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">A runner in �the zone� 
	(runner�s high); or a kid playing make-believe on the playground; or when 
	you�re driving for hours and by �being elsewhere� mentally you completely 
	lose track of time �� they are all examples of light altered states.</span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">When you lie down to 
	go to sleep at night and you let your mind wander in that daydreamy state 
	right before you drift off to sleep � that�s hypnosis.</span></li>
</ul>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Now, in the past you�ve 
probably never called these things hypnosis.&nbsp; You haven�t ever thought of them 
as mystical experience or mind control or being �zombified� or anything of the 
sort have you?&nbsp; No, because trance really is normal, natural and something you 
do accidentally every day without being aware of it.&nbsp; EVERYONE CAN ACHIEVE 
HYPNOSIS (<i>Except people with brain damage or who are presently using certain 
mind-altering drugs.)&nbsp; </i>&nbsp;The difference is that at The American Hypnosis 
Clinic we are going to deliberately guide you into trance, deepen the trance � 
and USE these simple states of mind to help you learn with a different part of 
your brain how to change habits much more quickly and easily.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Sometimes people are 
surprised because they really expected a foreign feeling � something exotic and 
amazing � and so they wonder if they�ve even been hypnotized.&nbsp; But it doesn�t 
feel foreign at all� especially when people go into a lighter or �uptime� 
trance.&nbsp;&nbsp; Only an unusually deep trance feels unusual.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">The good news is that 
light-to-medium depth trances are just as effective as deep trance experiences 
at making the changes you need to make.&nbsp; It�s not the depth of trance that 
matters for change � it is REPETITION of the RIGHT post-hypnotic suggestions 
that matters most.&nbsp; The suggestions have to meet your values and needs and take 
care what psychologists call the secondary gains of your behavior.&nbsp; That kind of 
thing is why The American Hypnosis Clinic has the best-trained therapists in the 
nation � to make sure we can find out what makes you tick and make sure you get 
what you need.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">That�s also why we always 
make a tape or CD for you to take home and use over and over.&nbsp; The more you use 
it, the more your unconscious mind learns and the more easily you can 
consciously change your habits.&nbsp; Sometimes it�s <u>effortless</u> and the change 
can be AMAZING!&nbsp; Other times, you still have to put real effort into changing 
your habits � but you will <u>succeed</u> this time because it gets much easier 
and much faster thanks to hypnosis.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">You will go deeper with 
practice simply as a byproduct of doing hypnosis regularly (hence the 
recording).&nbsp; The only thing that keeps people from going deep is anxiety.&nbsp; So 
the more you do it, the more at ease you become with it and therefore the deeper 
you go.&nbsp; Also, just like anything else � the more you do it, the better you get 
at it.&nbsp; Your experience will vary from time to time.&nbsp; Sometimes you�ll just feel 
relaxed and wonder if anything happened at all, sometimes you�ll think you�ve 
dozed off and eventually (when you�ve gotten REALLY good at it) you may feel 
completely numb (hypnoanesthesia) or even like you are floating outside your 
body!&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">To start, just expect to 
relax and to enjoy listening to the soothing sounds of your therapist�s voice.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\">&nbsp;</p>

<h6></h6>



<table class=\"MsoNormalTable\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table1\">
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		

		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\"><b>
		<span style=\"font-family:
  Arial\">What You Will <u>NEVER</u> Experience</span></b></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">


		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\"><b>
		<span style=\"font-family:
  Arial\">What You <u>WILL</u> Experience</span></b></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Being out of control � like someone�s 
		taken control of you or making you do anything</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Being very relaxed</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">You WILL hear your therapists voice (at 
		least at first)</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\"><b>
		<span style=\"font-family:
  Arial\">&nbsp;</span></b></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">(At least in the beginning) Very aware 
		of the sounds around you and what you feel</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">(At least in the beginning) Very aware 
		of your own thoughts</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\"><b>
		<span style=\"font-family:
  Arial\">What You PROBABLY WILL NOT Experience</span></b></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\"><b>
		<span style=\"font-family:
  Arial\">What You MIGHT Experience <br>
		(Especially if you go very deep)</span></b></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Probably will not forget anything 
		(unless you go very deep)</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">More or less than the usual amount of 
		water in your eyes or mouth </span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Your thought processes will not stop.&nbsp; 
		You will still be thinking, wondering, questioning, etc.</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Might feel heavy or even numb in fingers 
		or (if very deep) all over body</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">What you imagine may become <u>unusually</u> 
		vivid</span></td>
	</tr>
	<tr>
		<td width=\"367\" valign=\"top\" style=\"width:275.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">&nbsp;</span></td>
		<td width=\"348\" valign=\"top\" style=\"width:261.0pt;padding:0in 5.4pt 0in 5.4pt\">
		<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt\">
		<span style=\"font-family:Arial\">Might forget bits and pieces or large 
		chunks of conversation</span></td>
	</tr>
	
</table>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">There are actually several 
different types of altered states.&nbsp; In some your mind is very focused and you 
are imagining very vividly.&nbsp; In others, your conscious mind recedes to the point 
that you might almost think you are sleeping.&nbsp; The truth is, it�s not that 
important what your conscious mind is doing � it�s your <u>unconscious</u> mind 
that needs to be listening and learning.&nbsp; Remember, you�ve been trying to fix 
this problem consciously and utterly failed.&nbsp; So what we�re doing is very 
different.</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Your therapist may use 
traditional directive hypnosis, or what is called a regression or use NLP 
(neurolinguistic programming) exercises that don�t seem like hypnosis at all but 
simply imagination exercises.&nbsp; It all depends on the nature of your problem and 
where you are along the path to solving it.&nbsp; In any case, they are all ways to 
teach a part of your mind that is normally inaccessible. </span></p>

<h6></h6>

<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Remember, there is no wrong 
way to do hypnosis.&nbsp; You really can�t mess it up, so just relax and enjoy it!&nbsp; 
You WILL succeed if you simply follow your therapist�s instructions.&nbsp; 
<br>
&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">This is how to get the best 
experience:</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">

&nbsp;</span></p>
<ul style=\"margin-top: 0in; margin-bottom: 0in\" type=\"disc\">
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">Repeat what your 
	therapist says in your own voice within your own mind.</span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">Follow his or her 
	instructions carefully when they tell you to relax one muscle at a time or 
	imagine certain things.</span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">Imagine what you are 
	asked to <b>as vividly as you can</b>:&nbsp; See it, hear it, feel it, smell it 
	and/or taste it in as much detail as possible.&nbsp; Focus all your attention on 
	THAT and the other thoughts that otherwise might have distracted you will 
	fade naturally into the background.&nbsp; Remember that this is relaxing 
	playtime.&nbsp; You�re just playing make-believe like you did as a child.&nbsp; In the 
	past you may have been taught not to daydream� but today it�s OKAY!</span></li>
	<li class=\"MsoNormal\"><span style=\"font-family:Arial\">If your mind wanders 
	into work problems, worries about your success, or anything negative focus 
	it back to where your therapist is leading.&nbsp; </span></li>
</ul>
<br>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Remember your hypnotist is 
a guide and a teacher.&nbsp; He or she does not �hypnotize you��&nbsp; Your hypnotist <b>
<u>guides you</u> </b>into hypnosis.</span></p>

<p class=\"MsoNormal\"><u><span style=\"font-family:Arial\">You</span></u><span style=\"font-family:Arial\"> 
have to do it.&nbsp; Just like it�s been <u>you</u> that has been �doing� the 
behavior in question all this time.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">But because <u>you</u> have 
taken responsibility for <u>your</u> actions and <u>your</u> decision to change
<u>your</u> life� <u>YOU</u> WILL DO GREAT!&nbsp; I promise.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">Hypnosis is normal, natural 
and <b><u>easy</u></b>.&nbsp; It�s so easy you do it by accident!&nbsp; With the proper 
coaching it can be as easy as allowing gravity help you fall back into your 
favorite easy chair.&nbsp; And you�ve got Olympic-quality coaches here at The 
American Hypnosis Clinic to help you succeed.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">We respect and admire the 
fact that you�ve chosen to take control of your life and here at The American 
Hypnosis Clinic we�re proud you have chosen us to help you do it!&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-family:Arial\">&nbsp;</span></p>

<h6></h6>

<br><br><br>
<p class=\"MsoFootnoteText\"><span style=\"font-family: Arial\"><font size=\"2\">� 
2003, Larry Volz/The American Hypnosis Clinic, inc.</font></span></p>

<h6></h6>";


?>





