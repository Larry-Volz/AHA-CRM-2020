<?

$client_contract = "


<font size=4 color=\"red\">This Document must be completed and signed for return to the American Hypnosis Clinic by your therapist.</font>
<h3>Lifetime Commitment Guarantee &amp; Client Contract</h3>
<font size=2>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I, $f_name $l_name, understand that The American Hypnosis Clinic, inc. (hereafter referred to as AHC) uses different types of hypnosis, waking and somnambulistic, that are customized to each client.&nbsp; I agree to be hypnotized so my AHC-assigned hypnotist can help me by setting specific goals and giving me suggestions to achieve my goals and overcome personal challenges I have chosen to work on while in a self-hypnotic state.  Suggestion is the artful use of imagination within a self-hypnotic state to increase enthusiasm for self improvement and making good decisions using self-help techniques.&nbsp; Self-help techniques are thinking strategies used by normally-functioning people to remind themselves of improvements they wish to make in their lives. Hypnotists use suggestion while the client is in the self-hypnotic state to teach such strategies.&nbsp;<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand AHC offers a <u>lifetime</u> support guarantee.  Once enrolled in the program if more than one session is needed AHC will provide additional help using various types of hypnosis <u>at no additional charge for life</u>.  AHC care-giving options may include (but are neither obligated nor limited to): education in self-hypnosis, neurolinguistic programming, stress reduction techniques, biofeedback resources (GSR and/or EEG), practical lifestyle planning, reinforcement recordings and long-distance therapy. <br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand and agree to any recording that may be deemed necessary over the course of my care at AHC and the reviewing of my personal information with other therapists and staff within AHC for cross-consultation, record-keeping or training purposes.<BR>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand that for me to succeed I will have to accept the responsibility of doing my part.&nbsp; Hypnosis is an active, participatory therapy and cannot succeed without my full commitment and complete cooperation.&nbsp; I am signing this agreement and beginning hypnotherapy because I am serious about accomplishing my goals once and for all.  I agree to follow all suggestions given to me by my therapist, including keeping all appointments, mental exercises and lifestyle advice.&nbsp; I understand that if I don�t keep appointments and follow all instructions given me, AHC cannot and will not warranty their work.&nbsp; In order to succeed, my full cooperation is needed.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;According to top experts in the field of hypnosis and psychology <b>everyone with normal brain function can be hypnotized.&nbsp; The vast majority of clients succeed in their goals quickly and with few sessions</b>.&nbsp; However, for the occasional clients who have difficulty and need more sessions, our policies provide an incentive not to give up. Because clients pay for a program instead of session by session, it is to their advantage to utilize our support guarantee and stick with it until they completely succeed.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand that it is impossible to guarantee the behavior of another human being and that sometimes there are psychological or medical issues involved.&nbsp; I understand that in those cases mental health counseling may be needed.&nbsp; This is beyond the specialized service of hypnosis that AHC offers.&nbsp;  I understand that AHC does not do Psychotherapy.&nbsp; AHC does not prescribe drugs, diagnose any medical conditions or provide treatment for such conditions.&nbsp; AHC uses methods of hypnosis, visualization, guided imagery and relaxation (V68.20).&nbsp; All AHC hypnotherapists have training in the unique skills and methods of the complimentary therapeutic modality known as hypnosis and use only those skills in order to coach, teach, guide, instruct, and train clients to help themselves.&nbsp;&nbsp;AHC therapists are subcontractors and it is their responsibility to operate within the laws of their state.  If psychotherapy or medical help is necessary then I will personally accept all responsibility of seeking such help on my own.&nbsp; This does not lessen the ability of AHC to help me in addition to outside psychological or medical counseling nor does it relieve me from my agreement with them.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AHC reserves the right to permanently refuse service to clients who,in sole the opinion of AHC staff, are belligerent or physically abusive in any way to any member of AHC staff or other clients. AHC also reserves the right to refuse service to clients who come to their appointments under the influence of alcohol or any other mind-altering drug.&nbsp; AHC may (at it's sole discretion) choose to overlook one or more infractions of these rules, but can choose to permanently refuse services to such clients at any time.  <br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I understand that the therapist�s time is valuable and sought after and I am paying for a program at the total cost of \$$total_display, This figure includes a $finance_rate_display% finance charge if it is being financed into more than one payment.  I am buying priviledges to enjoy a complete program and not paying a per-session fee (which often is more expensive).  &nbsp;&nbsp; Therefore I understand that AHC does not issue refunds under any circumstances.&nbsp; Once I enter into this contract, I am bound to its terms and must pay for the program in full.&nbsp; I agree to pay for services in advance (according to terms agreed upon including payment plans if applicable) plus court costs and attorney fees if collection is necessary.&nbsp; <br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;When a client does not show up to his or her allotted appointment it means that someone else cannot be helped during that time slot.&nbsp; Therefore, AHC asks that if you have to cancel or reschedule an appointment please give us as much notice as possible.&nbsp; If your therapist has to cancel an appointment we will extend the same courtesy and it will not affect this fiscal agreement.  We reserve the right to charge a \$35 rescheduling fee cancellations or no-show�s with less than 24-hour advance notice.&nbsp; If two or more appointments are missed without 24 hours notice or is more than 20 minutes late more than twice without provable and justifiable reason, AHC can, at its sole discretion, permanently refuse services.  If AHC chooses to permanently refuse services to a client for any of the above mentioned causes, the client will still be responsible for the full amount of this agreement in full due on the first scheduled appointment date.<br>
<br>
<strong>Promissory Note:</strong>&nbsp;&nbsp;

I, $f_name $l_name, hereby enroll in AHC Affiliate hypnotherapy program.&nbsp; I agree to pay The American Hypnosis Clinic exactly \$$total_display for the complete program.  My payment schedule consists of $100 for the initial deposit and $number_of_payments payments of \$$equal_payments_of per month with my first installment being due at the time of service.&nbsp; &nbsp; I understand that if I wish to pay with a money order, I must pay the entire remaining balance at the time of my appointment, and it must be made out to The American Hypnosis Clinic.  I agree to and am bound by all terms and conditions in The AHC document \"Lifetime Commitment Guarantee &amp; Client Contract.\"&nbsp; I authorize The American Hypnosis Clinic to deduct the funds from the credit or debit card listed below according to this schedule.
<br><br>
<table><tr><td width=\"100%\"><font size=\"2\">Payment type:____________________________________________</font></td></tr>
<tr><td><font size=\"2\">Credit Card Number:____________________________________________</font></td></tr>
<tr><td><font size=\"2\">Expiration Date:____________________________________________</font></td></tr>
</table>

<br>I have read and agree to the above:<br>
<p class=\"MsoNormal\" align=\"right\" style=\"text-align:right\">
<span style=\"font-size: 10.0pt; font-family: Arial\">
___________________________________&nbsp;&nbsp;&nbsp; ______________</span></p>
<p class=\"MsoNormal\" align=\"right\" style=\"text-align:right\">
<span style=\"font-size: 10.0pt; font-family: Arial\">
Signature&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date</span></p>



<h6></h6>";



?>
