<?

$directions_to_richmond = "

<style>
<!--
h1
	{margin-top:12.0pt;
	margin-right:0in;
	margin-bottom:3.0pt;
	margin-left:0in;
	page-break-after:avoid;
	font-size:12.0pt;
	font-family:Arial;
	}
 table.MsoNormalTable
	{mso-style-parent:\"\";
	font-size:9.0pt;
	font-family:\"Times New Roman\";
	}
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
p.MsoHeader
	{margin-bottom:.0001pt;
	tab-stops:center 3.0in right 6.0in;
	font-size:9.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>

<span style=\"font-size: 9.0pt\"><h5><font size=\"3\">10710 Midlothian 
Turnpike, Suite 116, Richmond, VA 23235 -- (804) 594-2600</font></h5></span>
<table class=\"MsoNormalTable\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: id=\"table1\" width=\"100%\">
	<tr>
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; border: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\"><span style=\"font-family:Arial\">From points North 
		Via I-95</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: 1.0pt solid windowtext; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">(Do not take I-295) 
		From I-95 take exit #79.&nbsp; Immediately bear left onto I-195 towards 
		Powhite Parkway (VA 76s). Continue South ON Powhite Parkway (Route 76) 
		across the James River, through the toll plaza (.50 cents), continuing 
		straight on 76 South.&nbsp; Exit onto Midlothian Turnpike heading <u>West</u>. 
		Go 2 miles to the lights at Johnston-Willis Drive, (Sheehy Ford on the 
		left, hospital on right).&nbsp; Turn right onto Johnston-Willis Drive, and 
		take an immediate left into our parking lot.&nbsp; We are in the first glass 
		building on the left (Suntrust &amp; VA Physicians for Women).&nbsp; We are in 
		Suite 116.</span></td>
	</tr>
	<tr>
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; border-left: 1.0pt solid windowtext; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\"><span style=\"font-family:Arial\">From Points East 
		Via I-64</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">(Do not take I-295)&nbsp; 
		Take I-64 West towards Richmond.&nbsp; Exit on I-95 South (Exit #190).&nbsp; Go 
		approximately � mile and exit onto Route I-195 (Downtown expressway) at 
		Exit #74A.&nbsp; After the toll plaza (.50 cents) stay on Powhite Parkway 
		(Route 76) South.&nbsp; Take the exit for Midlothian Turnpike (Route 60), 
		heading West. Look for the lights at Johnston-Willis Drive, (Sheehy Ford 
		will be on the left, Hospital on right). Turn right onto Johnston-Willis 
		Drive, and take an immediate left into our parking lot.&nbsp; We are in the 
		first glass building on the left (Suntrust &amp; VA Physicians for Women).&nbsp; 
		We are in Suite 116.</span></td>
	</tr>
	<tr>
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; border-left: 1.0pt solid windowtext; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\"><span style=\"font-family:Arial\">From points South 
		Via I-95</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">From I-95 North take 
		Exit #67, Chippenham Parkway North (Route 150).&nbsp; Continue North on 
		Chippenham Parkway (Route 150) to Midlothian Turnpike West (Route 60).&nbsp; 
		Go approx. 2.5 miles to lights at Johnston-Willis Drive. (Sheehy Ford 
		will be on the left, Hospital on right).&nbsp; Turn right onto 
		Johnston-Willis Drive, and take an immediate left into our parking lot.&nbsp; 
		We are in the first glass building on the left (Suntrust &amp; VA Physicians 
		for Women).&nbsp; We are in Suite 116.</span></td>
	</tr>
	<tr style=\"height:94.0pt\">
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; height: 94.0pt; border-left: 1.0pt solid windowtext; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoHeader\"><span style=\"font-family:Arial\">From points West 
		Via Route 360/Route 460</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; height: 94.0pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">Take 460 East past 
		Farmville exits.&nbsp; Take a left on Route 307.&nbsp; Take a left onto Route 360 
		East.&nbsp; Exit onto Route 288 to Powhite Parkway (Route 76)(toll plaza � 75 
		cents).&nbsp; Continue on Powhite parkway to the Midlothian Turnpike (Rt. 60) 
		exit. Head West. Go approx. 2.5 miles to lights at Johnston-Willis 
		Drive. (Hospital is on the right,&nbsp; &amp; Sheehy Ford is on the left.) Turn 
		right onto Johnston-Willis Drive, and take an immediate left into our 
		parking lot.&nbsp; We are in the first glass building on the left (Suntrust &amp; 
		VA Physicians for Women).&nbsp; We are in Suite 116.</span></td>
	</tr>
	<tr style=\"height:53.5pt\">
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; height: 53.5pt; border-left: 1.0pt solid windowtext; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\"><span style=\"font-family:Arial\">From the South on</span><span style=\"font-size: 9.0pt; font-family: Arial\">
		</span><span style=\"font-family:Arial\">Courthouse Rd.</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; height: 53.5pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">Take Courthouse Road 
		North. At lights at Midlothian Turnpike, (Rt. 60), go right, heading 
		East to the 5<sup>th</sup> set of lights at Johnston Willis Drive. (Sheehy 
		Ford on Rt., Hospital on Left).&nbsp; Turn left onto Johnston-Willis Drive, 
		and take an immediate left into our parking lot.&nbsp; We are in the first 
		glass building on the left (Suntrust &amp; VA Physicians for Women). We are 
		in Suite 116.&nbsp; </span></td>
	</tr>
	<tr>
		<td width=\"151\" valign=\"top\" style=\"width: 113.4pt; border-left: 1.0pt solid windowtext; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\"><span style=\"font-family:Arial\">From points West 
		via I-64</span></td>
		<td width=\"583\" valign=\"top\" style=\"width: 437.4pt; border-left: medium none; border-right: 1.0pt solid windowtext; border-top: medium none; border-bottom: 1.0pt solid windowtext; padding-left: 5.4pt; padding-right: 5.4pt; padding-top: 0in; padding-bottom: 0in\">
		<p class=\"MsoNormal\">
		<span style=\"font-size: 9.0pt; font-family: Arial\">(Do not take I-295)&nbsp; 
		From I-64 take I-195 South (exit 186), going towards Powhite Parkway 
		(Route 76 s). Continue South ON Powhite Parkway (Route 76) across the 
		James River, through the toll plaza (.50 cents), continuing straight on 
		76 South.&nbsp; Exit onto Midlothian Turnpike heading <u>West</u>. Go 2 miles 
		to the lights at Johnston-Willis Drive, (Sheehy Ford on the left, 
		hospital on right).&nbsp; Turn right onto Johnston-Willis Drive, and take an 
		immediate left into our parking lot.&nbsp; We are in the first glass building 
		on the left (Suntrust &amp; VA Physicians for Women).&nbsp; We are in Suite 116.</span></td>
	</tr>
</table>


";

?>