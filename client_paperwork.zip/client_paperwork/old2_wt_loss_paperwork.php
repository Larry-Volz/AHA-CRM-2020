<?
$wt_loss_letter = "
<style>
<!--
H6{page-break-after : always ; }	
-->
</style>

<p align=\"center\" style=\"text-align:center\"><h3>Individualized 
Weight Loss Program</h3>
(All information provided is kept strictly Confidential)</p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\"><br>Appointment:&nbsp;<u>$appointment_date at $appointment_time&nbsp;</u> for <u>$f_name $l_name</u> Birthdate __/__/___&nbsp;SSN ________________ </u></span></p>
<p><span style=\"font-size: 10.0pt; line-height: 150%\">Work # ________________ Home#________________ Marital 
Status______________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<p>Address _____________________________________ City_________________ State___ Zip____________</p>

<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">
Occupation____________________&nbsp; Company ________________________ 
E-mail: <u>$email </u> </span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Favorite Hobbies 
______________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Purpose of todays Visit: 
________________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">If you have or have had any 
of the following, please check:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
	<tr>
		<td>		
		__Allergies
		</td>
		<td>
		__Seizures
		</td>
		<td>		
		__Hearing problems
		</td>
		<td>
		__Asthma
		</td>
	</tr>
	<tr>
		<td>
		__Epilepsy
		</td>
		<td>
		__Heart Trouble
		</td>
		<td>
		__High Blood Pressure
		</td>
		<td>
		__Depression
		</td>
	</tr>
	<tr>
		<td width =\"100%\">
		__Other:____________________
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
</table>

<!-- <h6></h6> --> <!-- ##################### NEXT PAGE ###################### -->

<span style=\"font-size: 10.0pt; line-height: 150%\">Please list any drugs you may 
be taking or health problems you may be suffering from at this time: 
____________________________________________________________________________________________________________</span>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Family Physician 
_________________________________________ Last visit __________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Name of Practice: 
______________________________________Phone 
Number:______________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%; font-family: new times roman\">
May we contact your physician and share information with him or her to provide 
you with the best possible results? ______________</span><u><span style=\"font-size: 10.0pt; line-height: 150%; font-family: Arial\">
</span></u></p>
<p>Habits:</p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table2\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Alcohol</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Tobacco</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Coffee/Tea</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Salt Intake</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Special Diet</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other 
		______________________</span></td>
	</tr>
</table>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Please circle the ways in 
which you want to change your eating habits: <br>
__Lower size of portions.&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; __Reduce junk/fatty foods.&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Reduce 
sweets.&nbsp; &nbsp;&nbsp; __Establish a healthy routine.&nbsp; __Increase exercise. </span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Other: 
________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">What is motivating you to 
lose the weight now? 
____________________________________________________________________���What 
health problems are you suffering from now due to the weight? 
___________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">How much do you weigh now? 
___________&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How much do you want to weigh? ______________<br>
What size are you now? __________ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; What size will you 
be when you succeed? ________________<br>
Is anyone else in your family overweight? 
____________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">Please check the items that 
apply to you:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table3\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating large portions
		</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat out of boredom</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many fried foods
		</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating out frequently</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating when alone</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat in times of stress</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat between meals</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat late at night</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">I drink alcohol </span>
		</p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many soft drinks</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too much eating for 
		comfort</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Drugs</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Caffeine </span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many sweets</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too much fast food</span></td>
	</tr>
</table>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">Describe the types of foods 
you eat on a typical day:</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Breakfast 
________________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Morning Snacks 
___________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Lunch&nbsp; 
___________________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Afternoon Snacks 
__________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Dinner 
___________________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Late night Snacks 
__________________________________________________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">Binge eating?&nbsp; __Yes&__nbsp; 
No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How often? 
_________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">What triggers your binge 
eating? ________________________________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">Do you ever purge after you 
eat? __Yes&nbsp;&nbsp; __No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How often 
______________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">Do you exercise regularly?&nbsp; 
__Yes&nbsp;&nbsp; __No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How often 
______________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">What are your preferred 
types of exercise? 
________________________________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">How much water do you drink 
per day? ____________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">How is your knowledge of 
nutrition?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Good&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Average&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Poor</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">How is your extra weight 
negatively affecting your life?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table4\">
	<tr>
		<td width=\"238\" valign=\"top\" style=\"width:178.2pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Self-confidence</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Energy</span></td>
		<td width=\"218\" valign=\"top\" style=\"width:163.8pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Health</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Appearance</span></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Professionally</span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relationships</span></td>
	</tr>
</table>
<p><span style=\"font-size: 10.0pt\">&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">How will you feel once you 
have accomplished your goal?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table5\">
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Proud of yourself </span>
		</p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relieved </span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Happy </span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">A good example</span></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Healthy </span></p>
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Accomplished something 
		important&nbsp; </span></td>
	</tr>
</table>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">Please mention any other 
concern or question that you may have 
_______________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">


<p>I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional.  I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.&nbsp;&nbsp; I am accepting sole responsibility to communicate with such professionals independently, share relevent information with my therapist or go ahead with the program without involving other health care professionals as I see fit. </p>


<p>I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</p>
<p>(Patient Signature)&nbsp;_________________________________________</p>

<br><p><span style=\"font-size: 10.0pt\">(Patient Signature)&nbsp; 
_________________________________________</span></p>
<p><b><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>
<p align=\"center\" style=\"text-align:center\"><b>
<span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></b></p>

<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>";


?>
