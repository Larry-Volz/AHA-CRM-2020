<?
$general_program_letter="

<p><h3>Individualized $program_title[$program_index]&nbsp;Program<br>
<span style=\"font-weight: 400; font-style: italic\"><font size=\"3\">(All information provided is kept strictly Confidential)</font></span></h3></p>
<p>Appointment: <u>$appointment_date</u>&nbsp; at&nbsp; <u>$appointment_time</u></p>
<p>Name:&nbsp; <u>$f_name $l_name</u>&nbsp;Birthdate ____/____/____&nbsp; Work # ________________ 
Home#________________</p>
<p>Address ____________________________________ City__________________ State___ 
Zip ____________</p>
<p>SSN _________________________ Age______ Marital Status______________________</p>
<p>Occupation__________________________&nbsp;Company ______________________________ 
E-mail: <u>$email</u></p>
<p>Favorite Hobbies________________________________________________________________</p>
<p>Your goals for this visit: _______________________________________________________</p>
<p>If you have or have had any of the following, please check:</p>
<table width=\"100%\">
	<tr>
		<td>
			___Allergies
		</td>
		<td>
			___Asthma
		</td>
		<td>
			___Heart Trouble
		</td>
		<td>
			___Depression
		</td>
	</tr>
	<tr>
		<td>
			___Seizures
		</td>
		<td>
			___Epilepsy
		</td>
		<td>
			___High Blood Pressure
		</td>
		<td>
			___Hearing problems
		</td>
	</tr>
	<tr>
		<td colspan=\"4\">
			Other ______________________________________________________________________
		</td>
		
	</tr>
</table>				
<p>Please list any drugs you may be taking or health problems you may be suffering from at this time: _______________________________________________________________________________</p>
<p>Family Physician_________________________________________ Last visit __________________________</p>
<p>Name of Practice:______________________________________ Phone Number:_______________________</p>
<p>May we share information with your physician? __ Yes __ No</p>

<table width=\"100%\">
	<tr>
		<td width=\"27%\">
			___Alcohol
		</td>	
		<td width=\"32%\">
			___Tobacco
		</td>	
		<td width=\"39%\">
			___Coffee/Tea
		</td>						
	</tr>
	<tr>
		<td width=\"27%\">
			___Special Diet
		</td>	
		<td colspan=\"2\">
			Other __________________________________________________
		</td>	
	</tr>
</table>
<p>What negative effects has this behavior had on your life? _______________________________________________________________________________________________</p>
<p>_______________________________________________________________________________________________</p>
<p>Are your friends and family supportive of your decision to make this change?&nbsp; Are they aware of it?</p>
<p>_______________________________________________________________________________________________</p>
<p>When and where does this problem happen?&nbsp; <br><i>(Be specific.&nbsp; Specify the days of the week, how many times per week, time of day/evening, when you do specific other things, when certain things are said, when you go particular places, when a particular event happens, etc.)</i></p>
<p>_____________________________________________________________________________________________</p>
<p>_____________________________________________________________________________________________</p>
<p>What are you worried about changing after you succeed?&nbsp; __________________________________________________</p>
<p>What things motivate you? __________________________________________________________________________</p>
<p>How will you feel once you have accomplished your goal?</p>
<table width=\"100%\">
	<tr>
		<td>
		___Proud of yourself
		</td>
		<td>
		___Happy 
		</td>
		<td>		
		___Healthy 
		</td>				
	</tr>
	<tr>
		<td>
		___Relieved 
		</td>
		<td>
		___A good example
		</td>
		<td>
		___Accomplished something important 
		</td>				
	</tr>	
</table>
<p>Other concerns or questions: ________________________________________________________________________</p>

<p><font size=\"2\">I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional.  I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.&nbsp;&nbsp; I am accepting sole responsibility to communicate with such professionals independently, share relevent information with my therapist or go ahead with the program without involving other health care professionals as I see fit.
</font> </p>


<p><font size=\"2\">I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</font></p>
<p>&nbsp;</p>
<p>(Patient Signature)&nbsp;_________________________________________</p>

";

?>