<?



//include directions_to_richmond.php;

$directions_to_clinic_output = "<style>
<!-- 
H6{page-break-after : always ; }
-->
</style>
<h2><font color=\"black\">Directions to Clinic:</font></h2>";

if (($affiliate_id !=689)AND($affiliate_id !=687)AND($affiliate_id !=685)AND($affiliate_id !=865)){

 $directions_to_clinic_output .= "$directions_to_clinic <br>";

}else {
 $directions_to_clinic_output .= "$directions_to_richmond<br>"; 
}

 $directions_to_clinic_output .= "<strong>If you get lost please contact $affil_f_name $affil_l_name at $affil_prim_tel</strong>";



?>
