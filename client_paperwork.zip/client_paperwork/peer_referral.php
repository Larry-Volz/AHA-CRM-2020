<? 

$peer_referral_output="

<h2>Request for Peer Support</h2>

<p>American Hypnosis Clinic<BR>
10710 Midlothian Turnpikes, St. 116<BR>
Richmond, VA  23235</p>

<br>
<br>
Dear $f_name,
<br><br>
The American Hypnosis Clinic is dedicated to your success.  In order to make this transition easier and more effective for you, we recommend that you have as many positive outside influences as possible.  We would like to send a letter of instructions on how your friends and loved ones may be helpful to you in making this lifestyle change. This is completely optional, but we have found that the more positive influences you have in your life the easier this life change will be for you. 
<br><br>
Please list below the names and addresses of people you spend most of your time with.  These are the people who either support you the most or those would be the most temptation for you, such as friends, family, co-workers, neighbors, teammates, etc.  
<br><br>
If there is anyone that you do not want us to share your decision with simply leave them off of the list.  We will always respect your privacy.  Remember, people like you for who you are, not what you do and those that really care about you will be happy to help.
<br><br>
When you are done, please either mail it to:  <br>Peer Referrals<br>American Hypnosis Clinic<br>10710 Midlothian Turnpike Suite 116<br>Richmond, VA 23235<br><br>
Or you can fax it to us at: 804-594-2600.<br><br>

<table border=\"1\" width=\"100%\">
	<tr>
		<td><strong>
			Name
			</strong>
		</td>
		<td>
		<strong>	
			Relationship
		</strong>
		</td>
		<td>
		<strong>
			Phone
		</strong>
		</td>
		<td>
		<strong>
			E-mail or Address
		</strong>
		</td>
					
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>		
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>		
		<td>&nbsp;</td>			
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
</table>											
			
";

?>