<?

$light_sound_waiver="
<style>
<!--
h4
	{margin-bottom:.0001pt;
	text-align:center;
	page-break-after:avoid;
	font-size:14.0pt;
	font-family:Arial; margin-left:0in; margin-right:0in; margin-top:0in}
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
p.MsoBodyText3
	{margin-bottom:.0001pt;
	font-size:10.0pt;
	font-family:Arial;
	color:black;
	font-weight:bold;
	font-style:italic; margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>
<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><!--msnavigation--><td valign=\"top\">
<h3><span style=\"font-size:12.0pt\"><br><br><br>Health Questions/Light and Sound Machine 
Waver</span></h3>
<p class=\"MsoNormal\">&nbsp;</p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">Your therapist may 
have access to Light and Sound equipment sometimes used accelerate trance 
induction.&nbsp; Please complete this waiver to let us know whether or not you have 
any health conditions that may prevent the use of such equipment.</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">Are you subject to 
any form of seizures, epilepsy or visual photosensitivity, are using a 
pacemaker, undergoing shock treatment, diagnosed with mental illness, suffering 
cardiac arrhythmia or other heart disorders, currently taking stimulants, 
tranquilizers or psychotropic medication, specifically including illicit drugs 
and alcohol?&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">Yes____ No ___&nbsp; 
Explain: 
________________________________________________________________________</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">
_____________________________________________________________________________________________</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\"><b>
<span style=\"font-size:10.0pt;font-family:Arial;
color:black\">____If I have ever been diagnosed from any kind of epilepsy, have 
undergone electroconvulsive therapy or have any other specific brain damage I 
agree to inform my hypnotherapist of this information verbally as well as in 
writing here</span></b><span style=\"font-size:10.0pt;font-family:Arial;
color:black\"> before each hypnosis session and to refuse hypnosis methods not 
involving a Light/Sound system. </span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">____I also 
understand that there is a very remote chance that the light/sound machines may 
trigger an epileptic seizure if I have undiagnosed photosensitive epilepsy (just 
as a television set can).&nbsp; I have the right to refuse the light and sound 
machine and will inform the therapist if I do not want it used.&nbsp; If I choose to 
use it, I do so at my own risk.&nbsp; </span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoBodyText3\">The light/sound machine is not necessary for the 
induction of hypnosis.&nbsp; It is merely a device used for accelerating trance 
induction for certain individuals as determined by your therapist.&nbsp; As a general 
rule The American Hypnosis Clinic considers them as safe as your television set 
at home and useful for many clients. </p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>


<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">&nbsp;</span></p>
<p class=\"MsoNormal\">
<span style=\"font-size:10.0pt;font-family:Arial;color:black\">
_________________________________</span><br>
Signature</span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>

<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>

<h6></h6>";

?>
