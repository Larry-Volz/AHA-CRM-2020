<?

$MD_waiver = "
<style>
<!--
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>


<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><!--msnavigation--><td valign=\"top\">
<p class=\"MsoNormal\"><b><span style=\"font-size:14.0pt\">Physician�s Supervision 
Waiver</span></b></p>
<p class=\"MsoNormal\">&nbsp;</p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I, 
$f_name $l_name, hereby choose to undergo hypnosis without my 
physician�s or psychologist�s supervision.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I 
understand that my program may deal with challenges and goals that would be best 
supervised by my personal physician, psychologist or another medical 
professional and The American Hypnosis Clinic has recommended that I involve 
such a supervisor.&nbsp; I am exercising my right to choose to go ahead with the 
program regardless.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I 
understand that there is always a possibility of medical or psychological 
complications involved any time a person chooses to change his habits or embark 
on a self-improvement project.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I 
understand that The American Hypnosis Clinic does not do <i>Psychotherapy</i>.&nbsp; 
The American Hypnosis Clinic does not prescribe drugs, diagnose any medical 
conditions or provide treatment for such conditions.&nbsp; The American Hypnosis 
Clinic uses methods of hypnosis, visualization, guided imagery and relaxation 
(V68.20).&nbsp; All The American Hypnosis Clinic hypnotherapists have supervised 
training in the unique skills and methods of the alternative therapeutic 
modality known as hypnosis and use only those skills in order to coach, teach, 
guide, instruct, and train clients to help themselves.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">If 
psychotherapy or medical help is necessary then I will personally accept all 
responsibility of seeking such help on my own.&nbsp; This does not lessen the ability 
of The American Hypnosis Clinic to help me in addition to outside psychological 
or medical counseling nor does it relieve me from my agreement with them.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I release 
the American Hypnosis Clinic from any liability for medical or psychological 
issues that may arise during the course of my hypnosis program whether directly 
or indirectly relating to my goal or the change, addition, or cessation of my 
habits and release them from any liability resulting from my past psychological 
and medical history.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">
_________________________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ______________</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">
Signed&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">
_________________________________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ______________</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">
Witnessed&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
Date</span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>

<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>
<h6></h6>";

?>