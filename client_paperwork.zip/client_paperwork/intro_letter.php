<? //############### ECHO TODAY�S DATE#################

$intro_letter="

<p><strong>American Hypnosis Clinic</strong></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\"><br>Dear 
$_POST[f_name],</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Congratulations on your decision to take control of this part of your your life once and for all!  To ask for help with this kind of thing takes courage and so we are proud of you for stepping up to the plate and honored that you chose us to help.  This letter
will confirm your appointment with your therapist, $affil_f_name $affil_l_name on&nbsp;$appointment_date at $appointment_time&nbsp; at The American Hypnosis Clinic affiliate office at&nbsp;"; 

$rich_or_affil=$_POST[rich_or_affil];

if($rich_or_affil== "Richmond"){
  $intro_letter .= "10710 Midlothian Turnpike Suite 116 - Richmond, VA 23235.";
  }else{
    $intro_letter .="$address -- $city, $state $zip.  ";
}

$intro_letter.="&nbsp; <p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">You should have several forms attached to this e-mail that you will need to fill out and bring to your appointment.  If you have trouble opening, reading or printing them please feel free to call us at 804-594-2600 for help.  Please confirm your appointment by clicking the link below: </span></p>

";
  
$intro_letter_end ="<font color = \"black\"><p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">The price of the program is $$_POST[price_display].&nbsp; The average client usually comes for&nbsp;$_POST[num_sessions_display] sessions for this goal, however everyone is different and if additional sessions are needed they will be provided at no extra cost.  The first session usually takes 90 minutes or so and subsequent sessions are usually about one hour.&nbsp;</span></p>

<p> You can expect your hypnosis sessions to be relaxing and enjoyable.  To learn more about what to expect we <u>highly</u> recommend that you visit our website and go to the page <a href=\"http://www.americanhypnosisclinic.com/expect.htm\">www.americanhypnosisclinic.com/expect.htm</a> and read the article we have posted there.</p>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Please 
refrain from using caffeine, perfume, non-prescription drugs or alcohol before 
your appointment. Please try to arrive on time as your therapist may have 
other clients scheduled immediately following your session.  Also, please feel free to contact our main office at 1-888-HYPNO-22 and let us know how your experience was.&nbsp; We always like to hear good news!&nbsp; </span></p>

<br>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">All the 
best,</span></p>

<img src=\"http://www.americanhypnosisclinic.com/intranet/client_paperwork/larrysig.JPG\"  height=\"80\" />
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Larry 
Volz, PhD<br>Executive Director</span></p></font>";

$intro_letter_end .="<h6></h6>";


?>