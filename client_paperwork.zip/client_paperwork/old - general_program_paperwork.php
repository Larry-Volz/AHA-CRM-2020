<?
$general_program_letter="

<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td valign=\"top\">
<p ><h3>Individualized $program_title[$program_index]&nbsp;Program</h3>(All information provided is kept strictly Confidential)</p>
		<p><br>
<font>Appointment: <u>$appointment_date at $appointment_time</u></font></p><br>
<p>
Name:&nbsp; <u>$f_name $l_name</u>&nbsp; 
Birthdate ____/____/____&nbsp; Work # ________________ Home#________________</p>
		<p>
		Address __<u>_______________________ 
		________________________ City____________________ State</u>___ Zip _<u>__________</u>__</p>
		<p>
		 SSN _________________________Age______ 
		Marital Status______________________</p>
		<p>
		Occupation__________________________&nbsp; Company 
		______________________________ E-mail: <u>$email</u></p>
<p>
Favorite Hobbies 
____________________________________________________________________________________________</span></p>
<p>
Your goals for today�s Visit: 
____________________________________________________________________________________</span></p>
<p>
If you have or have had any 
of the following, please check:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	<tr>
		<td width=\"184\" valign=\"top\" style=\"width:137.7pt;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Allergies</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Seizures</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Hearing problems</span></td>
		<td>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Asthma</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Epilepsy</span></td>
		<td>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Heart Trouble</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">High Blood Pressure</span></td>
		<td>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Depression</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other _____________</span></td>
	</tr>
</table>
<p>
&nbsp;</span></p>
<p>
Please list any drugs you may be taking or health problems you may be suffering from at this time: 
____________________________________________________________________________________________________________</p>
<p>
Family Physician 
_________________________________________ Last visit __________________________</span></p>
<p>
Name of Practice: 
______________________________________Phone 
Number:______________________________________</span></p>
<p>

May we contact your physician and share information with him or her to provide 
you with the best possible results? ______________</p>
<p>Habits:</p>
<table class=\"MsoNormalTable\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse\" id=\"table2\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Alcohol</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Tobacco</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Coffee/Tea</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Salt Intake</span></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Special Diet</span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other 
		______________________</span></td>
	</tr>
</table>
<p>
&nbsp;</span></p>
<p>
What negative effects has 
this behavior had on your life? </p>
<p>

___________________________________________________________________________________________________________</p>
<p>

____________________________________________________________________________________________________________</p>
<p>

____________________________________________________________________________________________________________</p>

<p>Are your friends and family supportive of your decision to make this change?&nbsp; Are they aware of it?</p>

<p>____________________________________________________________________________________________________________</p>

<p>When and where does this problem happen?&nbsp; <br>
<i>(Be specific.&nbsp; Specify the days of the week, how many times per week, time of 
day/evening, when you do specific other things, when certain things are said, 
when you go particular places, when a particular event happens, etc.)</i></p>
<p>____________________________________________________________________________________________________________</p>

<p>____________________________________________________________________________________________________________</p>

<p>____________________________________________________________________________________________________________</p>

<p>What are you worried that you will miss when you change this behavior?&nbsp; </p>

<p>____________________________________________________________________________________________________________</p>

<p>What things do you imagine that motivate you to succeed when you think about them?

<br><br>_____________________________________________________________________________________________________________<br>
<p>How will you feel once you have accomplished your goal?</p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table3\">
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Proud of yourself </span>
		</p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relieved </span></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Happy </span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">A good example</span></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Healthy </span></p>
		<p  style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; >___<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Accomplished something 
		important&nbsp; </span></td>
	</tr>
</table>
<p>
<span style=\"font-size: 4.0pt; line-height: 150%\">&nbsp;</span></p>
<p>Please mention any other concern or question that you may have _______________________________________________________</p>
<p>

____________________________________________________________________________________________________________</p>
<p>
I understand that all of the 
information I have provided is accurate to the best of my knowledge and is 
considered confidential information between patient and therapist.</span></p>
<p ><span style=\"font-size: 10.0pt\">(Patient Signature)&nbsp; 
_________________________________________</span></p>

<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>

<!-- <h6></h6>###################### PAGE BREAK ######################## -->";

?>
