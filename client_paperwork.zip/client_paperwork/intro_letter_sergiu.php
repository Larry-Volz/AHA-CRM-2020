<? //############### ECHO TODAY�S DATE#################

$intro_letter="<style>
<!--
H6{page-break-after : always ; }
-->
</style>
<br>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">
American Hypnosis Clinic<br>
10710 Midlothian Turnpike, St. 116<br>
Richmond, VA&nbsp; 23235</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">&nbsp;</span></p>

<br><br><br>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>Dear
$_POST[f_name],</span></p><br>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">This
will confirm your appointment with your therapist, $affil_f_name $affil_l_name on&nbsp;$appointment_date at $_POST[appointment_time]&nbsp; at The American Hypnosis Clinic affiliate office at&nbsp;";

$rich_or_affil=$_POST[rich_or_affil];

if($rich_or_affil== "Richmond"){
  $intro_letter .= "10710 Midlothian Turnpike Suite 116 - Richmond, VA 23235.";
  }else{
    $intro_letter .="$address <br>$city, $state $zip.  ";
}

$intro_letter.="&nbsp; <p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>Please
fill out the enclosed forms and return them or fax them to your therapist as
soon as possible; this will free up some time for you, give your therapist a
chance to read over them in advance and afford us the opportunity to accomplish

more for you during your session.&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>Included in your paperwork is a letter to permit us to include your physician as a cooperative part of the program.&nbsp;
Please fill it out and have your physician sign it.&nbsp; This
should be completed and returned to us before your appointment
date.&nbsp; If you choose not to inform you medical doctor of your treatment, make sure you
complete and sign the Physician Supervision Waiver.&nbsp; We have to have one or the other of these documents in order to see you.</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>The
price of the program is $$_POST[price_display].&nbsp; The average
client usually comes for&nbsp;$_POST[num_sessions_display] sessions for this
goal, however your therapist will be able to more accurately project how many
sessions will be needed for you individually.&nbsp; Everyone is different and if
additional sessions are necessary they will be provided at no extra cost.  The first session usually takes 90 minutes or so and subsequent sessions are usually about one hour.&nbsp;
</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>Please
refrain from using caffeine, perfume, non-prescription drugs or alcohol before
your appointment.</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">
<br>Please try to arrive promptly at your scheduled time as your therapist may have
other clients scheduled immediately following your session.&nbsp; </span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\"><br>Also,
please feel free to contact us at our Richmond office at 1-888-HYPNO-22 and let us know how your
experience was.&nbsp; We always like to hear good news!&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">&nbsp;</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">All the
best,</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">&nbsp;</span></p>
<img src=\"http://www.americanhypnosisclinic.com/intranet/client_paperwork/larrysig.JPG\"  height=\"120\" />


<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: Arial\">Larry
Volz, PhD<br>Executive Director</span></p>";

$intro_letter .="<h6></h6>";


?>