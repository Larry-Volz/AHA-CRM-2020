<?

$MD_release="
<link rel=\"File-List\" href=\"MD_release_files/filelist.xml\">

<style>
<!--
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>

<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><!--msnavigation--><td valign=\"top\">

<h2>American Hypnosis Clinic</h2><h3>Physician Inclusion Letter</h3>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\"><br><br>Date: 
__________________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Dear 
Doctor,</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">I am 
executive director of The American Hypnosis Clinic, a hypnosis practice comprised 
of over 160 affiliated clinics across the nation including $affil_f_name $affil_l_name who has an office in your area.</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Your 
patient, $f_name $l_name has requested help and enrolled in our $program_title[$program_index] program.</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">$f_name has 
given us permission to contact you to both inform you of and include you in our treatment plan.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">We do 
not attempt to treat or diagnose disease or mental disorders of any kind.&nbsp; 
Hypnosis in no way replaces standard medical procedures, but works in 
conjunction with them by freeing the patient of feelings and attitudes that may 
be inhibiting his or her response to them.&nbsp; Through hypnosis, one uses the 
natural facilities of the mind to create a positive attitude and boost the 
immune system, allowing the client to make the most of the medical help 
available.&nbsp; Hypnosis helps to create strong positive expectancy and reduces 
stress, thereby normalizing the action of the autonomic nervous system.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Your 
signature below allows us to work together to help your patient increase his/her 
own natural resources through visualization and progressive relaxation.&nbsp; We will 
keep you informed with progress notes (as well as graphs of the electronic 
monitoring of the sessions when used) as we go along.&nbsp; At any point please feel 
free to call or e-mail the attending hypnotherapist or I with any questions or 
advice you may have so we can best serve your patient.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Thank 
you for your time, partnership and future referrals,</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>

<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Larry 
Volz, PhD NLPP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">
<br><br>Physician�s Name: __________________________________________________________</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">
Practice/Hospital(s):&nbsp; ________________________________________________________</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">Fax # 
and or e-mail: _________________________________________________________ <i>(for 
patient progress reports)</i></span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">
Physician�s Signature: ________________________________________________________</span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>

<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>

<h6></h6>";

?>
