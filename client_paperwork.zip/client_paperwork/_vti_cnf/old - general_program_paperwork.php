vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Aug 2006 03:20:21 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|09 Aug 2006 03:20:21 -0000
vti_cacheddtm:TX|09 Aug 2006 03:20:21 -0000
vti_filesize:IR|11165
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_backlinkinfo:VX|
