vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Oct 2006 03:11:36 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|15 Aug 2006 17:25:09 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|01 Oct 2006 03:11:36 -0000
vti_filesize:IR|2854
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
