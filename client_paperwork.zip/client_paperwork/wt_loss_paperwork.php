<?
$wt_loss_letter = "

<b><font size=\"4\">Individualized 
Weight Loss Program<br>
</font></b><i>(All information provided is kept strictly Confidential)</i><p>
<span style=\"font-size: 10.0pt; line-height: 150%\">Appointment:&nbsp;<u>$appointment_date at $appointment_time&nbsp;</u> for <u>$f_name $l_name</u> Birthdate __/__/___&nbsp;SSN 
_____________ </u></span>
</p>
<p><span style=\"font-size: 10.0pt; line-height: 150%\">Work # ________________ Home#________________ Marital 
Status______________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">
<p>Address _____________________________ City_________________ State___ Zip____________</p>
<p><span style=\"font-size: 10.0pt; line-height: 150%\">Occupation____________________&nbsp; Company ________________________ 
E-mail: <u>$email 
</u></span></p>
<p><span style=\"font-size: 10.0pt; line-height: 150%\">Favorite Hobbies 
_____________________________________________________________________</span></p>
<p><span style=\"font-size: 10.0pt; line-height: 150%\">If you have or have had any 
of the following, please check:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">
	<tr>
		<td width=\"22%\">		
		__Allergies
		</td>
		<td width=\"22%\">
		__Seizures
		</td>
		<td width=\"25%\">		
		__Hearing problems
		</td>
		<td width=\"29%\">
		__Asthma
		</td>
	</tr>
	<tr>
		<td width=\"22%\">
		__Epilepsy
		</td>
		<td width=\"22%\">
		__Heart Trouble
		</td>
		<td width=\"25%\">
		__High Blood Pressure
		</td>
		<td width=\"29%\">
		__Depression
		</td>
	</tr>
	<tr>
		<td colspan=\"4\">
		__Other (specify):________________________________________________________________
		</td>
	</tr>
</table>

<!-- <h6></h6> --> <!-- ##################### NEXT PAGE ###################### -->

<span style=\"font-size: 10.0pt; line-height: 150%\">Please list any drugs you may 
be taking or health problems you may be suffering from at this time: 
_________________________________________________________________________<br>
<br>
Family Physician 
_____________________________________ Last visit ______________________</span><p>
<span style=\"font-size: 10.0pt; line-height: 150%\">Name of Practice: 
________________________________Phone Number:________________________</span></p>
<p>
<span style=\"font-size: 10.0pt; line-height: 150%; font-family: new times roman\">
May we share information with your physician?&nbsp; __Yes&nbsp; __No</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: id=\"table2\" width=\"100%\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Alcohol</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Tobacco</span></p></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Coffee/Tea</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Salt Intake</span></p></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Special Diet</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Other: _______________________________</span></p></td>
	</tr>
</table>
<p>Please circle the ways in 
which you want to change your eating habits: 
		</p>
<table border=\"0\" width=\"100%\" id=\"table1\">
	<tr>
		<td>__Lower size of portions </td>
		<td>__Reduce junk/fatty foods</td>
		<td>__Reduce sweets</td>
	</tr>
	<tr>
		<td>__Establish a healthy routine</td>
		<td>__Increase exercise</td>
		<td>Other: __________________________________</td>
	</tr>
</table>
</p>
<p>What is motivating you to 
lose the weight now? ___________________________________________________</p>
<p>What 
health problems are you suffering from now due to the weight? 
__________________________________________________________________</span></p>
	
How much do you weigh now? 
___________&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; How much do you want to weigh? ______________<br>
What size are you now? __________ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; What size will you 
be when you succeed? ________________<br>
Is anyone else in your family overweight? 
____________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">Please check the items that 
apply to you:</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: id=\"table3\" width=\"100%\">
	<tr>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating large portions</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat out of boredom<br>
		</span><span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many fried foods</span><br>
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating out frequently</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eating when alone</span></p></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat in times of stress</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat between meals</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Eat late at night</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">I drink alcohol </span>
		<span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many soft drinks</span></p></td>
		<td width=\"245\" valign=\"top\" style=\"width:2.55in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too much eating for 
		comfort</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Drugs</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Caffeine </span>
		<span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too many sweets</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Too much fast food</span></p></td>
	</tr>
</table>
<p><span style=\"font-size: 10.0pt\">&nbsp;Describe the types of foods 
you eat on a typical day:</span></p>
<p><span style=\"font-size: 10.0pt\">Breakfast 
_____________________________
Morning Snacks 
_____________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Lunch&nbsp; 
_______________________________
Afternoon Snacks 
____________________________</span></p>
<p style=\"margin-left:.5in\"><span style=\"font-size: 10.0pt\">
Dinner 
_______________________________
Late night Snacks 
____________________________</span></p>
<p><span style=\"font-size: 10.0pt\">Binge eating?&nbsp; __Yes __ 
No&nbsp;&nbsp;&nbsp;&nbsp; How often? 
______________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;What triggers your binge 
eating?_______________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;Do you ever purge after you 
eat? __Yes&nbsp;&nbsp; __No&nbsp;&nbsp;&nbsp;How often 
_________________________</span></p>
<p><span style=\"font-size: 10.0pt\">&nbsp;Do you exercise regularly?&nbsp; 
__Yes&nbsp;&nbsp; __No&nbsp;&nbsp;&nbsp;How often _____________________________</span></p>
<p><span style=\"font-size: 10.0pt\">What are your preferred 
types of exercise?_______________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">How much water do you drink 
per day? _________________________________________</span></p>
<p><span style=\"font-size: 10.0pt\">How is your knowledge of 
nutrition?&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Good&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Average&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; __Poor&nbsp;</span></p>
<p><span style=\"font-size: 10.0pt\">How is your extra weight 
negatively affecting your life?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table4\">
	<tr>
		<td width=\"238\" valign=\"top\" style=\"width:178.2pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Self-confidence</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Energy</span></p></td>
		<td width=\"218\" valign=\"top\" style=\"width:163.8pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Health<br>
		</span><span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Appearance</span></p></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Professionally</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relationships</span></p></td>
	</tr>
</table>
<p><span style=\"font-size: 10.0pt\">How will you feel once you 
have accomplished your goal?</span></p>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse: collapse; margin-left: 5.4pt\" id=\"table5\">
	<tr>
		<td width=\"240\" valign=\"top\" style=\"width:2.5in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Proud of yourself</span><span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Relieved </span>
		</p></td>
		<td width=\"216\" valign=\"top\" style=\"width:2.25in;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Happy </span>
		<span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">A good example</span></p></td>
		<td width=\"271\" valign=\"top\" style=\"width:203.4pt;padding:0in 5.4pt 0in 5.4pt\">
		<p style=\"text-indent: -.25in; margin-left: .5in\">
		<span style=\"font-size: 8.0pt; font-family: Wingdings\">__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Healthy </span>
		<span style=\"font-size: 8.0pt; font-family: Wingdings\"><br>
		__<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</span></span><span style=\"font-size: 10.0pt\">Accomplished something 
		important&nbsp; </span></p></td>
	</tr>
</table>
<p>Other 
concerns or questions you have: 
______________________________________________________________</span></p>
<p style=\"margin-bottom:12.0pt;line-height:150%\">


<p><font size=\"2\">I understand that my program may deal with challenges and goals that should also be supervised by my personal physician, psychologist or another medical professional.  I understand that The American Hypnosis Clinic recommendeds that I involve such a supervisor if my circumstances or state laws require it.&nbsp;&nbsp; I am accepting sole responsibility to communicate with such professionals independently, share 
relevant information with my therapist or go ahead with the program without involving other health care professionals as I see fit.
</font> </p>


<p><font size=\"2\">I understand the above statement and that all of the information I have provided is accurate to the best of my knowledge and is considered confidential information between patient and The American Hypnosis Clinic.</font></p>
<p>Patient Signature:&nbsp;_________________________________________ Date: 
________________</p>





";


?>
