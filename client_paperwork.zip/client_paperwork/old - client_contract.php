<?

$client_contract = "

<style>
<!--
p.MsoSubtitle
	{margin-bottom:.0001pt;
	text-align:center;
	font-size:18.0pt;
	font-family:Arial;
	margin-left:0in; margin-right:0in; margin-top:0in}
 p.MsoNormal
	{mso-style-parent:\"\";
	margin-bottom:.0001pt;
	font-size:12.0pt;
	font-family:\"Times New Roman\";
	margin-left:0in; margin-right:0in; margin-top:0in}
H6{page-break-after : always ; }	
-->
</style>

<!--msnavigation--><table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><!--msnavigation--><td valign=\"top\">
<p class=\"MsoSubtitle\" align=\"left\" style=\"text-align:left\">
<span style=\"font-size:
14.0pt\">Lifetime Commitment Guarantee &amp; Client Contract</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I, 
$f_name $l_name, understand that The American Hypnosis 
Clinic uses different types of hypnosis (direct, Ericksonian, N.L.P., etc.) that 
are customized to each individual client according to his or her needs.&nbsp; I agree 
to be hypnotized so that my hypnotist can help me through setting specific goals 
and by giving me suggestions on how to achieve my goals and overcome the 
personal challenges I have chosen to work on while I am in a self-hypnotic 
state.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\" style=\"text-autospace: none\">
<span style=\"font-size:9.0pt;font-family:Arial\">Suggestion is the artful use of 
imagination within a self-hypnotic state to increase a client�s enthusiasm for 
self improvement and making good decisions using self-help techniques.&nbsp; 
Self-help techniques are thinking strategies used by normally-functioning people 
to remind themselves of improvements they wish to make in their lives. Such 
strategies are taught by hypnotists using suggestion while the client is in the 
self-hypnotic state.&nbsp; A common Self-Help Technique is a Regression. As used by a 
Hypnotist, a Regression is a review of significant or remarkable events by the 
client with the Hypnotist serving as a Guide.</span></p>
<p class=\"MsoNormal\" style=\"text-autospace: none\">
<span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\" style=\"text-autospace: none\">
<span style=\"font-size:9.0pt;font-family:Arial\">The American Hypnosis Clinic 
hypnotists may use these techniques to help clients regain self-control over 
alcohol, cigarettes or other drugs, manage their weight, regain a positive 
mental attitude, manage situational stress, improve sleep, reduce apprehensions 
or fears, determine and set goals, become more optimistic, teach 
self-confidence, and promote general wellness in their lives.</span></p>
<p class=\"MsoNormal\" style=\"text-autospace: none\">
<span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><b><span style=\"font-size:9.0pt;font-family:Arial\">I 
understand The American Hypnosis Clinic offers a <u>lifetime</u> support 
guarantee.&nbsp; The American Hypnosis Clinic is as committed as I am and whether I 
need only one session or several I know they will be there for me.&nbsp; </span></b>
</p>
<p class=\"MsoNormal\"><b><i><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></i></b></p>
<p class=\"MsoNormal\"><b><span style=\"font-size: 9.0pt; font-family: Arial\">Once 
enrolled in the program if more than one session is needed The American Hypnosis 
Clinic will provide additional help using various types of directive, 
non-directive and indirect hypnosis, as well as education in self-hypnosis, 
neurolinguistic programming, stress reduction techniques, access to audio/video 
and biofeedback resources (including GSR and/or EEG) and practical lifestyle 
change planning as needed <u>at no additional charge for life</u></span></b><span style=\"font-size: 9.0pt; font-family: Arial\">.</span></p>
<p class=\"MsoNormal\"><i><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></i></p>
<p class=\"MsoNormal\"><b><span style=\"font-size: 9.0pt; font-family: Arial\">I 
understand that for me to succeed I will have to accept the responsibility of 
doing my part.&nbsp; Hypnosis is an active, participatory therapy and cannot succeed 
without my full commitment and complete cooperation.&nbsp; I am signing this 
agreement and beginning hypnotherapy because I am serious about accomplishing my 
goals once and for all.</span><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;
</span></b></p>
<p class=\"MsoNormal\"><b><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></b></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I agree to 
follow all suggestions given to me by the staff of The American Hypnosis Clinic, 
including keeping all scheduled appointments, mental exercises and lifestyle 
change advice.&nbsp; I understand that if I don�t keep my appointments and follow all 
instructions given me, The American Hypnosis Clinic cannot and will not warranty 
their work.&nbsp; In order to succeed, my full cooperation is needed.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><i><span style=\"font-size:9.0pt;font-family:Arial\">
According to top experts in the field of hypnosis and psychology (Milton 
Erickson, Richard Bandler, Dave Elman and others) <b>everyone with normal brain 
function can be hypnotized.&nbsp; The vast majority of clients succeed in their goals 
quickly and with few sessions</b>.&nbsp; However, for the occasional clients who have 
unusual difficulty and need more sessions than average, our policies provide an 
incentive for those clients not to give up. Because clients generally pay for a 
program instead of session by session, it is to their advantage to utilize our 
lifetime support guarantee and stick with it until they completely succeed.
</span></i></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I 
understand that it is impossible to guarantee the behavior of another human 
being and that sometimes there are psychological or medical issues involved.&nbsp; I 
understand that in those cases mental health counseling may be needed.&nbsp; This is 
beyond the specialized service of hypnosis that The American Hypnosis Clinic 
offers.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I 
understand that The American Hypnosis Clinic does not do <i>Psychotherapy</i>.&nbsp; 
The American Hypnosis Clinic does not prescribe drugs, diagnose any medical 
conditions or provide treatment for such conditions.&nbsp; The American Hypnosis 
Clinic uses methods of hypnosis, visualization, guided imagery and relaxation 
(V68.20).&nbsp; All The American Hypnosis Clinic hypnotherapists have supervised 
training in the unique skills and methods of the alternative therapeutic 
modality known as hypnosis and use only those skills in order to coach, teach, 
guide, instruct, and train clients to help themselves.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size: 10.0pt; font-family: Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">If 
psychotherapy or medical help is necessary then I will personally accept all 
responsibility of seeking such help on my own.&nbsp; This does not lessen the ability 
of The American Hypnosis Clinic to help me in addition to outside psychological 
or medical counseling nor does it relieve me from my agreement with them.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I 
understand that the therapist�s time is valuable and sought after and I am 
paying for a program, not a per-session fee (which often is more expensive).&nbsp; 
Therefore I understand that The American Hypnosis Clinic does not issue refunds 
under any circumstances.&nbsp; Once I enter into this contract, I am bound to its 
terms and must pay for the program in full.&nbsp; I agree to pay for services in 
advance (according to terms agreed upon including payment plans if applicable) 
plus court costs and attorney fees if collection is necessary.&nbsp; 

<h6></h6></span>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I 
understand and agree to any recording that may be deemed necessary over the 
course of my care at The American Hypnosis Clinic.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">The 
American Hypnosis Clinic reserves the right to refuse service to clients who 
come to their appointments under the influence of alcohol or any other 
mind-altering drug.&nbsp; If a client comes to their appointment under the influence 
a second time The American Hypnosis Clinic can permanently refuse services to 
this client.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">The 
American Hypnosis Clinic reserves the right, at its sole discretion, to 
permanently refuse service to clients who are belligerent or physically abusive 
in any way to any member of The American Hypnosis Clinic staff or other clients.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">There is a 
high demand for our therapist�s time and when a client does not show up to his 
or her allotted appointment it means that someone else cannot be helped during 
that time slot.&nbsp; Therefore, to accommodate our clients most effectively The 
American Hypnosis Clinic asks that if you have to cancel or reschedule an 
appointment please give us as much notice as possible.&nbsp; We reserve the right to 
charge a $35 rescheduling fee cancellations or no-show�s with less than 24-hour 
advance notice.&nbsp; If two or more appointments are missed without 24 hours notice 
or is more than 20 minutes late more than twice without provable and justifiable 
reason, The American Hypnosis Clinic can, at its sole discretion, permanently 
refuse services.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">If The 
American Hypnosis Clinic chooses to permanently refuse services to a client for 
cause, the client will still be responsible for the full amount of this 
agreement but The American Hypnosis Clinic will have no responsibility to 
clients who are thus disrespectful of our contract.&nbsp; </span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:9.0pt;font-family:Arial\">I agree to 
allow The American Hypnosis Clinic to review my file with other therapists and 
staff within the company for cross-consultation and record-keeping purposes.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">I have 
read and understand the above.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">
_________________________________&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;___________________</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">Client 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;Date</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">
<span style=\"font-size:10.0pt;font-family:Arial\">Guarantee</span></p>
<p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">
<span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><b><span style=\"font-size:10.0pt;font-family:Arial\">The 
American Hypnosis Clinic is as committed to your success as you are</span></b><span style=\"font-size:10.0pt;font-family:Arial\">.</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">&nbsp;</span></p>
<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;font-family:Arial\">The 
American Hypnosis Clinic guarantees it�s services <b>for the life of the client</b> 
providing the client has followed all suggestions given and has kept all 
appointments as agreed.&nbsp; You, the client can return <b>at no charge</b> if you 
need to for the therapeutic goal stated above.</span></p>
<p class=\"MsoNormal\">&nbsp;</p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>
<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:150%\">
<span style=\"font-size: 10.0pt; line-height: 150%\">&nbsp;</span></p>



<!--msnavigation--></td><td valign=\"top\" width=\"24\"></td><td valign=\"top\" width=\"1%\">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table>

<h6></h6>";


?>
