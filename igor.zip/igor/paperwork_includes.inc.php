<?php
  //define program description variables (get from Igor_variables if needed to update)
                $program_title[0]= "No Program Selected";
                $program_title[1] = "Alcohol Self Control";
                $program_title[2] = "Anger Management";
                $program_title[3] = "Childbirth with Less Pain";
                $program_title[4] = "Class - CHt ";
                $program_title[5] = "Class - CHt/MHt ";
                $program_title[6] = "Class - MHt ";
                $program_title[7] = "Drug Self Control ";
                $program_title[8] = "Emotional Self-Improvement";
                $program_title[9] = "Fibromyalgia";
                $program_title[10] = "Single-Session Fibromyalgia";
                $program_title[11] = "Gambling Self-Control"        ;
                $program_title[12] = "Single-Session High Blood Pressure Reduction";
                $program_title[13] = "High Blood Pressure Reduction";
                $program_title[14] = "Single-Session I.B.S. Improvement";
                $program_title[15] = "I.B.S. Improvement";
                $program_title[16] = "Learning Improvement [ADD/ADHD]";
                $program_title[17] = "Memory Improvement";
                $program_title[18] = "Morning Sickness Reduction";
                $program_title[19] = "Motivation Improvement";
                $program_title[20] = "Improved Self-Control Over Impulses";
                $program_title[21] = "Pain Management";
                $program_title[22] = "Phobia Elimination";
                $program_title[23] = "Exploratory Regression";
                $program_title[24] = "Self-Esteem Improvement";
                $program_title[25] = "Sexual Issue Improvement";
                $program_title[26] = "Sleep Improvement";
                $program_title[27] = "Smoking Cessation";
                $program_title[28] = "Stress/Anxiety Reduction";
                $program_title[29] = "Unusual Per-HOUR Issues [need approval]";
                $program_title[30] = "Unusual Per-SESSION Issues [need approval]";
                $program_title[31] = "Weight Management";
                $program_title[32] = "Mini-Weight Management";
                $program_title[33] = "Multi-Goal Wellness";

//include individual client letters
        include "client_paperwork/intro_letter.php";
        include "client_paperwork/smoking_paperwork.php";
        include "client_paperwork/wt_loss_paperwork.php";
        include "client_paperwork/general_program_paperwork.php";
        include "client_paperwork/promissary_note.php";
//        include "client_paperwork/light_sound_waiver.php";
//        include "client_paperwork/MD_release.php";
//        include "client_paperwork/MD_waiver.php";
        include "client_paperwork/client_contract.php";

//        include "client_paperwork/expect_of_hypnosis.php";
        include "client_paperwork/directions_to_richmond.php";
        include "client_paperwork/directions_to_clinic.php";
        include "client_paperwork/peer_referral.php";

  
?>
