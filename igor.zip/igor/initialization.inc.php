<?php
//###################### Init file ########################
session_start();
include("includes/functions.inc.php");
include("includes/cls_sendmail.php");
include("includes/cls_html_to_pdf.php");
$auth = $_SESSION[auth];
$permission = $_SESSION[permission];
$f_name = $_SESSION[f_name];
$user_id = $_SESSION[user];




//***************************Prepare variables used in the current script**************************************************

//look up the affiliate and get the appropriate variables for directions to their clinic and contact numbers etc.
$affiliate_id=$_POST['affiliate_id'];

//import client info from form
$program_index=$_POST['program_index'];
$email=$_POST['email'];


$total_program_cost=$_POST['price_display'];
$number_of_payments=$_POST['num_payments_display'];
$equal_payments_of=$_POST['payment_display'];
$print_or_email=$_POST['print_or_email'];
$total_display = $_POST['total_display'];
$finance_rate_display = $_POST['finance_rate_display'];
$f_name = $_POST['f_name'];
$l_name = $_POST['l_name'];
$amount_to_charge = $_POST['deposit'];

//Appointment date calculations...
$apt_month = $_POST['months'];
$apt_day = $_POST['days'];
$apt_year = $_POST['year'];

$appt_hour = $_POST['appt_hour'];
$military_appt_hour = $appt_hour;
$appt_minutes= $_POST['appt_minutes'];
$am_pm = $_POST['am_pm'];

if ($am_pm=="PM"){
  $military_appt_hour += 12;
}
$readable_minutes=$appt_minutes;
if ($readable_minutes==0){
  $readable_minutes="00";
}
$appointment_time = "$appt_hour:$readable_minutes $am_pm";
$appointment_date = "$apt_month/$apt_day/$apt_year";
$apt_date=mktime($military_appt_hour,$appt_minutes,0,$apt_month,$apt_day,$apt_year);

//NEW VARIABLES FOR CREDIT CARD INFORMATION
$client_id=$_POST['client_id'];
$pc_id=$_POST['pc_id'];


$cc_type=$_POST['cc_type'];
$cc_number=$_POST['cc_number'];
$cc_expiration_month=$_POST['cc_expiration_month'];
$cc_expiration_year=$_POST['cc_expiration_year'];

        $cc_expiration_date=mktime(0,0,0,$cc_expiration_month,1,$cc_expiration_year);

$override_cc_exp = $_POST['override_cc_exp'];

$ck_routing_number=$_POST['ck_routing_number'];
$ck_account_number=$_POST['ck_account_number'];
$ck_number=$_POST['ck_number'];

//set financial variables
$xaction_status="pending";//later options are - charged, failed, deleted
$charge_date=time();

$date_sold_month = $_POST['date_sold_month'];
$date_sold_day = $_POST['date_sold_day'];
$date_sold_year = $_POST['date_sold_year'];
$date_sold_hour = $_POST['date_sold_hour'];
$date_sold_minute = $_POST['date_sold_minute'];

$date_sold = mktime($date_sold_hour,$date_sold_minute,0,$date_sold_month,$date_sold_day,$date_sold_year);


//wait on charge date calculations
$wait_month = $_POST['wait_month'];
$wait_day = $_POST['wait_day'];
$wait_year = $_POST['wait_year'];

$financial_notes = $_POST['financial_notes'];

$paperwork_only = $_POST['paperwork_only'];


//***************************END  Prepare variables used in the current script*************************************************
  
?>
