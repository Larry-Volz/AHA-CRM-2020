<?php

// log in and create an activity log for this action
//Get my class and methods


include_once("ahcDatabase_class.php");//drop the ../ if in root directory



//do basic security check
$ahcDB->securityCheckBasic();


//CONNECT to DB
$ahcDB->dbConnect();

//############################## DO LOG ENTRY ##############################################

//do log entry
$now=time();
$list_id=38; //code for 'SALE! - sending paperwork' - PUT IN CORRECT CODE FOR PAGE!

//DO LOG ENTRY
$ahcDB->logEntry($list_id);

//------------------------------ END LOG ENTRY --------------------------------------------------


//############################## LOG THE CREDIT CARD CHARGE IN THE FINANCIAL DATABASE TABLE ######################

/*
foreach ($_POST as $key=>$value)
echo "$key => $value<br>";
*/
  
?>
