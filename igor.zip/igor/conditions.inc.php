<?php

//***************************** Condition for stopping the paperwork generation *******************************************

//create a delayed charge date if checked
IF ($wait_day !=""){

        $charge_date = mktime(0,0,0,$wait_month,$wait_day,$wait_year);

}
//end create a delayed charge date if checked



//need to have a program/dollar amount and name chosen or return with message

IF (($total_program_cost=="0")||(trim($l_name)=="")||(trim($apt_day)=="")||($affiliate_id=="0")||(trim($appointment_time)=="")){
           header ("Location: http://www.americanhypnosisclinic.com/intranet/more_info_required.htm");
        exit;
}


IF (!is_email($email)){
           header ("Location: http://www.americanhypnosisclinic.com/intranet/not_valid_email.htm");
        exit;
}



//#################################CREDIT CARD INFORMATION TESTER########################

//if neither cc information nor check information is filled out
// if (any of these things are blank)AND(any of these things are blank)then -> redirect
// if(true= not all filled out)and (true=not all filled out)-> redirects
//if (false=all filled out)and(true=not all filled out)-> does not redirect


IF (((trim($cc_type)=="") OR (trim($cc_number=="")) OR (trim(cc_expiration_month)=="") OR (trim(cc_expiration_year)=="")) AND ((trim($ck_routing_number)=="") OR (trim($ck_account_number=="")) OR (trim($ck_number)==""))){
           header ("Location: http://www.americanhypnosisclinic.com/intranet/more_info_required.htm");
        exit;
}

//########################### Test to make credit card date extends past last payment ########################

IF ((trim($cc_number != "")) AND ($override_cc_exp !="checked")){

        //look at first appointment date and add as many months to it as we have payments to determine last payment

        $last_pmt_month = ($apt_month + $number_of_payments - 1);
        $last_pmt_year = $apt_year;

                if ($last_pmt_month > 12){
                  $last_pmt_month -= 12;
                  $last_pmt_year += 1;
                }//end last payment month december/january check

                //cc expires last day of the month...
                $last_payment_day=30;
                        if ($last_pmt_month==2){//unless february...
                          $last_payment_day=28;
                        }

        $last_pmt_date = mktime(11,59,00,$last_pmt_month,$last_payment_day,$last_pmt_year);

        //compare cc expiration to last payment date.  If cc_exp < last payment then header to no way dude page
        If ($cc_expiration_date < $last_pmt_date){

                header ("Location: http://www.americanhypnosisclinic.com/intranet/cc_expires_too_soon.php");
                exit;

        }//end credit card expiration date comparison

}//end ONLY IF CREDIT CARD


//#################################END CREDIT CARD INFORMATION TESTER######################## 


//*****************************END Condition for stopping the paperwork generation ******************************************* 
  
?>