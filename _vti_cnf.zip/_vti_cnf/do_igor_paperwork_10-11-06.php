vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:22 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|11 Oct 2006 20:59:31 -0000
vti_title:SR|American Hypnosis Clinic
vti_backlinkinfo:VX|
vti_cacheddtm:TX|12 Dec 2006 15:09:22 -0000
vti_filesize:IR|28439
vti_cachedtitle:SR|American Hypnosis Clinic
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|client_paperwork/css_for_client_paperwork.css
vti_cachedsvcrellinks:VX|FQUS|client_paperwork/css_for_client_paperwork.css
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
