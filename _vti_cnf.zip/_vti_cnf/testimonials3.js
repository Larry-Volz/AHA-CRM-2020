vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:51 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|testimonials3_scroller_only_page.htm
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TW|04 Mar 2006 21:03:27 -0000
vti_timecreated:TR|04 Mar 2006 21:01:57 -0000
vti_cacheddtm:TX|04 Mar 2006 21:05:08 -0000
vti_filesize:IR|10555
