vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|01 Oct 2006 16:26:29 -0000
vti_timecreated:TR|03 Mar 2006 00:28:12 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|_borders/left.php _borders/old\\ left.htm _borders/old-half-wrecked-left.php
vti_editor:SW|FrontPage Frames Wizard
vti_nexttolasttimemodified:TR|18 Apr 2006 18:28:12 -0000
vti_cacheddtm:TX|01 Oct 2006 16:26:29 -0000
vti_filesize:IR|1195
vti_cachedtitle:SR|New Page 1
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|F|knowledgebase_files/knowledgebase_left.htm F|knowledgebase_files/blank_knowledgbase_file.htm
vti_cachedsvcrellinks:VX|FFUS|knowledgebase_files/knowledgebase_left.htm FFUS|knowledgebase_files/blank_knowledgbase_file.htm
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_hasframeset:BR|true
