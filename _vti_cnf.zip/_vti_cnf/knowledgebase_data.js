vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|02 Mar 2006 09:16:26 -0000
vti_timecreated:TR|02 Mar 2006 07:53:21 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|experiment\\ \\ -\\ Knowledge\\ Base.htm
vti_nexttolasttimemodified:TW|02 Mar 2006 09:11:14 -0000
vti_cacheddtm:TX|02 Mar 2006 09:16:26 -0000
vti_filesize:IR|36533
