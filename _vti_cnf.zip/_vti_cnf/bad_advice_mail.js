vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|12 Dec 2006 15:09:16 -0000
vti_timecreated:TR|02 Mar 2006 09:44:32 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|02 Mar 2006 09:47:31 -0000
vti_cacheddtm:TX|02 Mar 2006 09:47:54 -0000
vti_filesize:IR|292
