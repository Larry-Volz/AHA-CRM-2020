vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:34 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|07 Oct 2006 06:23:34 -0000
vti_title:SR|AHC Intranet Home
vti_backlinkinfo:VX|
vti_cacheddtm:TX|12 Dec 2006 15:09:34 -0000
vti_filesize:IR|11195
vti_cachedtitle:SR|AHC Intranet Home
vti_cachedbodystyle:SR|<body topmargin="2">
vti_cachedlinkinfo:VX|S|People\\ banner\\ 1.jpg H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/affiliates_menu.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/all_clients/show_all_leads.php H|http://wwwa.accuweather.com/forecast.asp S|http://wxport.accuweather.com/wxpost/graphic.aspx
vti_cachedsvcrellinks:VX|FSUS|People\\ banner\\ 1.jpg NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/affiliates_menu.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/all_clients/show_all_leads.php NHHS|http://wwwa.accuweather.com/forecast.asp NSHS|http://wxport.accuweather.com/wxpost/graphic.aspx
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 description Go\\ to\\ www.AmericanHypnosisClinic.com\\ if\\ you'd\\ like\\ to\\ learn\\ more\\ about\\ The\\ American\\ Hypnosis\\ Clinic!
vti_charset:SR|windows-1252
vti_language:SR|en-us
