vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Jan 2007 21:18:15 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TW|21 Jul 2006 15:19:03 -0000
vti_timecreated:TR|01 Mar 2006 18:32:35 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|old_Igor.php Igor10-7-06_backup.php Igor_10-9-06.php Igor1.php Igor_10-26-06.php Igor.php Igor2.php Igor_new.php Igor_10-18-06.php Igor_backup_1-9-07.php
vti_syncwith_localhost\\c\:\\documents and settings\\larry volz\\my documents\\my web sites\\experiments/c\:/documents and settings/larry volz/my documents/my web sites/experiments:TW|01 Mar 2006 22:17:57 -0000
vti_syncwith_localhost\\c\:\\program files\\xampp\\htdocs\\all_clients/c\:/program files/xampp/htdocs/all_clients:TW|09 Mar 2006 21:29:02 -0000
vti_cacheddtm:TX|18 Aug 2006 13:56:45 -0000
vti_filesize:IR|9806
