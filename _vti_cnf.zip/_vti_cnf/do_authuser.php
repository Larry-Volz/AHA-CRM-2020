vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|12 Dec 2006 15:09:19 -0000
vti_timecreated:TR|22 Mar 2006 06:40:39 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|index.htm re-login_page.html index\\ -\\ backup.htm authenticate.htm show_login.htm
vti_nexttolasttimemodified:TW|28 Mar 2006 07:04:57 -0000
vti_cacheddtm:TX|12 Dec 2006 15:09:19 -0000
vti_filesize:IR|6049
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|index2.php
vti_cachedsvcrellinks:VX|FHUS|index2.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=REFRESH 0;URL=index2.php
vti_charset:SR|windows-1252
