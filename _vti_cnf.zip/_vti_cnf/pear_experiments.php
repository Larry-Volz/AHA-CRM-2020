vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:46 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|23 Apr 2006 04:15:22 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|12 Dec 2006 15:09:46 -0000
vti_filesize:IR|214
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
