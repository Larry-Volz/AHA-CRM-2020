vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|12 Dec 2006 15:09:36 -0000
vti_timecreated:TR|18 Apr 2006 18:03:24 -0000
vti_title:SR|AHC Intranet Home
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|19 Apr 2006 21:59:16 -0000
vti_cacheddtm:TX|12 Dec 2006 15:09:36 -0000
vti_filesize:IR|2301
vti_cachedtitle:SR|AHC Intranet Home
vti_cachedbodystyle:SR|<body topmargin="0">
vti_cachedlinkinfo:VX|S|People\\ banner\\ 1.jpg H|mailto:larry@americanhypnosisclinic.com
vti_cachedsvcrellinks:VX|FSUS|People\\ banner\\ 1.jpg NHUS|mailto:larry@americanhypnosisclinic.com
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 description Go\\ to\\ www.AmericanHypnosisClinic.com\\ if\\ you'd\\ like\\ to\\ learn\\ more\\ about\\ The\\ American\\ Hypnosis\\ Clinic!
vti_charset:SR|windows-1252
vti_language:SR|en-us
