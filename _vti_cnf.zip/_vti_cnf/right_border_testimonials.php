vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:48 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|19 Apr 2006 21:42:16 -0000
vti_title:SR|Shared Right Border
vti_backlinkinfo:VX|backup-index.php right_border_testimonials.php index2.php
vti_cacheddtm:TX|12 Dec 2006 15:09:48 -0000
vti_filesize:IR|3513
vti_cachedtitle:SR|Shared Right Border
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|right_border_testimonials.php
vti_cachedsvcrellinks:VX|FHUS|right_border_testimonials.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Page-Enter blendTrans(duration=1.0) HTTP-EQUIV=REFRESH 6;URL=right_border_testimonials.php
vti_charset:SR|windows-1252
