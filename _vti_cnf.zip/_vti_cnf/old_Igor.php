vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:42 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TR|21 Apr 2006 05:57:57 -0000
vti_timecreated:TR|01 Mar 2006 18:32:51 -0000
vti_title:SR|IGOR
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|old_Igor.php
vti_syncwith_localhost\\c\:\\documents and settings\\larry volz\\my documents\\my web sites\\experiments/c\:/documents and settings/larry volz/my documents/my web sites/experiments:TW|01 Mar 2006 23:20:38 -0000
vti_syncwith_localhost\\c\:\\program files\\xampp\\htdocs\\all_clients/c\:/program files/xampp/htdocs/all_clients:TW|22 Mar 2006 07:50:59 -0000
vti_cacheddtm:TX|12 Dec 2006 15:09:42 -0000
vti_filesize:IR|18611
vti_cachedtitle:SR|IGOR
vti_cachedbodystyle:SR|<body onload="document.Igor.program_index.selectedIndex=0" topmargin="1">
vti_cachedlinkinfo:VX|S|Igor_variables.js S|Igor_Walks_Off.htm A|old_Igor.php B|_private/form_results.csv W|_private/form_results.csv
vti_cachedsvcrellinks:VX|FSUS|Igor_variables.js FSUS|Igor_Walks_Off.htm FAUS|old_Igor.php FBUS|_private/form_results.csv
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|true
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_error0:SX|This page contains a FrontPage Save Results component that will not function properly until you publish your FrontPage Web to a server.
vti_error:IX|1
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_hasruntimebots:BR|true
