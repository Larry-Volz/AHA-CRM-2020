vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Oct 2006 20:12:33 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|19 Oct 2006 20:12:33 -0000
vti_cacheddtm:TX|19 Oct 2006 20:12:33 -0000
vti_filesize:IR|29026
vti_cachedtitle:SR|American Hypnosis Clinic
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|client_paperwork/css_for_client_paperwork.css
vti_cachedsvcrellinks:VX|FQUS|client_paperwork/css_for_client_paperwork.css
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_title:SR|American Hypnosis Clinic
vti_backlinkinfo:VX|
