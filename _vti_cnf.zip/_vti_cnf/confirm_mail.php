vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:18 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|11 Oct 2006 20:55:14 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|25 Oct 2006 03:48:25 -0000
vti_cacheddtm:TX|10 Jan 2007 04:11:42 -0000
vti_filesize:IR|11937
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|G|ahc_template.dwt S|acemenu_loader.js S|http://www.americanhypnosisclinic.com/People\\ banner\\ 1.jpg S|ahc_top_menu3.js S|http://www.americanhypnosisclinic.com/images/left_corner.jpg S|http://www.americanhypnosisclinic.com/images/left_side_short.jpg H|index.php S|http://www.americanhypnosisclinic.com/images/left_home_button.jpg H|Quit_Smoking.htm S|http://www.americanhypnosisclinic.com/images/left_QS_button.jpg H|Lose\\ Weight.htm S|http://www.americanhypnosisclinic.com/images/left_weight_button.jpg H|Drug\\ Treatment.htm S|http://www.americanhypnosisclinic.com/images/left_addiction_button.jpg H|Pain.htm S|http://www.americanhypnosisclinic.com/images/left_pain_button.jpg H|Phobias.htm S|http://www.americanhypnosisclinic.com/images/left_fears_button.jpg H|Learning\\ Enhancement.htm S|http://www.americanhypnosisclinic.com/images/left_learn_button.jpg H|Other.htm S|http://www.americanhypnosisclinic.com/images/left_other_button.jpg H|E-mailInquiryForm.php S|http://www.americanhypnosisclinic.com/images/left_button_contact_ust.jpg S|http://www.americanhypnosisclinic.com/images/ahc_te2.gif A|http://lb.bcentral.com/ex/manage/subscriberprefs.aspx H|CBS\\ news\\ 6\\ -\\ 2004.wmv H|CBS\\ news\\ 6\\ -\\ 2004.wmv H|CBS\\ news\\ 6\\ -\\ 2004.wmv H|E-mailInquiryForm.php H|http://www.americanhypnosisclinic.com/links/ThemeIndex.html H|disclaimer.htm H|E-mailInquiryForm.php H|http://www.comedy.hypnosis.ac H|http://www.GoDaddy.com S|http://www.americanhypnosisclinic.com/http://www.google-analytics.com/urchin.js S|http://www.americanhypnosisclinic.com/right_border_testimonials.php
vti_cachedsvcrellinks:VX|NGUS|ahc_template.dwt NSUS|acemenu_loader.js NSHS|http://www.americanhypnosisclinic.com/People\\ banner\\ 1.jpg NSUS|ahc_top_menu3.js NSHS|http://www.americanhypnosisclinic.com/images/left_corner.jpg NSHS|http://www.americanhypnosisclinic.com/images/left_side_short.jpg NHUS|index.php NSHS|http://www.americanhypnosisclinic.com/images/left_home_button.jpg NHUS|Quit_Smoking.htm NSHS|http://www.americanhypnosisclinic.com/images/left_QS_button.jpg NHUS|Lose\\ Weight.htm NSHS|http://www.americanhypnosisclinic.com/images/left_weight_button.jpg NHUS|Drug\\ Treatment.htm NSHS|http://www.americanhypnosisclinic.com/images/left_addiction_button.jpg NHUS|Pain.htm NSHS|http://www.americanhypnosisclinic.com/images/left_pain_button.jpg NHUS|Phobias.htm NSHS|http://www.americanhypnosisclinic.com/images/left_fears_button.jpg NHUS|Learning\\ Enhancement.htm NSHS|http://www.americanhypnosisclinic.com/images/left_learn_button.jpg NHUS|Other.htm NSHS|http://www.americanhypnosisclinic.com/images/left_other_button.jpg NHUS|E-mailInquiryForm.php NSHS|http://www.americanhypnosisclinic.com/images/left_button_contact_ust.jpg NSHS|http://www.americanhypnosisclinic.com/images/ahc_te2.gif NAHS|http://lb.bcentral.com/ex/manage/subscriberprefs.aspx NHUS|CBS\\ news\\ 6\\ -\\ 2004.wmv NHUS|CBS\\ news\\ 6\\ -\\ 2004.wmv NHUS|CBS\\ news\\ 6\\ -\\ 2004.wmv NHUS|E-mailInquiryForm.php NHHS|http://www.americanhypnosisclinic.com/links/ThemeIndex.html NHUS|disclaimer.htm NHUS|E-mailInquiryForm.php NHHS|http://www.comedy.hypnosis.ac NHHS|http://www.GoDaddy.com NSHS|http://www.americanhypnosisclinic.com/http://www.google-analytics.com/urchin.js NSHS|http://www.americanhypnosisclinic.com/right_border_testimonials.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|true
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_error0:SX|A FrontPage Substitution component references substitution parameter "CompanyPhone", but the parameter is not set for the page or Web.
vti_error1:SX|A FrontPage Substitution component references substitution parameter "CompanyLongName", but the parameter is not set for the page or Web.
vti_error:IX|2
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
