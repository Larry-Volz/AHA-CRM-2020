vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2006 15:09:15 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|23 Apr 2006 06:23:37 -0000
vti_title:SR|AHC Intranet
vti_backlinkinfo:VX|
vti_cacheddtm:TX|12 Dec 2006 15:09:15 -0000
vti_filesize:IR|1823
vti_cachedtitle:SR|AHC Intranet
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|F|_borders/top.php F|_borders/left.php F|< S|right_border_testimonials.php
vti_cachedsvcrellinks:VX|FFUS|_borders/top.php FFUS|_borders/left.php DFUS|< FSUS|right_border_testimonials.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_hasframeset:BR|true
