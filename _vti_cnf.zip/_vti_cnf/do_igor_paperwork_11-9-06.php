vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Nov 2006 03:42:21 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|10 Nov 2006 03:42:21 -0000
vti_cacheddtm:TX|10 Nov 2006 03:42:21 -0000
vti_filesize:IR|30372
vti_cachedtitle:SR|American Hypnosis Clinic
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|client_paperwork/css_for_client_paperwork.css
vti_cachedsvcrellinks:VX|FQUS|client_paperwork/css_for_client_paperwork.css
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_title:SR|American Hypnosis Clinic
vti_backlinkinfo:VX|
