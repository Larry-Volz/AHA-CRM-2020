vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Jan 2007 22:34:48 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_createview_edit.php Dbase\\ Admin/all_clients/show_createview.php
