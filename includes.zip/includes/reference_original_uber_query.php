$sql="SELECT 
all_clients.f_name, 
all_clients.middle_initial, 
all_clients.l_name, 
all_clients.referred_by_details,
all_clients.address1, 
all_clients.address2,
all_clients.address3, 
all_clients.postcode, 
all_clients.country, 
all_clients.prim_tel, 
all_clients.sec_tel, 
all_clients.mob_tel, 
all_clients.phone_ext, 
all_clients.email,
all_clients.additional_information, 
all_clients.motivation, 
all_clients.why_us,
FROM_UNIXTIME(all_clients.sales_contact_next,'%M %D %Y') AS contact_next, 
FROM_UNIXTIME(all_clients.date_client_sold,'%M %D %Y') AS date_sold, 
FROM_UNIXTIME(all_clients.first_appointment,'%M %D %Y') AS first_appointment,
FROM_UNIXTIME(all_clients.created,'%M %D %Y') AS created, 
FROM_UNIXTIME(all_clients.modified,'%M %D %Y') AS modified, 

desc_sales_categories.description AS sales_category, 
desc_sales_stage.description AS sales_stage,

auth_users.f_name AS rec_man_f_name, 
auth_users.l_name AS rec_man_l_name,

desc_referred_by.description AS referred_by,  

desc_client_flags.description AS client_flags,

desc_primary_goal.description AS primary_goal, 

affiliates.f_name AS therapist_f_name, 
affiliates.l_name AS therapist_l_name,

desc_action_at_appointment.description AS action


FROM all_clients, desc_sales_categories, desc_sales_stage, auth_users, desc_referred_by, desc_client_flags, desc_primary_goal, affiliates, desc_action_at_appointment

WHERE all_clients.client_id=$client_id 
AND all_clients.sales_category=desc_sales_categories.id 
AND desc_sales_stage.id=all_clients.sales_stage
AND all_clients.record_manager=auth_users.id 
AND all_clients.referred_by=desc_referred_by.id
AND all_clients.client_flags=desc_client_flags.id
AND desc_primary_goal.id=all_clients.primary_goal
AND affiliates.id=all_clients.therapist
AND all_clients.action=desc_action_at_appointment.id";