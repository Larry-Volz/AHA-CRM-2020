<?php
/*
  Class Mysql
  Created by : Varga Sergiu
  Date: 20.05.2003
  Descriere;  Acesta clasa invaluie principalele functionalitati ale gestionarii bazei de date Mysql utilizand PHP

  Nota : Incepand cu versiunea Mysql 4.1 este posibil select in select

  */


 $DB_HOST ="localhost";
 $DB_USER = "america2_AHC";
 $DB_PASS="magiclar";
 $DATABASE="america2_AHC";

 class class_mysql{

  var $queryid = "";
  var $selectid = "";
  var $updateid = "";
  var $insertid = "";
  var $result = array();

  function db_con(){
        //$db=@mysql_connect($dbhost, $loginname, $loginpass)
        GLOBAL $DB_HOST, $DB_USER, $DB_PASS ,$DATABASE;
        $db=@mysql_connect($DB_HOST, $DB_USER, $DB_PASS)
         or die ("Conexiune esuata: ".mysql_error());
        mysql_select_db($DATABASE) or die ("Baza de date nu poate fi selectata: ".mysql_error());
    return $db;
  }

  function query($sql){
    if($this->queryid = mysql_query($sql,$this->db_con())){
     return TRUE;
    }else{
     echo $this->getError("Eroare Mysql.");
    }
  }

  function select($sql){
    if($this->selectid = mysql_query($sql,$this->db_con())){
     return TRUE;
    }else{
     echo $this->getError("Eroare Mysql.");
    }
  }

  function insert($sql){
    if($this->insertid = mysql_query($sql,$this->db_con())){
     return TRUE;
    }else{
     echo $this->getError("Eroare Mysql.");
    }
  }

  function update($sql){
    if($this->updateid = mysql_query($sql,$this->db_con())){
     return TRUE;
    }else{
     echo $this->getError("Eroare Mysql.");
    }
  }

  function getRecords(){
    return @mysql_num_rows($this->selectid);
  }

  function getLastInsertID(){
    return mysql_insert_id();
  }

  function dataSeek($pos){
    return mysql_data_seek($this->selectid,$pos);
  }

  function fetchArray(){
    $this->result = @mysql_fetch_array($this->selectid, MYSQL_BOTH);
    return $this->result;
  }

   function getFields(){
    $this->result = @mysql_num_fields($this->selectid);
    return $this->result;
  }


   function fetchField(){
    $this->result = @mysql_fetch_field($this->selectid);
    return $this->result;
  }

  function fetchRow(){
    $this->result = @mysql_fetch_row($this->selectid);
    return $this->result;
  }

  function emptyResult(){
    return mysql_fetch_row($this->selectid);
  }

  function getError($msg){
    return "<br />S-a detectat o eroare: <br />".$msg."<br />Eroare Mysql: ".mysql_error()."<br />";
  }
}
?>
