<?

Global $LeadsPrintBlock;

//Get my class and methods
//include_once("../ahcDatabase_class.php");//drop the ../ if in root directory

//connect to db
$ahcDB->dbConnect();


// create function to count # of leads over a beginning and end date

function countNewLeads($start_date,$end_date){
	

	$db_name="america2_AHC";
	$table_name="new_leads";
	
	//$connection = mysql_connect("localhost","america2_AHC","magiclar");// or die (mysql_error())
	$connection = mysql_connect("localhost", "america2_AHC", "magiclar");
	
	// create var to hold the result of select db function
	$db = mysql_select_db($db_name, $connection);// or die (mysql_error())
	
	//--------------------------- COUNT Leads QUERY -----------------------------
	
	$sql = "SELECT count(id) FROM $table_name WHERE time_stamp > $start_date AND time_stamp <= $end_date";
	$result=mysql_query($sql,$connection);// or die(mysql_error())
	
	$count_new_leads = mysql_result($result,0,"count(id)");// or die(mysql_error())

	
	return $count_new_leads;

}//end function

//-------------------------------END countNewLeads------------------------------------



 /* 
//create function to create output of table of leads over beginning and end date with links to their details page
 
if (!$end_date){
  $end_date=time();
}

function displayNewLeads($start_date,$end_date) {
  
  }
  
  

   
//CREATE TABLE WITH tableHelpers.php
//TABLE HELPER include file
require_once('../../FORMfields/tableHelpers.php');

//instantiate class
    $leads_table = new TableSet();
    $leads_table->enableSort = true;
  
    $leads_table->loadQuery("SELECT CONCAT('<a href=\"show_one_lead.php?id=',id,'\">','View','</a>') AS 'View',f_name AS 'First Name',l_name AS 'Last Name',primary_goal AS 'Primary Goal', day_phone AS 'Phone', alt_phone AS 'Alt Phone',CONCAT('<a href=\"mailto:',email,'\">',email,'</a>') AS 'e-Mail', city AS 'City', state AS 'State', zip AS 'Zip' FROM new_leads WHERE time_stamp > '$start_date' AND time_stamp < '$end_date' ORDER BY l_name");
 
 
 $leads_table->loadQuery("SELECT f_name FROM new_leads WHERE time_stamp > $start_date AND time_stamp < $end_date ORDER BY l_name"); 

 
 
 
 
  $return $leads_table;
}
 */
?>

<html>
<head>
<title></title>



</head>
<body>




</body>
</html>