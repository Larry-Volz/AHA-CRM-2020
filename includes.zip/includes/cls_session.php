<?php

/*
 Clasa utila pentru gestionarea sesiunilor.
 Prezinta compatibilitatea cu versiunile mai vechi din PHP ( < 4.0.6  ) prin cod separat pt  variabilele
 globale respectiv superglobale .
 Foloseste un tablou separat in care sunt copiate variabilele sesiune.

 Metode:

 get()
 set()
 del()
 del_all()
 array_copy()
 set_expire_time()
 get_expire_time()
 sess_destroy()


*/

class MYSession {

        var $MY_SESSION_ARRAY = array();
        var $session_state = 0;

        function MYSession ()
        {
                 $session_state = session_start ();

                 if(!$session_state)
                        return 0;
                 else
                 {
                        if (!empty($_SESSION))
                        {
                                //$this->MY_SESSION_ARRAY =$this->array_copy($_SESSION);
                                $this->MY_SESSION_ARRAY = $_SESSION;
                        }
                        else
                        {
                                global $HTTP_SESSION_VARS;
                                if (!empty($HTTP_SESSION_VARS))
                                {
                                        $this->MY_SESSION_ARRAY = $HTTP_SESSION_VARS;
                                }
                        }
                }
        }// metoda Mysession
        //*********************

        function get($name="")
        {

                if ( $name=="")   return "";
                else
                {
                        if( ( !is_array($this->MY_SESSION_ARRAY) ) || ( (string)$this->MY_SESSION_ARRAY[$name]=="" )  )
                                return "";
                        else
                           return $this->MY_SESSION_ARRAY[$name];
                }
        }// metoda get
        //************************

    //    if(empty($this->MY_SESSION_ARRAY) || !isset($this->MY_SESSION_ARRAY[$name]))


        function set($name,$value)
        {
                if(empty($name))
                        return "";
                else
                {
                        $this->MY_SESSION_ARRAY[$name]=$value;
                        if(version_compare("4.0.6", phpversion(), "<="))
                        {
                                global $HTTP_SESSION_VARS;
                                $HTTP_SESSION_VARS[$name]=$value;
                        }
                        else
                          $_SESSION[$name]=$value;
                }
        }// metoda set
        //******************
        function del($name)
        {
                if(empty($name) || empty($this->MY_SESSION_ARRAY[$name]))
                        return "";
                else
                {
                        unset($this->MY_SESSION_ARRAY[$name]);
                        if(version_compare("4.0.6", phpversion(), "<="))
                        {
                                global $HTTP_SESSION_VARS;
                                unset($HTTP_SESSION_VARS[$name]);
                        }
                        else
                                unset($_SESSION[$name]);
                }
        }// metoda del
        //****************

        function del_all()
        {
                $this->MY_SESSION_ARRAY=array();
                if(version_compare("4.0.6", phpversion(), "<="))
                {
                        global $HTTP_SESSION_VARS;
                        $HTTP_SESSION_VARS=array();
                }
                else
                        $_SESSION=array();
        }// metoda del_all
        //*************************

        function array_copy($array)
        {
                $newarray= array();
                foreach ($array as $key => $value)
                {
                        $newarray[$key]=$value;
                }
                return  $newarray;
        }// metoda array_copy



         function set_expire_time($sec)
        {
          $expire_time=time()+$sec;
          $this->MY_SESSION_ARRAY["EXPIRE"]=$expire_time;
                        if(version_compare("4.0.6", phpversion(), "<="))
                        {
                                global $HTTP_SESSION_VARS;
                                $HTTP_SESSION_VARS["EXPIRE"]=$expire_time;
                        }
                        else
                          $_SESSION["EXPIRE"]=$expire_time;
        }
        /* metoda set_expire_time --- metoda care seteaza  o variabila sesiune EXPIRE cu o valoare de $sec secunde
         , care poate fi folosita pentru atentificare --- de exeplu in pagina de validare pt membrii ---
        */

        function get_expire_time($name= "EXPIRE")
        {
                if(empty($name))
                          return "";
                else
                {
                        if(empty($this->MY_SESSION_ARRAY) || empty($this->MY_SESSION_ARRAY[$name]))
                                return "";
                        else
                           return $this->MY_SESSION_ARRAY[$name];
                }

        }
        // metoda get_expire_time  - metoda care afiseaza continutul variabilei EXPIRE setata anterior cu set_expire_time()




        function sess_destroy()
        {
                $this->MY_SESSION_ARRAY=array();
                session_destroy();
        }// function sess_destroy

          //  metoda ce distruge sesiunea , precum si tabloul MY_SESSION_ARRAY , ce contine valoarea variabilelor sesiune

         function appendSID($url){
                $sid = "";
                $sess_id=session_name()."=".session_id();
                $sep="";
                if(strlen($sess_id)){

                        if(strpos($url, "?") >0)
                                $sep = "&";
                        else
                                $sep = "?";

                        $sid = $sep.$sess_id;

                }
                return $url.$sid;
        }


       function regenerate_id()
       {
          if(version_compare("4.3.2", phpversion(), "<="))
          {
            session_regenerate_id();
          }
          else
           {
             $arr1=array();
             $arr2=array();
             global $HTTP_SESSION_VARS;
             @$arr1=$_SESSION;
             $arr2==$HTTP_SESSION_VARS;
             session_destroy();

             $passwordChars = '0123456789'.
                  'abcdefghijklmnopqrstuvwxyz';
             $password = "";
             $passwordLength=rand(35,40);
             for ($index = 1; $index <= $passwordLength; $index++)
              {
               // pick random number
               $randomNumber = rand(1,strlen($passwordChars));
               $password .= substr($passwordChars,$randomNumber-1,1);
             }
             session_id($password);
             session_start();
             @${"_SESSION"}=$arr1;
             ${"HTTP_SESSION_VARS"}=$arr2;

           }
       }
       // asociaza toate variabilele din sesiune unui nou session_id


}// end class


/*  Exemplu de functionare

$sess = new MYSession();
                //session_regenerate_id();
                if (!$sess->get(SESSION_ID))
                {
                        $sess->set('url1','test.php');      t
                        header("Location: login.php");
                        exit;
                }
-------------------------------------------------

cod util pt verificarea expirarii logarii curente
if ( $sess->get_expire_time()<time() ) { echo "Expirare<br>"; $sess->sess_destroy(); }


-------------------------------------------------

                */



?>
