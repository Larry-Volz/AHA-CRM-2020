<?
/*

include_once("includes/time_travel.php");

timeSinceMonday()
RETURNS THE NUMBER OF SECONDS ELAPSED SINCE THE MOST RECENT MONDAY SO YOU CAN CALCULATE WHATEVER THIS WEEK
call by $time_elapsed = $time_travel->timeSinceMonday();

timeElapsedToday()
RETURNS THE NUMBER OF SECONDS ELAPSED SINCE MIDNIGHT TODAY
call by $time_elapsed = $time_travel->timeElapsedToday();

TodayMonthSelectBox($box_name)
RETURNS A SELECT BOX WITH TODAY'S Month AT THE DEFAULT'
call by $output = $time_travel->TodayMonthSelectBox($box_name)
returns a select box with the cgi variable name $box_name_month

TodayDaySelectBox($box_name)
RETURNS A SELECT BOX WITH TODAY'S DAY AT THE DEFAULT'
call by $output = $time_travel->TodayDaySelectBox($box_name)
returns a select box with the cgi variable name $box_name_day

TodayYearSelectBox($box_name)
RETURNS A SELECT BOX WITH TODAY'S Month AT THE DEFAULT'
call by $output = $time_travel->TodayYearSelectBox($box_name)
returns a select box with the cgi variable name $box_name_year

*/

class time_functions{
  
	function timeSinceMonday()  {
// RETURNS THE NUMBER OF SECONDS ELAPSED SINCE THE MOST RECENT MONDAY SO YOU CAN CALCULATE WHATEVER THIS WEEK	  
	 
		$now=time();
		
		//get day of week and hour of the day		
		$day = date("w", $now);	//day of week from 0 = sunday to 6=saturday
		$hour = date("G", $now);
		$minutes = date("i", $now);
		  
		//subtract 1 from weekday to see how many days since monday*
		
		$days_elapsed=$day-1;
		
		//multiply # of days difference by 60*60*24 to get seconds elapsed
		$seconds_elapsed=$days_elapsed*60*60*24 ;
		
		//add number of hours since midnight
		
		$seconds_elapsed += $hour*60*60 + $minutes;
		
		//take total days + hours elapsed from monday to get time elapsed since monday
		  
RETURN $seconds_elapsed;
	  
	}//end timeSinceMonday ---------------------------------------------------------------------------------------
	

//################################################################################################################	


	function timeElapsedToday()  {
	  
	// RETURNS THE NUMBER OF SECONDS ELAPSED SINCE MIDNIGHT TODAY	  
	 
		$now=time();
		
		//get date for today		
		$today = date("j", $now);	//day of week from 0 = sunday to 6=saturday
		$month = date("n", $now);
		$year = date("Y", $now);
		  
		//create todays timestamp from date but starting at midnight
		$today_midnight = mktime(0,0,0,$month,$today,$year);
		//subtract midnight from now for new time elapsed
		$seconds_elapsed=$now-$today_midnight;
		
		  
RETURN $seconds_elapsed;
	  
	}//end timeElapsedToday()---------------------------------------------------------------------------------------	
  
//------------------------------------------------------------------------------------------------------------------  
  
  

//######################## TodayMonthSelectBox()) ##############################################

function TodayMonthSelectBox($box_name){

$month_name = array('','January','February','March','April','May','June','July','August','September','October','November','December');

			$todays_month = date("n");

$charge_month_select = "<select name=\"{$box_name}_month\">";
      		
for ($i=1; $i<13; $i++)
	{
	  
		$charge_month_select .= "<option value=\"$i\"";

			IF ($i == $todays_month){
	  
			  $charge_month_select .= " selected";
			  
			}//end of IF statement

		$charge_month_select .= ">{$month_name[$i]}</option>";

	  
		}//end for statement
        		
 $charge_month_select .= "</select>";   
 return $charge_month_select;    	
 
 }//end today's month select box ----------------------------------------------------------------------------------	


function TodayDaySelectBox($box_name){
//CREATE DATA-SELECTED HTML SELECT BOX FOR CHARGE DATE DAY - TODAY IS DEFAULT

			$now=time();
			$day = date("j", $now);

$charge_day_select="<select name=\"{$box_name}_day\"><option value=\"\">Day</option>";

		//for days 1 through 31...
		for ($i = 1; $i < 32; $i++){
		  
				$charge_day_select .= "<option value=\"$i\"";
				
				if ($i==$day){
				  
				  $charge_day_select .=" selected";				  
				}//end inner comparison if statement
								
				$charge_day_select .= ">$i</option>";
		   
		}//end if statement

$charge_day_select .= "</select>";
RETURN $charge_day_select;

}//end TodayDaySelect ------------------------------------------------------------------------------------------------

function TodayYearSelectBox($box_name){
//CREATE DATA-SELECTED HTML SELECT BOX FOR CHARGE DATE YEAR

			$now=time();
			$year = date("Y", $now);
			
$charge_year_select="<select name=\"{$box_name}_year\">";

		//for 2006 thru 2020...
		for ($i = 2006; $i < 2021; $i++){
		  
				$charge_year_select .= "<option value=\"$i\"";
				
				if ($i==$year){
				  
				  $charge_year_select .=" selected";				  
				}//end inner comparison if statement
								
				$charge_year_select .= ">$i</option>";
		   
		}//end if statement
		
$charge_year_select .= "</select>";
RETURN $charge_year_select;

}//end TodayYearSelectBox()

//--------------------------------------------------------------------------------------------------  

  
//======================================== end class definition ===================================
}// end class definition

//instantiate object
$time_travel = NEW time_functions();
?>