<?

//EXPERIMENT:  USE AN INCLUDE FILE OF PHP WITHOUT USING A FUNCTION - SO i CAN USE ALL THE VARIABLES







function allHisVars($client_id){

//GETS ALL VARIABLES FOR THIS ONE CLIENT AND RETURNS THEM AS GLOBALS



//connect if needed

   global $db_name,$connection,$db;



    $db_name = "america2_AHC";



        //open the SQL connection to AHC server databases

       // $connection = mysql_connect("localhost","america2_larryvo","magiclar");// or die (mysql_error())
        $connection = mysql_connect("localhost", "america2_AHC", "magiclar");



        // SELECT DB - create var to hold the result of select db function

        $db = mysql_select_db($db_name, $connection);// or die (mysql_error())



//Make all variables global so they can be used outside of function

Global $client_f_name, $client_middle_initial, $client_l_name, $sales_category, $sales_stage, $contact_next, $date_sold,

$rec_man_f_name, $rec_man_l_name, $referred_by, $referred_by_details, $client_flags, $address1, $address2, $address3, $postcode, $country, $prim_tel, $sec_tel, $mob_tel, $phone_ext, $primary_goal, $additional_information,$first_appointment, $therapist_f_name, $therapist_l_name, $action, $created, $modified, $motivation, $why_us;







//Create the UBER-query!!! - using joins or where id= id and gets them all in a READABLE FORMAT...

//only things missing from uber-query are secondary goal, modified by and created by

//because already using that variable from auth_users and desc_primary_goal.

//Can't use them in a single-table-helper query but can get the number using * or use a specific query for them.

// USE SELECT * FROM all_clients for all variables in MODIFIABLE FORMAT!!!



//THE UBER-QUERY (copy these)

$sql="SELECT

all_clients.f_name,

all_clients.middle_initial,

all_clients.l_name,

desc_sales_categories.description AS sales_category,

desc_sales_stage.description AS sales_stage,

FROM_UNIXTIME(all_clients.sales_contact_next,'%M %D %Y') AS contact_next,

FROM_UNIXTIME(all_clients.date_client_sold,'%M %D %Y') AS date_sold,

auth_users.f_name AS rec_man_f_name,

auth_users.l_name AS rec_man_l_name,

desc_referred_by.description AS referred_by,

all_clients.referred_by_details,

desc_client_flags.description AS client_flags,

all_clients.address1,

all_clients.address2,

all_clients.address3,

all_clients.postcode,

all_clients.country,

all_clients.prim_tel,

all_clients.sec_tel,

all_clients.mob_tel,

all_clients.phone_ext,

desc_primary_goal.description AS primary_goal,

all_clients.additional_information,

FROM_UNIXTIME(all_clients.first_appointment,'%M %D %Y') AS first_appointment,

affiliates.f_name AS therapist_f_name,

affiliates.l_name AS therapist_l_name,

desc_action_at_appointment.description AS action,

FROM_UNIXTIME(all_clients.created,'%M %D %Y') AS created,

FROM_UNIXTIME(all_clients.modified,'%M %D %Y') AS modified,

all_clients.motivation,

all_clients.why_us



FROM all_clients, desc_sales_categories, desc_sales_stage, auth_users, desc_referred_by, desc_client_flags, desc_primary_goal, affiliates, desc_action_at_appointment



WHERE all_clients.client_id=$client_id

AND all_clients.sales_category=desc_sales_categories.id

AND desc_sales_stage.id=all_clients.sales_stage

AND all_clients.record_manager=auth_users.id

AND all_clients.referred_by=desc_referred_by.id

AND all_clients.client_flags=desc_client_flags.id

AND desc_primary_goal.id=all_clients.primary_goal

AND affiliates.id=all_clients.therapist

AND all_clients.action=desc_action_at_appointment.id";





//FOR MODIFYING:

//$sql="SELECT * FROM all_clients;//ORDER BY whatever





//FORMAT FOR METHODIZING

//SELECT X.X,Y.Y AS qrs

//FROM x,y

//WHERE X.X=Y.Y

//AND Y.Y=Z.Z





        $result = mysql_query($sql) ;// or die(mysql_error())

                        while ($row = mysql_fetch_array($result)){



                          $client_f_name=$row['f_name'];

                          $client_l_name=$row['l_name'];

                          $client_middle_initial=$row['middle_initial'];

                          $sales_category=$row['sales_category'];

                          $sales_stage=$row['sales_stage'];

                          $contact_next=$row['contact_next'];

                          $date_sold=$row['date_sold'];

                          $rec_man_l_name=$row['rec_man_l_name'];

                          $rec_man_f_name=$row['rec_man_f_name'];

                          $referred_by=$row['referred_by'];

                          $referred_by_details=$row['referred_by_details'];

                          $client_flags=$row['client_flags'];

                          $address1=$row['address1'];

                          $address2=$row['address2'];

                          $address3=$row['address3'];

                          $postcode=$row['postcode'];

                          $country=$row['country'];

                          $prim_tel=$row['prim_tel'];

                          $sec_tel=$row['sec_tel'];

                          $mob_tel=$row['mob_tel'];

                          $phone_ext=$row['phone_ext'];

                          $primary_goal=$row['primary_goal'];

                          $additional_information=$row['additional_information'];

                          $first_appointment=$row['first_appointment'];

                          $therapist_f_name=$row['therapist_f_name'];

                          $therapist_l_name=$row['therapist_l_name'];

                          $action=$row['action'];

                          $created=$row['created'];

                          $modified=$row['modified'];

                          $motivation=$row['motivation'];

                          $why_us=$row['why_us'];





                          }//end of While loop



//        echo "$client_f_name, $client_l_name, $client_middle_initial, $sales_category";



}//------------------------------------- end of allHisVars($client_id)-------------------------------------



?>