<?

function meta_redirect($url,$sec)
{
        echo("<META HTTP-EQUIV=\"Refresh\" CONTENT=\"$sec; url=$url\">");

}

function GenerateFilename($name,$extension)
{
  //function to generate file name
  srand((double)microtime()*1000000);
  $randvalue = rand(1000,1000000);
  return $name."_".$randvalue.".$extension";

}

function CreateHtmlFile($filename,$content)
{
 ob_start();
 $fp = fopen ($filename, "w");
 fwrite($fp, $content);
 fclose($fp);
 ob_end_clean();
}

function is_email($email)
        {
          $fail = 0;
          // Shift the address to lowercase to simplify checking
          $email = strtolower($email);

          // Split the Address into user and domain parts
          $UD = explode("@", $email);
          if (sizeof($UD) != 2) $fail = 1;    #meer dan 1 @ in emailadres

          // Split the domain part into its Levels
          $Levels = explode(".", $UD[1]); $sLevels = sizeof($Levels);
          if ($sLevels < 2) $fail = 1;    #minder dan 1 . achter @

          // Get the TLD, strip off trailing ] } ) > and check the length
          $tld = $Levels[$sLevels-1];
          $tld = ereg_replace("[>)}]$|]$", "", $tld);
          if (strlen($tld) < 2 || strlen($tld) > 3 && $tld != "arpa") $fail = 1;    #2 of 3 chars voor TLD (of TLD moet arpa zijn)

          if ($fail==0) {return true;}
          else {return false;}
        }

function RandomCode() {

 $passwordChars = '0123456789'.
                  '0123456789'.
                  'abcdefghijklmnopqrstuvwxyz';
 $password = "";
 $passwordLength=rand(12,17);
 for ($index = 1; $index <= $passwordLength; $index++) {

   // pick random number
   $randomNumber = rand(1,strlen($passwordChars));

   $password .= substr($passwordChars,$randomNumber-1,1);
 }

 return strtolower($password);

}


        function formatUserInputText( $text, $maxLineLength = 255 ) {

                // Splitting the very long words (ex. line with no spaces)
                $currLength = 0;
                $result = "";
             //   $text=trim($test);
                for ($i = 0; $i < strlen($text); $i++) {
                 $char = substr($text,$i,1);
                 if ($char != " ") $currLength++;
                 else $currLength = 0;
                 if ($currLength == $maxLineLength){
                         $currLength = 0;
                         $result .= " ";
                 }
                 $result .= $char;
                }
                $text = $result;

                // Replacing critical symbols with their HTML equivalent
                $text = str_replace("<", "&lt;", $text);
                $text = str_replace(">", "&gt;", $text);
                $text = str_replace('"', "&quot;", $text);
                $text = str_replace("'", "&#039;", $text);
                $text = str_replace("  "," &nbsp;",$text);
                $text = nl2br($text);

                return($text);
        }



        function unformatUserInputText( $text )
          {

                  $text = str_replace("&lt;", "<", $text);
                  $text = str_replace("&gt;", ">", $text);
                  $text = str_replace(" &nbsp;","  ",$text);
                  $text = str_replace("<br />","",$text);
                  $text = str_replace('&quot;', '"', $text);

                  return($text);
          }

         function  duplicate_view_name($name,$table)
         {
          GLOBAL $cdb1;
          $sql="select viewName from  $table";
          $cdb1->select($sql);
          while( $line=$cdb1->FetchArray() )
          {
          if ($line[0] == "$name") return true;
          }

          return false;

         }

         function message_box($text)
         {
         $str="<center><br><br>";
         $str.="<table cellpadding='10' cellspacing='0' style='border: 1px #000000 solid; font-family: Verdana; font-size: 12px; color: red;'>";
         $str.="<tr><td>$text</td></tr>";
         $str.="</table>";
         echo $str;

         }

 function GetViewPerms($idview,$view_sql_table)

 {
   GLOBAL $cdb_view1;

   if (empty($idview)) exit;
   if  ($_SESSION['user_type']=="god") return true;
   $sql=" select view_perms, user_id from $view_sql_table where id=$idview ";
   $cdb_view1->select($sql);
   $perm=$cdb_view1->FetchArray();

//   echo    strtolower($perms['view_perms']);
//   echo   "<pre>";
//   print_r($perm);
//   echo "</pre>";

   switch ( strtolower($perm['view_perms']) )
   {

     case "just me":
                                 if  ( $_SESSION['user_id'] == $perms['user_id'] )
                                 return true;
                                 break;
     case "program counselors":

                                 if ( ($_SESSION['user_id'] == $perms['user_id'] ) || ( $_SESSION['user_type'] == "pc" ) )
                                 return true;
                                 break;

     case "management":

                                 if ( ($_SESSION['user_id'] == $perms['user_id'] ) || ( $_SESSION['user_type'] == "god" ) )

                                 return true;

                                 break;

     case "administration":

                                 if ( ($_SESSION['user_id'] == $perms['user_id'] ) || ( $_SESSION['user_type'] == "admin" ) )

                                 return true;

                                 break;
     case "everyone":

                                 return true;

                                 break;
   }

   return false;



 }



        function  IsValidPassword($pass)
          {
             $passwordChars = '0123456789'.'abcdefghijklmnopqrstuvwxyz';

             if(strlen($pass)<4) return false;
             if(strlen($pass)>12) return false;
             for  ($i=0;$i<strlen($pass);$i++)
             if ( strpos($passwordChars,$pass[$i])===false )  return false ;
             return true;
          }






?>