<?
//will define $acIncludes as primary object from this class at end of script...

//Include this file with require_once('../../includes/classes_all_clients.php');

//CONNECT TO MAIN AHC DATABASE. (line 15 ish)
//CALL BY:   require_once('../../includes/classes_all_clients.php'); $acIncludes->dbConnect();
//Or... all_clients_functions::dbConnect();

//CHECK BASIC SECURITY (line 41 ish)(use ahcDatabase_class.php for more serious security and log-ins).
// CALL BY:   require_once('../../includes/classes_all_clients.php'); $acIncludes->securityCheckBasic();

//DO A QUERY. (line 66 ish) CALL BY:   require_once('../../includes/classes_all_clients.php'); $acIncludes->doQuery($sql);

//RETRIEVE ANY one VARIABLE FROM a TABLE AND ASSIGN it TO A php VARIABLE (line 90 ish)
//CALL BY:  require_once('../../includes/classes_all_clients.php'); $variable = $acIncludes->getVar($table_name,$id,$fieldName);
//example:  $description = $acIncludes->getVar('desc_whatever',$id,$desc);

//POPULATE A DROP-DOWN (SELECT) LIST FOR ANY DESCRIPTIONS (line 133 ish)
//CALL BY: require_once('../../includes/classes_all_clients.php'); $acIncludes->dropDownEcho($desc_table,$select_box_name);

//POPULATE HTML SELECT LIST FOR ANY desc TABLE WHERE 1 IS SELECTED (MODIFY) (line 165 ish)
//CALL BY: require_once('../../includes/classes_all_clients.php'); $print_block=$acIncludes->dropDownModify($desc_table,$select_box_name,$client_id,$desc_field_name);
//note:  assumes that database has already been opened

//Write name & client id# to session (line 233 ish)
//Call by require_once('../../includes/classes_all_clients.php'); $acIncludes->writeClientToSession($client_id,$f_name,$l_name);

//Get name & client id# from session (line 248 ish)
//Call by require_once('../../includes/classes_all_clients.php'); $acIncludes->readClientFromSession();

//GET ALL CLIENT VARIABLES AND DESCRIPTIONS SUITABLE FOR DISPLAY
//CALL BY $acIncludes->getAllVariables($client_id);
//variables are all listed in $globals within function (line 290 ish)

//populate a state drop-down box and click previous value


//unset session variables (write later if needed...)


 class all_clients_functions {


//##############################################################################################
//#                 METHOD TO CONNECTS TO MAIN AHC DATABASE.  CALL BY:   $acIncludes->dbConnect();             #
//#                 Or... all_clients_functions::dbConnect();                                                                                           #
//##############################################################################################

  function dbConnect(){
    global $db_name,$connection,$db;

    $db_name = "america2_AHC";

        //open the SQL connection to AHC server databases
        //$connection = mysql_connect("localhost","america2_larryvo","magiclar");// or die (mysql_error())
        $connection = mysql_connect("mysql209.secureserver.net","america2_AHC","magiclar");

        // SELECT DB - create var to hold the result of select db function
        $db = mysql_select_db($db_name, $connection);// or die (mysql_error())
        return $db;

}//======================================== END  METHOD ===========================================




//#######################################################################################
//#         FUNCTION TO CHECK BASIC SECURITY.  CALL BY:   $acIncludes->securityCheckBasic();   #
//#######################################################################################

  function securityCheckBasic(){

GLOBAL $user_id;

session_start();

$auth = $_SESSION[auth];
$permission = $_SESSION[permission];
$f_name=$_SESSION[f_name];
$user_id=$_SESSION[user];

IF ($auth !="ok"){
        header ("Location: http://www.americanhypnosisclinic.com/intranet/index.htm");
        exit;
}

//------------------------------ end security check --------------------------


}//======================================== END  METHOD ===========================================

//###########################################################################################
//#                                 METHOD TO DO A QUERY.  CALL BY:   $acIncludes->doQuery($sql);                          #
//###########################################################################################

  function doQuery($sql){

    // $sql is the string containing the query to do

    //execute the sql statement and create a variable you can use to display or work with it
    // performs query (UPDATE,INSERT,SELECT OR DELETE)

        $result = mysql_query($sql);// or die(mysql_error())

        //returns reciept of query
        return $result;

}//=========================== END PERFORM QUERY METHOD =================================


//########################################################################################
//#                                         METHOD TO RETRIEVE A VARIABLE FROM TABLE                                                          #
//#                                         AND ASSIGNS THEM TO A php VARIABLE                                                                   #
//#    CALL BY:   $variable = $acIncludes->getVar($table_name,$id,$fieldName);                    #
//#    example:  $description = $acIncludes->getVar('desc_whatever',$id,$desc)                         #
//########################################################################################

        function getVar($table_name,$id,$fieldName){

                        //DO QUERY TO RETRIEVE ALL VARIABLES FOR PERSON # $ID
                          $sql = "SELECT * FROM $table_name WHERE id = '$id'";
                        $result = mysql_query($sql) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
        while ($row = mysql_fetch_array($result)){

                        $variable = $row[$fieldName];

           }//close while loop that assigns values from fetch_array

return $variable;

}//end function

//-------------------------------------- END GET VARIABLE -------------------------------------------


//###################################################################################################
//#             METHOD TO POPULATE A DROP-DOWN (SELECT) LIST FOR ANY DESCRIPTIONS                                     #
//#          CALL BY: $acIncludes->dropDownEcho($desc_table,$select_box_name);                                                         #
//###################################################################################################
//#                                                                                                                                                                                                        #
//# Strategy:  (for all_clients only) Start with $client_idname of description table ($desc_table)  #
//#                                                                                                                                                                                                        #
//###################################################################################################

function dropDownEcho($desc_table,$select_box_name){
//EXAMPLE:
//$desc_table="desc_primary_goal";
//$select_box_name="primary_goal";

         $output="<select name = \"".$select_box_name."\">";

        //get all descriptions
        $query1 = "SELECT * FROM $desc_table";
        $results1 = mysql_query($query1);// or die(mysql_error())

                //start looping through descriptions one by one
                while ($descriptions = mysql_fetch_array($results1)){

                          $id = $descriptions['id'];
                          $desc = $descriptions['description'];

                                  $output .= "<option value = \"".$id."\"";

                                  if ($id="0"){

                                    $output .= " selected";

                                  }

                  $output .=">".$desc."</option>";
                  }//end while

        $output .= "</select>";

  return $output;

}//end function definition

################################ END dropDownSelected DEFINITION ####################################


//######################################################################################################
//#                                                                                                                                                                                                           #
//#   METHOD TO POPULATE HTML SELECT LIST FOR ANY desc TABLE WHERE 1 IS SELECTED (MODIFY)                           #
//# CALL BY:                                                                                                                                                                                    #
//# $print_block=$acIncludes->dropDownModify($desc_table,$select_box_name,$client_id,$desc_field_name);#
//#  note:  assumes that database has already been opened                                                                                           #
//######################################################################################################

// Strategy:  (for all_clients only) Start with $client_idname of description table ($desc_table),

//######################################################################################################

function dropDownModify($desc_table,$select_box_name,$client_id,$desc_field_name){
//EXAMPLE:
//$desc_table="desc_primary_goal";
//$select_box_name="secondary_goal_choice";
//$client_id="123498";
//$desc_field_name="secondary_goal";

//GLOBAL $msg;//testing???????????????????????

         $output="<select name = \"".$select_box_name."\">";

         //Get the previous choice from the field in question
         $sql = "SELECT $desc_field_name FROM all_clients WHERE client_id='$client_id'";
         $results2=mysql_query($sql) ;// or die(mysql_error())or die if can't figure out problems...'

                             while ($choice = mysql_fetch_array($results2)){
                                $choice_id = $choice[$desc_field_name];
                                        if (!isset($choice_id)){
                                          $choice_id=0;
                                        }//end if-to-take-care-of-nulls
                                //$msg="\$choice_id=\$choice[\$desc_field_name] yielded $choice_id<br>";//testing?????????????????????
                        }//end while loop

        //get all descriptions
        $query1 = "SELECT * FROM $desc_table";
        $results1 = mysql_query($query1);// or die(mysql_error())

                //start looping through descriptions one by one
                while ($descriptions = mysql_fetch_array($results1)){

                          $id = $descriptions['id'];
                          $desc = $descriptions['description'];

                                  $output .= "<option value = \"".$id."\"";

                                        if ($choice_id == $id){//if this choice is one of those selected...
                                        //        $msg .= "\$choice_id = $choice_id and \$id = $id -> Match!<br><br>"; //testing??????????????

                                                          $output .= " selected";

                                                }//end of if statement


                                          $output .= ">".$desc."</option>";

                  }//end OUTER while loop

        $output .= "</select>";

  return $output;

}//end function definition

################################ END dropDownSelected DEFINITION ####################################




//########################### Write name & client id# to session ###################################
//Call by $acIncludes->writeClientToSession($client_id,$f_name,$l_name);

function writeClientToSession($client_id,$f_name,$l_name){
//session_start();//if not already open

$_SESSION[client_id]=$client_id;//assuming that has been defined.  If not - define it!
$_SESSION[client_f_name]=$f_name;
$_SESSION[client_l_name]=$l_name;

}//end function to write name/id to session

//--------------------------------------- end writeClientToSession(); ---------------------------------



//########################### Read name & client id# from session ###################################
//Call by $acIncludes->readClientFromSession();

function readClientFromSession(){
session_start();//if not already open

Global $client_id,$f_name,$l_name;

if (isset($_SESSION[client_id])){

        $client_id = $_SESSION[client_id];//assuming that has been defined.  If not - define it!
        $f_name=$_SESSION[client_f_name];
        $l_name=$_SESSION[client_l_name];

        }
}//end function to read name/id from session

//--------------------------------------- end readClientFromSession(); ---------------------------------


//######################################################################################################
//#                                                                                                                                                                                                           #
//#                     GET ALL CLIENT VARIABLES AND DESCRIPTIONS SUITABLE FOR DISPLAY                 #
//#                                                                                                                                                                                                           #
//#                                                        CALL BY $acIncludes->getAllVariables($client_id);                                                   #
//#                                                                                                                                                                                                           #
//######################################################################################################


function getAllVariables($client_id){
//GETS ALL VARIABLES FOR THIS ONE CLIENT AND RETURNS THEM AS GLOBALS

//connect if needed
   global $db_name,$connection,$db;

    $db_name = "america2_AHC";

        //open the SQL connection to AHC server databases
        //$connection = mysql_connect("localhost","america2_larryvo","magiclar");// or die (mysql_error())
        $connection = mysql_connect("mysql209.secureserver.net","america2_AHC","magiclar");

        // SELECT DB - create var to hold the result of select db function
        $db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//All these variables are global so they are usable outside of function call for views
Global $client_f_name, $client_middle_initial, $client_l_name, $sales_category, $sales_stage, $contact_next, $date_sold,
$rec_man_f_name, $rec_man_l_name, $referred_by, $referred_by_details, $client_flags, $address1, $address2, $address3, $postcode, $country, $prim_tel, $sec_tel, $mob_tel, $phone_ext, $primary_goal, $additional_information,$first_appointment, $therapist_f_name, $therapist_l_name, $action, $created, $modified, $motivation, $why_us, $email,$contact_log;

//Create the UBER-query!!! - using joins or where id= id and gets them all in a READABLE FORMAT...
//only things missing from uber-query are secondary goal, modified by and created by
//because already using that variable from auth_users and desc_primary_goal.
//Can't use them in a single-table-helper query but can get the number using * or use a specific query for them.
// USE SELECT * FROM all_clients for all variables in MODIFIABLE FORMAT!!!

//THE UBER-QUERY (copy these)
//****** IF SHOW SINGLE CLIENT STOPS WORKING CHECK TO SEE IF THERE ARE STILL 0'S AS DEFAULTS IN THE *****
//******                                                                                 DESCRIPTIONS TABLES!!!!                                                                *****
$sql="SELECT
all_clients.f_name,
all_clients.middle_initial,
all_clients.l_name,
all_clients.referred_by_details,
all_clients.address1,
all_clients.address2,
all_clients.address3,
all_clients.postcode,
all_clients.country,
all_clients.prim_tel,
all_clients.sec_tel,
all_clients.mob_tel,
all_clients.phone_ext,
all_clients.email,
all_clients.additional_information,
all_clients.motivation,
all_clients.why_us,
FROM_UNIXTIME(all_clients.sales_contact_next,'%M %D %Y') AS contact_next,
FROM_UNIXTIME(all_clients.date_client_sold,'%M %D %Y') AS date_sold,
FROM_UNIXTIME(all_clients.first_appointment,'%M %D %Y') AS first_appointment,
FROM_UNIXTIME(all_clients.created,'%M %D %Y') AS created,
FROM_UNIXTIME(all_clients.modified,'%M %D %Y') AS modified,

desc_sales_categories.description AS sales_category,
desc_sales_stage.description AS sales_stage,

auth_users.f_name AS rec_man_f_name,
auth_users.l_name AS rec_man_l_name,

desc_referred_by.description AS referred_by,

desc_client_flags.description AS client_flags,

desc_primary_goal.description AS primary_goal,

affiliates.f_name AS therapist_f_name,
affiliates.l_name AS therapist_l_name,

desc_action_at_appointment.description AS action


FROM all_clients, desc_sales_categories, desc_sales_stage, auth_users, desc_referred_by, desc_client_flags, desc_primary_goal, affiliates, desc_action_at_appointment

WHERE all_clients.client_id=$client_id
AND all_clients.sales_category=desc_sales_categories.id
AND desc_sales_stage.id=all_clients.sales_stage
AND all_clients.record_manager=auth_users.id
AND all_clients.referred_by=desc_referred_by.id
AND all_clients.client_flags=desc_client_flags.id
AND desc_primary_goal.id=all_clients.primary_goal
AND affiliates.id=all_clients.therapist
AND all_clients.action=desc_action_at_appointment.id";



//FOR MODIFYING:
//$sql="SELECT * FROM all_clients;//ORDER BY whatever


//FORMAT FOR METHODIZING
//SELECT X.X,Y.Y AS qrs
//FROM x,y
//WHERE X.X=Y.Y
//AND Y.Y=Z.Z


        $result = mysql_query($sql) or die(mysql_error()) ;//
                        while ($row = mysql_fetch_array($result)){

                          $client_f_name=$row['f_name'];
                          $client_l_name=$row['l_name'];
                          $client_middle_initial=$row['middle_initial'];
                          $sales_category=$row['sales_category'];
                          $sales_stage=$row['sales_stage'];
                          $contact_next=$row['contact_next'];
                          $date_sold=$row['date_sold'];
                          $rec_man_l_name=$row['rec_man_l_name'];
                          $rec_man_f_name=$row['rec_man_f_name'];
                          $referred_by=$row['referred_by'];
                          $referred_by_details=$row['referred_by_details'];
                          $client_flags=$row['client_flags'];
                          $address1=$row['address1'];
                          $address2=$row['address2'];
                          $address3=$row['address3'];
                          $postcode=$row['postcode'];
                          $country=$row['country'];
                          $prim_tel=$row['prim_tel'];
                          $sec_tel=$row['sec_tel'];
                          $mob_tel=$row['mob_tel'];
                          $phone_ext=$row['phone_ext'];
                          $primary_goal=$row['primary_goal'];
                          $additional_information=$row['additional_information'];
                          $first_appointment=$row['first_appointment'];
                          $therapist_f_name=$row['therapist_f_name'];
                          $therapist_l_name=$row['therapist_l_name'];
                          $action=$row['action'];
                          $created=$row['created'];
                          $modified=$row['modified'];
                          $motivation=$row['motivation'];
                          $why_us=$row['why_us'];
                          $email=$row['email'];

                          }//end of While loop

// Get Contact Log information and output as $contact_log"

        //query
        $contactQuery="SELECT all_clients_contact_logs.notes AS notes, FROM_UNIXTIME(all_clients_contact_logs.timestamp,'%M %D %Y %h:%i:%s') AS log_time, auth_users.f_name AS rec_man_f_name, auth_users.l_name AS rec_man_l_name
        FROM all_clients_contact_logs, auth_users
        WHERE client_id=$client_id
        AND auth_users.id=all_clients_contact_logs.user_id
        ORDER BY all_clients_contact_logs.timestamp DESC";

        //send er up the flag
        $resultamundo = mysql_query($contactQuery) ;// or die(mysql_error())

        $contact_log = "";

                        while ($row = mysql_fetch_array($resultamundo)){

                          $log_time=$row['log_time'];
                          $rec_man_f_name=$row['rec_man_f_name'];
                          $rec_man_l_name=$row['rec_man_l_name'];
                          $notes=$row['notes'];

                $contact_log .= "
                                <font face=\"Arial\" size=\"2\">
                                <p align=\"left\">$notes</p>
                                <p align=\"right\">- $rec_man_f_name $rec_man_l_name<br>
                                        - $log_time</p></font><br>
                                </font>";

                          }//end while loop

        $contact_log .="<p align=\"left\">$additional_information</p>";

}//------------------------------------- end of allHisVars($client_id)-------------------------------------




//######################################################################################################
//#                                                                                                                                                                                                           #
//#                        Create a state drop-down html box and select the one previously selected                                   #
//#                                                                                                                                                                                                           #
//#                        call by $state_print = $acIncludes->stateDropDown($address3);                                                           #
//#                                                                                                                                                                                                           #
//######################################################################################################


function stateDropDown($address3){

//POPULATE STATE DROP-DOWN MENU WITH PREVIOUS SELECTION

$state_left_string = array("<option value=\"AL\"","<option value=\"AK\"","<option value=\"AZ\"","<option value=\"AR\"","<option value=\"CA\"","<option value=\"CO\"","<option value=\"CT\"","<option value=\"DE\"","<option value=\"DC\"","<option value=\"FL\"","<option value=\"GA\"","<option value=\"HI\"","<option value=\"ID\"","<option value=\"IL\"","<option value=\"IN\"","<option value=\"IA\"","<option value=\"KS\"","<option value=\"KY\"","<option value=\"LA\"","<option value=\"ME\"","<option value=\"MD\"","<option value=\"MA\"","<option value=\"MI\"","<option value=\"MN\"","<option value=\"MS\"","<option value=\"MO\"","<option value=\"MT\"","<option value=\"NE\"","<option value=\"NV\"","<option value=\"NH\"","<option value=\"NJ\"","<option value=\"NM\"","<option value=\"NY\"","<option value=\"NC\"","<option value=\"ND\"","<option value=\"OH\"","<option value=\"OK\"","<option value=\"OR\"","<option value=\"PA\"","<option value=\"RI\"","<option value=\"SC\"","<option value=\"SD\"","<option value=\"TN\"","<option value=\"TX\"","<option value=\"UT\"","<option value=\"VT\"","<option value=\"VA\"" ,"<option value=\"WA\"","<option value=\"WV\"","<option value=\"WI\"","<option value=\"WY\"");

$state_right_string = array(">Alabama (AL)</option>",">Alaska (AK)</option>",">Arizona (AZ)</option>",">Arkansas (AR)</option>",">California (CA)</option>",">Colorado (CO)</option>",">Connecticut (CT)</option>",">Delaware (DE)</option>",">Washington DC</option>",">Florida (FL)</option>",">Georgia (GA)</option>",">Hawaii (HI)</option>",">Idaho (ID)</option>",">Illinois (IL)</option>",">Indiana (IN)</option>",">Iowa (IA)</option>",">Kansas (KS)</option>",">Kentucky (KY)</option>",">Louisiana (LA)</option>",">Maine (ME)</option>",">Maryland (MD)</option>",">Massachusetts (MA)</option>",">Michigan (MI)</option>",">Minnesota (MN)</option>",">Mississippi (MS)</option>",">Missouri (MO)</option>",">Montana (MT)</option>",">Nebraska (NE)</option>",">Nevada (NV)</option>",">New Hampshire (NH)</option>",">New Jersey (NJ)</option>",">New Mexico (NM)</option>",">New York (NY)</option>",">North Carolina (NC)</option>",">North Dakota (ND)</option>",">Ohio (OH)</option>",">Oklahoma (OK)</option>",">Oregon (OR)</option>",">Pennsylvania (PA)</option>",">Rhode Island (RI)</option>",">South Carolina (SC)</option>",">South Dakota (SD)</option>",">Tennessee (TN)</option>",">Texas (TX)</option>",">Utah (UT)</option>",">Vermont (VT)</option>",">Virginia (VA)</option>",">Washington (WA)</option>",">West Virginia (WV)</option>",">Wisconsin (WI)</option>",">Wyoming (WY)</option>");

$state_abbrevs = array("AL","AK","AZ","AR","CA","CO","CT","DE","","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY");

$state_print = "<select name=\"address3\">";

        for ($i=0; $i<50; $i++){

                 $state_print .= $state_left_string[$i];

                        if ($state_abbrevs[$i] == $address3){

                          $state_print .= "selected";

                        }//if first two letters match the selection #'s above, then selected'

        $state_print .= $state_right_string[$i];

        }//end for/next loop

        $state_print.= "</select>";

return $state_print;

}//----------------------------------------- end stateDropDow function ---------------------------------



//########################################################################################
//#                                         METHOD TO RETRIEVE A VARIABLE FROM TABLE                                                          #
//#                                         AND ASSIGNS THEM TO A php VARIABLE                                                                   #
//#    CALL BY:   $variable = $acIncludes->getVar($table_name,$id,$fieldName);                    #
//#    example:  $description = $acIncludes->getACVar('desc_whatever',$id,$desc)                         #
//########################################################################################

        function getACVar($table_name,$client_id,$fieldName){

                        //DO QUERY TO RETRIEVE ALL VARIABLES FOR PERSON # $ID
                          $sql = "SELECT * FROM $table_name WHERE client_id = '$client_id'";
                        $result = mysql_query($sql) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
        while ($row = mysql_fetch_array($result)){

                        $variable = $row[$fieldName];

           }//close while loop that assigns values from fetch_array

return $variable;

}//end function



//======================================================================================================
//======================================================================================================

}//end entire Class


$acIncludes = new all_clients_functions();//create object from class

?>