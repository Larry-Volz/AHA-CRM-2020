<?

//ALT STRATEGY:
//do simple * select but using the id=desc_id idea to make sure right descriptions or use join
//then catch it in an array



//testing get variable from databases

//get all_clients_classes
require_once('classes_all_clients.php');


//open database
$acIncludes->dbConnect();

$table_name="desc_action_at_appointment";
$id="3";
$fieldName="desc";

//get wanted variable
$descPrintBlock = $acIncludes->getVar($table_name,$id,$fieldName);

//Try simple drop-down box creation method...
$desc_table="desc_primary_goal";
$select_box_name="primary_goal";
$primary_goal_select_box = $acIncludes->dropDownEcho($desc_table,$select_box_name);

//Try drop-down box with one chosen to modify method...
$desc_table="desc_primary_goal";
$select_box_name="primary_goal_choice";
$client_id=1;
$desc_field_name="primary_goal";

//call method
$print_primary_goal_block=$acIncludes->dropDownModify($desc_table,$select_box_name,$client_id,$desc_field_name);

//get all client's variables
$client_id=3;
$client=$acIncludes->getAllVariables($client_id);//CALL FUNCTION TO GET BACK ALL VARIABLES AS GLOBALS

?>
<html>
<head>
</head>
<body>
<h1>Testing the acIncludes</h1>
<br>
<strong>In looking for the desc from desc_action_at_appointment with and id=3 I used:<strong><br>
$acIncludes->getVar($table_name,$id,$fieldName);  <br><br>
<strong>And that yielded:</strong><br><br>
<? echo "$descPrintBlock"; ?><br><br><br>

<i>$acIncludes->dropDownEcho($desc_table,$select_box_name);</i><strong>  Yielded:</strong><br><br>

<form name="experimental_form">

	<? echo $primary_goal_select_box; ?><br><br>
	
<strong>And heres the method to print the select box with the one he already selected - selected!</strong><br>
<i>$print_primary_goal_block=$acIncludes->dropDownModify($desc_table,$select_box_name,$client_id,$desc_field_name);</i><br><br>

	<? echo $print_primary_goal_block; ?><br>
	<? echo $msg; ?><br>	

<input type="submit" value="submit" />
<br><br>
<strong>Here is where I try the function to retrieve all display variables from the various related tables:

<?	echo "<br><br>$client_f_name, $client_middle_initial, $client_l_name, $sales_category, $sales_stage, $contact_next, $date_sold, 
$rec_man_f_name, $rec_man_l_name, $referred_by, $referred_by_details, $client_flags, $address1, $address2, $address3, $postcode, $country, $prim_tel, $sec_tel, $mob_tel, $phone_ext, $primary_goal, $additional_information,$first_appointment, $therapist_f_name, $therapist_l_name, $action, $created, $modified, $motivation, $why_us"; ?>
<br><br> Hope that worked...

</body>
</html>