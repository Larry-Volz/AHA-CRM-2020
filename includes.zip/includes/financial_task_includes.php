<?
//title:  financial_tasks_includes

//ListCurrentFinancialTasks(): (Line 25ish)
//function to list the outstanding financial tasks that need to be done

//count_open_tasks(): line 244ish

//CountDaysSales():

//CountWeekSales():

//CountMonthSales():

//CountYTDSales():

//CountSalesMoney($time_period): around line 431ish

//HighestSeller($time_start,$time_end): around line 477ish
 
//################################## CONNECT ###########################################

//***********!!!!!!!!!!!! MAKE SURE THE FOLLOWING CLASS IS CALLED FROM CALLING SCRIPT!!!!!!!!!!!!!!!!!!!!!
//include_once("../../ahcDatabase_class.php");

//connect to db
//$ahcDB->dbConnect();

//#####################################################################################################################
FUNCTION ListCurrentFinancialTasks(){
// create variable for name of database & table
$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = @mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = @mysql_select_db($db_name, $connection) or die (mysql_error());


//create the sql statement  -- WHERE xaction_status='pending' OR xaction_status='failed' 
$sql = "SELECT * FROM $table_name ORDER BY date";

//execute the sql statement and create a variable you can use to display or work with it
$result = mysql_query($sql, $connection);// or die(mysql_error());

$output .="<table border=\"1\"><tr><td colspan=\"100%\"><strong>Current Accounting Tasks</strong></td></tr>";

$output .="<tr><td>&nbsp;</td><td NOWRAP>Status</td><td NOWRAP><strong>Date to Charge</strong></td><td NOWRAP><strong>Client</strong></td><td NOWRAP><strong>Program</strong></td><td NOWRAP><strong>Charge Amt</strong></td><td NOWRAP><strong>Sold By</strong></td><td NOWRAP><strong>Notes</strong></td></tr>";


//counter for background changes
$background_counter=2;

//get financial table data
	while ($row = mysql_fetch_array($result)){
    	$id=$row['id'];    	  	
    	$client_id=$row['client_id'];
    	$client_f_name=$row['client_f_name'];
    	$client_l_name=$row['client_l_name'];

		$xaction_status=$row['xaction_status'];    	
    	
    	$amount_to_charge=$row['amount'];
		$program_cost=$row['program_cost'];				
		$number_of_payments=$row['number_of_payments'];	
		$equal_payments_of=$row['equal_payments_of'];							

		$cc_type=$row['cc_type'];
		$cc_number=$row['cc_number'];
		$cc_expiration_date=$row['cc_expiration_date'];
		
        $readable_expiration_date= date("F , Y", $cc_expiration_date);		
		
		$ck_routing_number=$row['ck_routing_number'];
		$ck_account_number=$row['ck_account_number'];
		$ck_number=$row['ck_number'];
		
        $program_id=$row['program_id']+1;

        $time_stamp=$row['date'];
		$readable_charge_date= date("F j, Y", $time_stamp);
		
		$date_sold=$row['date_sold'];
		$readable_date_sold= date("F j, Y", $date_sold);
        
        $financial_notes=$row['notes'];
        
        $pc_id=$row['pc_id'];
        


//inner while loop to find the client's name from the id number - When all_clients works...
/*

						$table3 = "all_clients";
                        $sql3 = "SELECT * FROM $table3 WHERE client_id = $client_id";

                        $result3 = mysql_query($sql3) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
		        while ($row3 = mysql_fetch_array($result2)){
					
					    $f_name=$row3['f_name'];
				        $l_name=$row3['l_name'];

           }//close while loop that assigns values from fetch_array

        
*/

//Inner while loop to find the description of the primary goal index ----------------------------------

						$table2 = "desc_primary_goal";
                        $sql2 = "SELECT * FROM $table2 WHERE id = $program_id";

                        $result2 = @mysql_query($sql2) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
		        while ($row2 = @mysql_fetch_array($result2)){

                        $primary_goal = $row2['description'];

           }//close while loop that assigns values from fetch_array
//-----------------------------------------------------------------------------------------------------


//Inner while loop to find the name of the pc from the user_id
						$table4 = "auth_users";
                        $sql4 = "SELECT * FROM $table4 WHERE id = $pc_id";

                        $result4 = @mysql_query($sql4) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
		        while ($row4 = mysql_fetch_array($result4)){

                        $f_name = $row4['f_name'];
                        $l_name = $row4['l_name'];
                        $pc_name= "$f_name $l_name";

           }//close while loop that assigns values from fetch_array
           
           
//-------------------------------------------------------------------------------------------------------           



//set up color coding
	IF (trim($xaction_status)=="pending"){
	  $font_color="blue";
	}
	IF (trim($xaction_status)=="failed"){
	  $font_color="red";
	}
		IF (trim($xaction_status)=="deleted"){
	  $font_color="gray";
	}
		IF (trim($xaction_status)=="charged"){
	  $font_color="green";
	}

//Do background dependent on counter or if there are notes ---------------------------
IF ($background_counter%2==0){
    $bg_color="#CCFFCC";
}else
{
  $bg_color="#FFFFFF";
}

$background_counter++;

//IF (trim($financial_notes) != ""){
//   $bg_color="#FFCCFF";
//}

//-----------------------------------------------------------------------------------


/*

Create a yes/no variable of whether or not to print:
		If pending or failed - yes, print
		
		if $time_stamp>24 hours ago and is charged or deleted then do not print

*/

$print_yesno ="";
$now=time();
$time_diff=$now-$time_stamp;

IF ((($xaction_status=="charged")OR($xaction_status=="deleted")) AND ($time_diff>43200)){
  $print_yesno="no";
}ELSE{
  $print_yesno="yes";
}


IF ($print_yesno=="yes"){

			$output .= "<tr><td bgcolor=\"$bg_color\" NOWRAP>";
			
				IF (trim($financial_notes) != ""){
				  $output .= "<font color= \"red\">***</font>";
				}
			
			$output .="&nbsp;</td>";
			
			$output .="<td NOWRAP><font color =\"$font_color\">
			$xaction_status</a></td>
			<td bgcolor=\"$bg_color\" NOWRAP><font color =\"$font_color\"><a href=\"http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/financial/show_mod_single_accounting_task.php?xaction_id=$id\">
			$readable_charge_date</a></font></td>
			<td bgcolor=\"$bg_color\" NOWRAP><font color =\"$font_color\"><a href=\"http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/financial/show_mod_single_accounting_task.php?xaction_id=$id\">
			$client_f_name&nbsp;$client_l_name</a></font></td>
			<td bgcolor=\"$bg_color\" NOWRAP><font color =\"$font_color\"><a href=\"http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/financial/show_mod_single_accounting_task.php?xaction_id=$id\">
			$primary_goal</a></font></td>
			<td bgcolor=\"$bg_color\" NOWRAP><font color =\"$font_color\"><a href=\"http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/financial/show_mod_single_accounting_task.php?xaction_id=$id\">
			\$$amount_to_charge</a></font></td>
			<td bgcolor=\"$bg_color\" NOWRAP><font color =\"$font_color\"><a href=\"http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/financial/show_mod_single_accounting_task.php?xaction_id=$id\">
			$pc_name&nbsp;</a></font></td>
			";

			
		$output .= "<td bgcolor=\"$bg_color\" nowrap>$financial_notes&nbsp;</td>";
		
		$output .= "</tr>";  
				
		}//FINISH THE YES/NO PRINT LOOP -------------------------------------------------------------
		
    }//close the outer while loop------------------------------------------------------------------------------------
    
$output .= "</table>";

return $output;

}//end function

//=====================================================================================================================


//##################### FUNCTION TO COUNT OPEN ACCOUNTING TASKS ###########################

//######################## CALL BY: $count_open_tasks = count_open_tasks(); #################



function count_open_tasks(){

// create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------


$sql = "SELECT count(id) FROM $table_name WHERE xaction_status=\"failed\" OR xaction_status=\"pending\"";

$result=mysql_query($sql,$connection);// or die(mysql_error())

$count = mysql_result($result,0,"count(id)");// or die(mysql_error())

return $count;

}//end function

//-------------------------------END count_open_tasks()------------------------------------






//########################################################################################################
//CountDaysSales(): Counts sales since midnight

function CountDaysSales(){
  
  // create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------

		$now=time();
		
		//get date for today		
		$today = date("j", $now);	//day of week from 0 = sunday to 6=saturday
		$month = date("n", $now);
		$year = date("Y", $now);
		  
		//create todays timestamp from date but starting at midnight
		$today_midnight = mktime(0,0,0,$month,$today,$year);
		//subtract midnight from now for new time elapsed
		$seconds_elapsed = $now - $today_midnight;

$sql = "SELECT count(id) FROM $table_name WHERE date_sold > $today_midnight AND date_sold <= $now AND client_f_name !='Testy'";

$result=mysql_query($sql,$connection);// or die(mysql_error())

$count = mysql_result($result,0,"count(id)");// or die(mysql_error())

return $count;
  
  
  
}//end function definition


//******* DO FUNCTION TO SHOW THE MONEY ADDED UP FROM THE DAY'S SALES AS WELL

//--------------------------------------------------------------------------------------------------------



//CountWeekSales(): Counts last 7 days

function CountWeekSales(){
  
  // create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------

$now=time();
$one_week_ago=$now-604800;

$sql = "SELECT count(id) FROM $table_name WHERE date_sold >$one_week_ago AND date_sold <= $now AND client_f_name !='Testy'";

$result=mysql_query($sql,$connection);// or die(mysql_error())

$count = mysql_result($result,0,"count(id)");// or die(mysql_error())

return $count;
  
  
  
}//end function definition



//--------------------------------------------------------------------------------------------------------



//CountMonthSales(): Counts last 30 days

function CountMonthSales(){
  
  // create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------

$now=time();
$twelve_hrs_ago=$now-2592000;

$sql = "SELECT count(id) FROM $table_name WHERE date_sold >$twelve_hrs_ago AND date_sold <= $now AND client_f_name !='Testy'";

$result=mysql_query($sql,$connection);// or die(mysql_error())

$count = mysql_result($result,0,"count(id)");// or die(mysql_error())

return $count;
  
  
  
}//end function definition



//--------------------------------------------------------------------------------------------------------



//CountYearSales(): Counts last 30 days

function CountYearSales(){
  
  // create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------

$now=time();
$one_year_ago=$now-31104000;

$sql = "SELECT count(id) FROM $table_name WHERE date_sold >$one_year_ago AND date_sold <= $now AND client_f_name !='Testy'";

$result=mysql_query($sql,$connection);// or die(mysql_error())

$count = mysql_result($result,0,"count(id)");// or die(mysql_error())

return $count;
  
  
  
}//end function definition

//------------------------------------------------------------------------------------------------------------------



function CountSalesMoney($time_interval){
//time_interval is the time in seconds before now that you want it to add up  
  
  // create variable for name of database & table

$db_name = "america2_AHC";
$table_name = "financial";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost", "america2_AHC", "magiclar") or die (mysql_error());

// create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection);// or die (mysql_error())

//--------------------------- COUNT DB FINANCIAL QUERY -----------------------------

$now=time();
$start_time=$now-$time_interval;

$total_money=0;

$sql="SELECT * FROM $table_name WHERE date_sold > $start_time AND date_sold <= $now AND client_f_name !='Testy'";

                        $result = mysql_query($sql) or die(mysql_error());//

                //CREATE AN ARRAY CALLED $row() FOR EACH RECORD IN RESULT SET
		        while ($row = mysql_fetch_array($result)){

                        $program_cost = $row['program_cost'];
                        $total_money += $program_cost;
                        


           }//close while loop that assigns values from fetch_array
$total_money_formatted= money_format("%i", $total_money);   
        
return $total_money_formatted;           

}//end CountSalesMoney($time_interval)

//-------------------------------------------------------------------------------------------------------------

function HighestSeller($time_start,$time_end){
//RETURNS THE ID# OF THE TOP SELLER FOR THAT TIME PERIOD  
  
//lookup all financial transactions by time period order by pc_id

//do while loop

//Create two variables:  pc_id_index['$i'] = $i and pc_total['$i']

//'add each pc's total pc_total['$i']+= program_total

//Create other variables:  best_pc_index, best_pc_total, worst_pc_index, worst_pc_total

//then, when they are all full do a while kinda bubble sort...

//if best_pc_total < pc_total['$i']{ best_pc_total = pc_total['$i'] and best_pc_index = pc_id_index['$i']}

//return best_pc_index and make the amount a global so I can pick that up to  
  
  
  
  //OR... DO TOTALS IN ONE ARRAY AND THEN SORT THAT ARRAY.  FIND COMMAND TO GET RANKING!  AUTOMATE IN ANNOUNCEMENT AREA!
  
}// end HighestSeller()


?>

<html>
<head>
<title></title>



</head>
<body>




</body>
</html>