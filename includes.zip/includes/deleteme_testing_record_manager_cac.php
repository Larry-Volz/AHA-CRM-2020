<?

//################################ security #####################################################
//include file
require_once('classes_all_clients.php');

//################################ get client's variables #######################################

//open database
$acIncludes->dbConnect();

//get all client's variables
$client_id=2;
$client=$acIncludes->getAllVariables($client_id);//CALL FUNCTION TO GET BACK ALL VARIABLES AS GLOBALS

echo "Record manager is:  $rec_man_f_name $rec_man_l_name (#$record_manager)<br>";
echo "created_by: $created_by<br>";
echo "modified_by: $modified_by<br>";
echo"created: $created<br>";
echo "modified: $modified<br>";
echo "client_id: $client_id";





?>