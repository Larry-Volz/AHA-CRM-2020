var defaultEmptyOK = false
var decimalPointDelimiter = "."

function Fereastra_veche(WinWidth,WinHeight,Link,WindowName) {
        window.open(Link,WindowName,'toolbar=0,width='+WinWidth+',height='+WinHeight+',location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=0,copyhistory=0');
}

function Fereastra(WinWidth,WinHeight,Link,WindowName) {
     var winl = (screen.width-WinWidth) / 2;
     var wint = (screen.height-WinHeight) / 2;

     if (WinWidth>800)    WinWidth=800;
     if(WinHeight>600)    WinHeight=600;

     WinWidth=WinWidth+20;
     WinHeight=WinHeight+20;




        popup=window.open(Link,WindowName,'toolbar=0,width='+WinWidth+',height='+WinHeight+',location=0,directories=0,status=0,menubar=0,scrollbars=yes,'+'top='+wint+',left='+winl+'resizable=0,copyhistory=0');
//        popup.close();
//        popup1=window.open(Link,WindowName,'toolbar=0,width='+WinWidth+',height='+WinHeight+',location=0,directories=0,status=0,menubar=0,scrollbars=yes,'+'top='+wint+',left='+winl+'resizable=0,copyhistory=0');
        popup1.focus();
}

function Fereastra_chitanta(WinWidth,WinHeight,Link,WindowName) {
        window.open(Link,WindowName,'toolbar=0,width='+WinWidth+',height='+WinHeight+',location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,copyhistory=0');
}

function ispopupblocker()
{
 var mine = window.open('','','width=1,height=1,left=0,top=0,scrollbars=no');
 if(mine)
    {
    mine.close()
    return false
    }
 else
    {
    mine.close()
    return true
    }
}

function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}


function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}



function isEmail(str) {

                var at="@"
                var dot="."
                var lat=str.indexOf(at)
                var lstr=str.length
                var ldot=str.indexOf(dot)
                if (str.indexOf(at)==-1){

                   return false
                }

                if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){

                   return false
                }

                if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){

                    return false
                }

                 if (str.indexOf(at,(lat+1))!=-1){

                    return false
                 }

                 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){

                    return false
                 }

                 if (str.indexOf(dot,(lat+2))==-1){

                    return false
                 }

                 if (str.indexOf(" ")!=-1){

                    return false
                 }

                  return true
        }








function isInteger (s)

{   var i;

    if (isEmpty(s))
       if (isInteger.arguments.length == 1) return defaultEmptyOK;
       else return (isInteger.arguments[1] == true);

    // Search through string's characters one by one
    // until we find a non-numeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {
        // Check that current character is number.
        var c = s.charAt(i);

        if (!isDigit(c)) return false;
    }

    // All characters are numbers.
    return true;
}



function isFloat (s)

{   var i;
    var seenDecimalPoint = false;

    if (isEmpty(s))
       if (isFloat.arguments.length == 1) return defaultEmptyOK;
       else return (isFloat.arguments[1] == true);

    if (s == decimalPointDelimiter) return false;

    // Search through string's characters one by one
    // until we find a non-numeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {
        // Check that current character is number.
        var c = s.charAt(i);

        if ((c == decimalPointDelimiter) && !seenDecimalPoint) seenDecimalPoint = true;
        else if (!isDigit(c)) return false;
    }

    // All characters are numbers.
    return true;
}


function verifica1()
{

  if ( (document.logare.username.value=="") )
   {
   alert('Completa-ti campul Nume Utilizator');
   }
 else if ( (document.logare.password.value=="") )
  {
   alert('Completa-ti campul Parola');
  }
  else
  {
  document.logare.submit();
  }

}



  function java_redirect(url)
{
       window.location.href=url;
}
  function confimare(text,url)
{
      var a='';
      a=text;
       if (confirm(a)) window.location.href=url;
}


function update_length()
{
  var a=document.add_card.cod.value;
  var b=document.add_card.lung.value;
  b=a.length;

}


function confirmare(message, url){
if(confirm(message)) location.href = url;
}


