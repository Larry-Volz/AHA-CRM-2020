<?

	$fromZipCode="";
	if ( isset($HTTP_GET_VARS["fromZipCode"]) )$fromZipCode=trim($HTTP_GET_VARS["fromZipCode"]);
	if ( isset($HTTP_POST_VARS["fromZipCode"]) )$fromZipCode=trim($HTTP_POST_VARS["fromZipCode"]);
	$toZipCode="";
	if ( isset($HTTP_GET_VARS["toZipCode"]) )$toZipCode=trim($HTTP_GET_VARS["toZipCode"]);
	if ( isset($HTTP_POST_VARS["toZipCode"]) )$toZipCode=trim($HTTP_POST_VARS["toZipCode"]);
	$toZipCodeMoving=$toZipCode;
	$fromZipCodeMoving=$fromZipCode;

	include( "http://www.americanhypnosisclinic.com/intranet/mileage_calculator/DrivingDistanceCalcFunctions.php" );
?>
<p class="PageTitle">Mileage Calculator</p>
<form action="http://www.americanhypnosisclinic.com/intranet/mileage_calculator/mileage_calc_sample.php">
	<table cellspacing="0" cellpadding="5" class="smallText">
		<tr>
			<td width="112" nowrap><b>From Zip Code:</b></td>
			<td><input type="text" size="8" STYLE="BORDER:1px #BBBDC9 solid" class="smallText" name="fromZipCode" value="<?=$fromZipCode?>"></td>
		</tr>
			<td><b>To Zip Code:</b></td>
			<td><input type="text" size="8" STYLE="BORDER:1px #BBBDC9 solid" class="smallText" name="toZipCode" value="<?=$toZipCode?>"></td>
		</tr>
		<tr>
			<td colspan=2 align=center><input type="submit" value="Calculate" STYLE="BORDER:1px #BBBDC9 solid"></td>
		</tr>
	</table>
</form>
<?

if( $fromZipCode!="" &&  $toZipCode!=""){
	getDistance($fromZipCode,$toZipCode);
?>
	<table width="560"  border="0" cellspacing="1" cellpadding="5" >
		<tr>
			<td class="Subtitle">
				<b><?echo "<p class='contet'>Distance between ".$FromCity."(".$FromState.") and ".$ToCity."(".$ToState.") is ".number_format($DrivingDistance,0)." miles</p>";?></b>
			</td>
		</tr>
	</table>
<?}?>