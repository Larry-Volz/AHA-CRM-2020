<?php
  echo "PHP_OS: ". PHP_OS;
?>
