<?php header('Location: sitemgr.html'); ?>
