<?php
	/**************************************************************************\
	* eGroupWare SiteMgr - SiteMgr support for Mambo Open Source templates     *
	* http://www.egroupware.org                                                *
	* Written and (c) by RalfBecker@outdoor-training.de                        *
	* --------------------------------------------                             *
	*  This program is free software; you can redistribute it and/or modify it *
	*  under the terms of the GNU General Public License as published by the   *
	*  Free Software Foundation; either version 2 of the License, or (at your  *
	*  option) any later version.                                              *
	\**************************************************************************/

	/* $Id: footer.php,v 1.2 2005/03/14 21:09:03 ralfbecker Exp $ */

	// This file echos the contentarea 'footer'
	global $objui;
	echo $objui->t->process_blocks('footer');
	
	// this is necessary to get wz_tooltips
	echo $GLOBALS['phpgw_info']['flags']['need_footer'];
