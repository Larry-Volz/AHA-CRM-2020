<?php
	/**************************************************************************\
	* eGroupWare - jerryr                                                      *
	* http://www.egroupware.org                                                *
	* --------------------------------------------                             *
	*  This program is free software; you can redistribute it and/or modify it *
	*  under the terms of the GNU General Public License as published by the   *
	*  Free Software Foundation; either version 2 of the License, or (at your  *
	*  option) any later version.                                              *
	\**************************************************************************/


	/* Basic information about this template */
	$GLOBALS['egw_info']['template']['jerryr']['name']      = 'jerryr';
	$GLOBALS['egw_info']['template']['jerryr']['title']     = 'jerryr';
	$GLOBALS['egw_info']['template']['jerryr']['version']   = '1.0';

	$GLOBALS['egw_info']['template']['jerryr']['author'] = 'Pim Snel';
	$GLOBALS['egw_info']['template']['jerryr']['license']  = 'GPL';
	$GLOBALS['egw_info']['template']['jerryr']['windowed'] = False;
	$GLOBALS['egw_info']['template']['jerryr']['icon'] = "phpgwapi/templates/jerryr/images/jerryr-logo.png";
	$GLOBALS['egw_info']['template']['jerryr']['maintainer'] = array(
	);
	$GLOBALS['egw_info']['template']['jerryr']['description'] = "jerryr is a clone of the idots template set.";
?>
