<?php
/**
 * PHPMailer language file.
 * English Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Vnesti morate enaslov vsaj enega naslovnika.';
$PHPMAILER_LANG["mailer_not_supported"] = ' epo�ta ni podprta.';
$PHPMAILER_LANG["execute"] = 'Ne morem izvesti: ';
$PHPMAILER_LANG["instantiate"] = 'Ne morem nalo�iti po�tne funkcije.';
$PHPMAILER_LANG["authenticate"] = 'SMTP napaka: Ne morem preveriti pristnosti.';
$PHPMAILER_LANG["from_failed"] = 'Naslednji naslov po�iljatelja je napa�en: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP napaka: Naslednji naslovniki niso pravi: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP napaka: Podatki niso bili sprejeti.';
$PHPMAILER_LANG["connect_host"] = 'SMTP napaka: Ne morem se povezati s stre�nikom SMTP.';
$PHPMAILER_LANG["file_access"] = 'Ne morem dostopati do datoteke: ';
$PHPMAILER_LANG["file_open"] = 'Napaka z datoteko: Ne morem odpreti datoteke: ';
$PHPMAILER_LANG["encoding"] = 'Neznano kodiranje: ';
?>
