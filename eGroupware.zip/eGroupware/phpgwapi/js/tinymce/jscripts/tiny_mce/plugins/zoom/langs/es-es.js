tinyMCELang['lang_dir'] = 'ltr';
tinyMCELang['lang_zoom_prefix'] = 'Escala';