// UK lang variables

tinyMCELang['lang_insert_image_alt2'] = 'T&iacute;tulo de la imagen';
tinyMCELang['lang_insert_image_onmousemove'] = 'Imagen alternativa'
tinyMCELang['lang_insert_image_mouseover'] = 'para evento mouse over';
tinyMCELang['lang_insert_image_mouseout'] = 'para evento mouse out';
