// SV lang variables

tinyMCELang['lang_fullscreen_title'] = 'Fullsk&auml;rmsl&auml;ge'
tinyMCELang['lang_fullscreen_desc'] = 'Hoppa fr&aring;n/till fullsk&auml;rmsl&auml;ge'
