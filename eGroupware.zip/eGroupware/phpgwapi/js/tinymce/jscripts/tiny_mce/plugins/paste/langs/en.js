// UK lang variables

tinyMCELang['lang_paste_text_desc'] = 'Paste as Plain Text';
tinyMCELang['lang_paste_text_title'] = 'Use CTRL+V on your keyboard to paste the text into the window.';
tinyMCELang['lang_paste_text_linebreaks'] = 'Keep linebreaks';
tinyMCELang['lang_paste_word_desc'] = 'Paste from Word';
tinyMCELang['lang_paste_word_title'] = 'Use CTRL+V on your keyboard to paste the text into the window.';
tinyMCELang['lang_selectall_desc'] = 'Select All';
