// UK lang variables

tinyMCELang['lang_iespell_desc'] = 'Run spell checking';
tinyMCELang['lang_iespell_download'] = "ieSpell not detected. Click OK to go to download page."
