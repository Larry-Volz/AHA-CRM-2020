// UK lang variables

tinyMCELang['lang_insert_image_alt2'] = 'N�zev obr�zku';
tinyMCELang['lang_insert_image_onmousemove'] = 'Alternativn� obr�zek'
tinyMCELang['lang_insert_image_mouseover'] = 'p�i najet� my�i';
tinyMCELang['lang_insert_image_mouseout'] = 'p�i odjet� my�i';