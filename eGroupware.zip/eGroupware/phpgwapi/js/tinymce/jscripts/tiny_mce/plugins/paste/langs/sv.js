// SV lang variables

tinyMCELang['lang_paste_text_desc'] = 'Klistra in som vanlig text'
tinyMCELang['lang_paste_text_title'] = 'Anv&auml;nd CTRL+V p&aring; ditt tangentbord f&ouml;r att klistra in i detta f&ouml;nster.';
tinyMCELang['lang_paste_text_linebreaks'] = 'Spara radbrytningar';
tinyMCELang['lang_paste_word_desc'] = 'Klistra in fr&aring;n Word'
tinyMCELang['lang_paste_word_title'] = 'Anv&auml;nd CTRL+V p&aring; ditt tangentbord f&ouml;r att klistra in i detta f&ouml;nster.';
tinyMCELang['lang_selectall_desc'] = 'Select All';
