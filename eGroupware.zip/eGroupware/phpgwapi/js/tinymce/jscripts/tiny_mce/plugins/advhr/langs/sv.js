// SE lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Skapa/Redigera horisontell linje'
tinyMCELang['lang_insert_advhr_width']   = 'Bredd';
tinyMCELang['lang_insert_advhr_size']    = 'H�jd';
tinyMCELang['lang_insert_advhr_noshade'] = 'Ingen skugga';
