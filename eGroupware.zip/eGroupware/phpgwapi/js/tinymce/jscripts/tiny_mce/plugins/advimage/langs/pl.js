﻿// PL lang variables

tinyMCELang['lang_insert_image_alt2'] = 'Tytuł obrazka';
tinyMCELang['lang_insert_image_onmousemove'] = 'Obrazek zastępczy'
tinyMCELang['lang_insert_image_mouseover'] = 'po najechaniu myszy';
tinyMCELang['lang_insert_image_mouseout'] = 'po odjechaniu myszy';