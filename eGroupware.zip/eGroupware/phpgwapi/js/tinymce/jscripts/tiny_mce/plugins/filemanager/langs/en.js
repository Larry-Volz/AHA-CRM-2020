tinyMCELang['lang_insert_filemanager']  = 'Insert link to file';
