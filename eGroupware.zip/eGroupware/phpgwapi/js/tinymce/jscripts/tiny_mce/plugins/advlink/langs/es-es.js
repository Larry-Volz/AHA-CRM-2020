// UK lang variables

tinyMCELang['lang_insert_link_target_same'] = 'Abrir en esta ventana / marco';
tinyMCELang['lang_insert_link_target_parent'] = 'Abrir en venta / marco superior';
tinyMCELang['lang_insert_link_target_top'] = 'Abrir en el marco superior (sustituye todos los marcos)';
tinyMCELang['lang_insert_link_target_blank'] = 'Abrir en una ventana nueva';
tinyMCELang['lang_insert_link_target_named'] = 'Abrir en la ventana';
tinyMCELang['lang_insert_link_popup'] = 'Ventana emergente JS';
tinyMCELang['lang_insert_link_popup_url'] = 'URL de la ventana emergente';
tinyMCELang['lang_insert_link_popup_name'] = 'Nombre de la ventana';
tinyMCELang['lang_insert_link_popup_return'] = 'insertar \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars'] = 'Mostrar barras de desplazamiento';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Mostrar barra de estado';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Mostrar barras de herramientas';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Mostrar barra del men&uacute;';
tinyMCELang['lang_insert_link_popup_location'] = 'Mostrar barra de direcciones';
tinyMCELang['lang_insert_link_popup_resizable'] = 'Hacer la ventana redimensionable';
tinyMCELang['lang_insert_link_popup_size'] = 'Tama&ntilde;o';
tinyMCELang['lang_insert_link_popup_position'] = 'Posici&oacute;n (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Por favor, indique un nombre para el destino o elija otra opci&oacute;n.';
