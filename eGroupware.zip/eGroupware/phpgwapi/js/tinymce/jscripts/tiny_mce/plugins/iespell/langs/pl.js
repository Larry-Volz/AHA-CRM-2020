﻿// PL lang variables

tinyMCELang['lang_iespell_desc'] = 'Uruchom sprawdzanie pisowni';
tinyMCELang['lang_iespell_download'] = "Nie wykryto pluginu, kliknij aby przejść do strony z pluginami."