// UK lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Insertar emoci&oacute;n';
tinyMCELang['lang_emotions_desc'] = 'Emociones';

