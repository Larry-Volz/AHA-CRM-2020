<?php
//Code shared by all activities (pos)
?>
