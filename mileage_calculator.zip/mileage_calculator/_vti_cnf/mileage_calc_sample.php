vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Mar 2006 22:53:59 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|30 Mar 2006 22:53:59 -0000
vti_backlinkinfo:VX|mileage_calculator/mileage_calc_sample.php
vti_cacheddtm:TX|30 Mar 2006 22:54:00 -0000
vti_filesize:IR|1625
vti_cachedlinkinfo:VX|A|mileage_calc_sample.php
vti_cachedsvcrellinks:VX|FAUS|mileage_calculator/mileage_calc_sample.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
