<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler, Kay Vogelgesang, Carsten Wiedmann">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title>XAMPP 1.5 WIN32</title>
	</head>

	<body class="white" bgcolor="#ffffff">
		<center>
			<img src="img/blank.gif" alt="" height="180" width="1"><br>
			<img src="img/xampp-logo.jpg" alt="">
			<p>
			<a href="/xampp/lang.php?de">Deutsch</a> /
			<a href="/xampp/lang.php?en">English</a> /
			<a href="/xampp/lang.php?es">Spanish</a> /
			<a href="/xampp/lang.php?fr">Francais</a> /
			<a href="/xampp/lang.php?it">Italiano</a> /
			<a href="/xampp/lang.php?nl">Nederlands</a> /
			<a href="/xampp/lang.php?no">Norsk</a> /
			<a href="/xampp/lang.php?pl">Polish</a> /
			<a href="/xampp/lang.php?pt">Portuguese</a> /
			<a href="/xampp/lang.php?sl">Slovenian</a> /
			<a href="/xampp/lang.php?zh">Chinese</a> / 
			<a href="/xampp/lang.php?pt_br">Portugu�s (Brasil)</a>
		</center>
	</body>
</html>
