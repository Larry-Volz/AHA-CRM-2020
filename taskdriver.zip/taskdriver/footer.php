<?php
include 'config.php';
echo "<table cellspacing=\"0\" class=\"black\" width=\"100%\">";
echo "<tr><td align=\"center\" width=\"100%\"></td></tr>";
echo "<tr><td align=\"center\" width=\"100%\">TaskDriver $version</td></tr>";
echo "</table>";
?>