vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Nov 2005 21:44:24 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|03 Nov 2005 21:44:24 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|03 Nov 2005 21:44:25 -0000
vti_filesize:IR|341
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
