<?
// ################################ CONNECT ################################
// create variable for name of database & table
$db_name = "america2_AHC";
$table_name = "auth_users";

//open the SQL connection to AHC server databases
$connection = mysql_connect("localhost","america2_larryvo","magiclar") or die (mysql_error());

// SELECT DataBase - create var to hold the result of select db function
$db = mysql_select_db($db_name, $connection) or die (mysql_error());


//########## Get User Information ##############################

$current_user_id = $_COOKIE[user_id];

echo" user id from cookie is $current_user_id";

$query2="SELECT * from $table_name WHERE id='$current_user_id'";
$result2=@mysql_query($query2) or die(mysql_error());
$perm_array=mysql_fetch_array($result2);

$current_user_f_name=$perm_array[f_name];
$current_user_l_name=$perm_array[l_name];

echo "<h1>Hi There $current_user_f_name  $current_user_l_name </h1>";
?>
<html>

<head>
  <title></title>
</head>

<body>

<?php

echo "Hello!";

?>

</body>

</html>