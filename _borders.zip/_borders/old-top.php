<?
//###################### SESSION SECURITY CHECK ########################
	
global $auth,$member_f_name,$member_l_name,$timer_start,$permission,$user_id;

session_start();



function chkTimerStarted(){  
  	$timer_start=$_SESSION[timer_start];
  	//timer started?  If No - check if logged in...
	if ($timer_start<1){
	  //echo "timer_start<1 &nbsp;&nbsp;";//testing???????????????????????????
	  chkLoggedIn();
	  	//If yes... return timer start variable
		}else{
		  	//echo"timer_start = $timer_start";//testing???????????????????????????
			return $timer_start;	  
	}//end if/else block
}//end function

function chkLoggedIn(){
	$auth = $_SESSION[auth];
		//if logged in is Yes then set variables
		if ($auth =="ok"){ 
		  	echo"auth = ok? -> really = $auth &nbsp;&nbsp;";
		  	//If logged in then established variables 
		  	$user_id = $_SESSION[user];
			$permission = $_SESSION[permission];
			$member_f_name=$_SESSION[member_f_name];
			$member_l_name=$_SESSION[member_l_name];
			$yesNo=1;
			return $yesNo;		
	}else{//If not - keep checking session variables until they are logged in
		//echo"supposed to go back to chkTimerStarted now...&nbsp;&nbsp;";//testing???????????????????????????
//	  chkTimerStarted();
	}//end if-else

}//end function  
 /* 

}
 	IF (!($_SESSION[timer_start])){// immediately reload if first time bringing up
  		$_SESSION[timer_start]=time();
  		$timer_start=$_SESSION[timer_start];
  		$readableTimerStart = date("\a\\t g.i a",$timer_start);
}else{
  	$readableTimerStart="Session Not Started";
}//end if


//------------------------------ end security check --------------------------

*/

?>
<html>
<head>
<!-- <meta http-equiv="REFRESH" content="60;URL=top.php"> -->
<title>Shared Top Border</title>


<base target="main">

<script language="JavaScript"> // FOR THE ACTIVE BUTTONS I THINK...
<!--
function FP_swapImg() {//v1.0

 var doc=document,args=arguments,elm,n; 
 doc.$imgSwaps=new Array(); 
 for(n=2; n<args.length; n+=2) { 
   elm=FP_getObjectByID(args[n]); 
   if(elm) { 
    	 doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 		elm.$src=elm.src;
		  elm.src=args[n+1]; 
		} 
	}
	
}

function FP_preloadImgs() {//v1.0

 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
 
}

function FP_getObjectByID(id,o) {//v1.0

 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
 
}
// -->
</script>

<!-- CODE TO SETUP TO PRINT THE DAY/DATE -->
<script type="text/javascript">

	<!-- HIDE FROM OLD BROWSERS
	
	dayName = new Array("Sun","Mon","Tue","Wed","Thur","Fri","Sat");
	monName = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	
	now = new Date
	
	//end hiding script from old browsers -->
	
</script>


<!-- <meta name="Microsoft Border" content> -->


</head>


<body background="top_gradient.jpg" onload="FP_preloadImgs(/*url*/'button7C.jpg', /*url*/'button7D.jpg', /*url*/'button7F.jpg', /*url*/'button80.jpg')" topmargin="5">
<table border="0" width="100%" id="table1">
	<tr>
		<td width="8%" valign="top">
		<img border="0" src="logo-emailable.jpg" width="64" height="43"></td>
		<td valign="top" width="60%" colspan="2">
		<p style="margin-top: 0; margin-bottom: 0"><b><font color="#000080">American Hypnosis Clinic, inc.<br>
		INTRANET&nbsp; </font></b>
		<p style="margin-top: 0; margin-bottom: 0">

<?	
	//Has timer started and have they logged in?  
	//Calls function that stays in loop until yes 
	
	$timer_start= chkTimerStarted();
	$readableTimerStart=date('h\:i a \o\n n\-j\-y',$timer_start+7200);//works - but shows westcoast time

	  echo"<br><i><b>Hi $member_f_name. </b></i>&nbsp;Your session started at $readableTimerStart </td>";	 

?>		
		<td valign="top" width="54%">
		<iframe name="I1" width="420" height="93" src="announcements_page.php" border="0" frameborder="0">
		Your browser does not support inline frames or is currently configured not to display inline frames.
		</iframe>
			
		</td>
	</tr>
	<tr>
		
	</tr>
</table>


<script type="text/javascript">

	<!--Hide from old browsers
		blowfish = dayName[now.getDay()] + ", " + monName[now.getMonth()] + " " + now.getDate() + ".";
	//	document.write(blowfish);
		document.dayndate_form.dayndate_display.value = blowfish;
	//end hiding -->
	
</script>

<p style="margin-top: 0; margin-bottom: 0" align="center">&nbsp;</p>

</body>
</html>