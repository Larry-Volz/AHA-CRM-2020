vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Aug 2006 17:52:03 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|18 Apr 2006 08:08:24 -0000
vti_title:SR|American Hypnosis Clinic Intranet - navigation frame
vti_backlinkinfo:VX|backup-index.php index2.php
vti_nexttolasttimemodified:TW|18 Aug 2006 17:50:41 -0000
vti_cacheddtm:TX|18 Aug 2006 17:52:03 -0000
vti_filesize:IR|8776
vti_cachedtitle:SR|American Hypnosis Clinic Intranet - navigation frame
vti_cachedbodystyle:SR|<body background="left_gradient2.jpg" topmargin="2" leftmargin="2" link="#000080" vlink="#0000FF">
vti_cachedlinkinfo:VX|S|left_gradient2.jpg H|../inside_index.php S|logo_animation_0.jpg H|../< H|https://mindbodyonline.com/ws.asp S|logo_animation_0.jpg H|../Dbase\\ Admin/all_clients/show_allclients_main.php H|https://mindbodyonline.com/ws.asp S|logo_animation_0.jpg H|../scheduling_page.php H|../Igor.php S|logo_animation_0.jpg H|../Igor.php H|../Knowledge\\ Base.php S|logo_animation_0.jpg H|../Dbase\\ Admin/auth_users/members_menu.php H|../Knowledge\\ Base.php S|logo_animation_0.jpg H|../Dbase\\ Admin/affiliates/affiliates_menu.php H|../Knowledge\\ Base.php S|logo_animation_0.jpg H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/my_contacts/contact_menu.php H|../Knowledge\\ Base.php S|logo_animation_0.jpg H|../silly\\ quotes.htm H|http://www.americanhypnosisclinic.com/intranet/logout.php A|http://wwwa.accuweather.com/us-city-list.asp S|http://vortex.accuweather.com/adc2004/pub/images/partner_signup/zipcodelookup/lightblue_logo_sm.gif S|http://vortex.accuweather.com/adc2004/pub/images/partner_signup/buttons/submit.gif H|../PC_Training.htm H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/Administrative\\ Links.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/quotes/quotes_menu.php
vti_cachedsvcrellinks:VX|FSUS|_borders/left_gradient2.jpg FHUS|inside_index.php FSUS|_borders/logo_animation_0.jpg DHUS|< NHSS|https://mindbodyonline.com/ws.asp FSUS|_borders/logo_animation_0.jpg FHUS|Dbase\\ Admin/all_clients/show_allclients_main.php NHSS|https://mindbodyonline.com/ws.asp FSUS|_borders/logo_animation_0.jpg FHUS|scheduling_page.php FHUS|Igor.php FSUS|_borders/logo_animation_0.jpg FHUS|Igor.php FHUS|Knowledge\\ Base.php FSUS|_borders/logo_animation_0.jpg FHUS|Dbase\\ Admin/auth_users/members_menu.php FHUS|Knowledge\\ Base.php FSUS|_borders/logo_animation_0.jpg FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Knowledge\\ Base.php FSUS|_borders/logo_animation_0.jpg NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/my_contacts/contact_menu.php FHUS|Knowledge\\ Base.php FSUS|_borders/logo_animation_0.jpg FHUS|silly\\ quotes.htm NHHS|http://www.americanhypnosisclinic.com/intranet/logout.php NAHS|http://wwwa.accuweather.com/us-city-list.asp NSHS|http://vortex.accuweather.com/adc2004/pub/images/partner_signup/zipcodelookup/lightblue_logo_sm.gif NSHS|http://vortex.accuweather.com/adc2004/pub/images/partner_signup/buttons/submit.gif NHUS|PC_Training.htm NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/Administrative\\ Links.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/quotes/quotes_menu.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_language:SR|en-us
