vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|14 May 2006 03:39:03 -0000
vti_timecreated:TR|19 Apr 2006 00:58:20 -0000
vti_title:SR|AHC Announcements
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|_borders/old-top.htm _borders/old-top.php _borders/top.php
vti_nexttolasttimemodified:TW|22 Apr 2006 21:11:37 -0000
vti_cacheddtm:TX|14 May 2006 03:39:03 -0000
vti_filesize:IR|997
vti_cachedtitle:SR|AHC Announcements
vti_cachedbodystyle:SR|<body topmargin="1" leftmargin="1" rightmargin="1" bottommargin="1" background="top_gradient.jpg">
vti_cachedlinkinfo:VX|S|top_gradient.jpg H|http://ahc.webexone.com/r.asp
vti_cachedsvcrellinks:VX|FSUS|_borders/top_gradient.jpg NHHS|http://ahc.webexone.com/r.asp
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
