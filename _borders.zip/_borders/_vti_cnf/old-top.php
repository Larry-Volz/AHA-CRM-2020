vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|27 Apr 2006 23:45:11 -0000
vti_timecreated:TR|19 Apr 2006 00:11:29 -0000
vti_title:SR|Shared Top Border
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|19 Apr 2006 00:11:29 -0000
vti_editor:SW|FrontPage Frames Wizard
vti_cacheddtm:TX|27 Apr 2006 23:45:11 -0000
vti_filesize:IR|5034
vti_cachedtitle:SR|Shared Top Border
vti_cachedbodystyle:SR|<body background="top_gradient.jpg" onload="FP_preloadImgs(/*url*/'button7C.jpg', /*url*/'button7D.jpg', /*url*/'button7F.jpg', /*url*/'button80.jpg')" topmargin="5">
vti_cachedlinkinfo:VX|S|button7C.jpg S|button7D.jpg S|button7F.jpg S|button80.jpg S|top_gradient.jpg S|logo-emailable.jpg S|announcements_page.php
vti_cachedsvcrellinks:VX|FSUS|_borders/button7C.jpg FSUS|_borders/button7D.jpg FSUS|_borders/button7F.jpg FSUS|_borders/button80.jpg FSUS|_borders/top_gradient.jpg FSUS|_borders/logo-emailable.jpg FSUS|_borders/announcements_page.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
