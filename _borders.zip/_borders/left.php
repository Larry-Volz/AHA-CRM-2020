<?
 session_start();
 
$permission =$_SESSION[permission];

/*
IF(!isset($permission)){
  header("Location: left.php");
  exit;
}

$destination = "inside_index_".$permission.".php";
*/
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>American Hypnosis Clinic Intranet - navigation frame</title>


<base target="main">

</head>

<body background="left_gradient2.jpg" topmargin="2" leftmargin="2" link="#000080" vlink="#0000FF">

<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>

<table border="0" width="101%" id="table1">
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="main" href="../inside_index.php">
<img name ="logo_button" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button.src='logo_undo_swirl.gif'" onmouseout="document.logo_button.src='logo_redo_swirl.gif'"></a>
</td>

		<td align="center" >
		
		<p style="margin-bottom: 2px"><b><font size="2">
		<a onmouseover="document.logo_button.src='logo_undo_swirl.gif'" onmouseout="document.logo_button.src='logo_redo_swirl.gif'" target="main" href="../<?		if ($permission !=""){		  		  $destination = "inside_index_".$permission.".php";				  } else {		  		    $destination = "authenticate.htm";					}					echo "$destination"; 		?>" 
		?><!-- LEAVE THE ONE "> AS IT IS CORRECT AND NOT FRONT-PAGE-SCREWUP! -->Home</a></font></b>
		
		</td>
	</tr>
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="_blank" href="https://mindbodyonline.com/ws.asp?studio=AmericanHypnosisClinic&stype=3">
<img name ="logo_button6" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button6.src='logo_undo_swirl.gif'" onmouseout="document.logo_button6.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" bordercolor="#000000">
		<p style="margin-bottom: 2px"><b><font size="2">
		<a onmouseover="document.logo_button6.src='logo_undo_swirl.gif'" onmouseout="document.logo_button6.src='logo_redo_swirl.gif'" target="main" href="../Dbase%20Admin/all_clients/show_allclients_main.php">All Clients</a></font></b></td>
	</tr>
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="_blank" href="https://mindbodyonline.com/ws.asp?studio=AmericanHypnosisClinic&stype=3">
<img name ="logo_button1" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button1.src='logo_undo_swirl.gif'" onmouseout="document.logo_button1.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" bordercolor="#000000">
		<p style="margin-bottom: 2px"><b><font size="2">
		<a onmouseover="document.logo_button1.src='logo_undo_swirl.gif'" onmouseout="document.logo_button1.src='logo_redo_swirl.gif'" target="main" href="http://americanhypnosisclinic.com/webcalendar/">Scheduling</a></font></b></td>
	</tr>
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="main" href="../Igor.php">
<img name ="logo_button2" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button2.src='logo_undo_swirl.gif'" onmouseout="document.logo_button2.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" bordercolor="#000000">
		<p style="margin-bottom: 2px"><b><font size="2">
		<a onmouseover="document.logo_button2.src='logo_undo_swirl.gif'" onmouseout="document.logo_button2.src='logo_redo_swirl.gif'" target="main" href="../Igor.php">Igor</a></font></b></td>
	</tr>
	<tr>
		<td width="34" align="center">
<p style="margin-bottom: 2px">
<a target="main" href="../Knowledge%20Base.php">
<img name ="logo_button8" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button4.src='logo_undo_swirl.gif'" onmouseout="document.logo_button4.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" bordercolor="#000000">
		<p style="margin-bottom: 2px">
		<a onmouseover="document.logo_button8.src='logo_undo_swirl.gif'" onmouseout="document.logo_button8.src='logo_redo_swirl.gif'" target="main" href="../Dbase%20Admin/auth_users/members_menu.php"><font size="2">
		<b>Members</b></font></a></font></b></td>
	</tr>
	<tr>
		<td width="34">
<a target="main" href="../Knowledge%20Base.php">
<img name ="logo_button9" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button9.src='logo_undo_swirl.gif'" onmouseout="document.logo_button9.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" valign="middle"bordercolor="#000000"><font style="font-size: 9.5pt">
		<p style="margin-bottom: 2px"><b>
		<a onmouseover="document.logo_button9.src='logo_undo_swirl.gif'" onmouseout="document.logo_button9.src='logo_redo_swirl.gif'" target="main" href="../Dbase%20Admin/affiliates/affiliates_menu.php">&nbsp;Affiliates</a></b>
	</tr>
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="main" href="../Knowledge%20Base.php">
<img name ="logo_button7" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button5.src='logo_undo_swirl.gif'" onmouseout="document.logo_button5.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" valign="middle"bordercolor="#000000"><font style="font-size: 9.5pt">
		<p style="margin-bottom: 2px"><b>
		<a onmouseover="document.logo_button7.src='logo_undo_swirl.gif'" onmouseout="document.logo_button7.src='logo_redo_swirl.gif'" target="main" href="http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/my_contacts/contact_menu.php">&nbsp;Contacts</a></b>
	</tr>
	<tr>
		<td width="34">
<p style="margin-bottom: 2px">
<a target="main" href="../Knowledge%20Base.php">
<img name ="logo_button5" border="0" src="logo_animation_0.jpg" width="34" height="24" onmouseover="document.logo_button5.src='logo_undo_swirl.gif'" onmouseout="document.logo_button5.src='logo_redo_swirl.gif'"></a></td>
		<td align="center" bordercolor="#000000">
		<p style="margin-bottom: 2px"><font size="2"><b>
		<a onmouseover="document.logo_button5.src='logo_undo_swirl.gif'" onmouseout="document.logo_button5.src='logo_redo_swirl.gif'" target="main" href="../silly%20quotes.htm">Fun Stuff</a></b></font></td>
	</tr>
</table>

<hr>
<table>
	<tr>
		<td>
			<a href="http://www.americanhypnosisclinic.com/intranet/logout.php" target ="_top"><strong>Log Out</strong></a>
		</td>
	</tr>
	<tr>
		<td align="center">
<!-- Begin WEATHER Link Graphic tag -->
		<form method="get" action="http://wwwa.accuweather.com/us-city-list.asp" id="Form1" name="localWX">
		<table bgcolor="#6C8DAF" border="0" cellpadding="0" cellspacing="4" width="120">
		<tr>
		<td align=center valign=middle><img src="http://vortex.accuweather.com/adc2004/pub/images/partner_signup/zipcodelookup/lightblue_logo_sm.gif" border="0"></td>
		</tr>
		<tr>
		<td align=center valign=middle><input type="text" name="zipcode" size="7" maxlength="30"></td>
		</tr>
		<tr>
		<td align=center valign=middle>
		<input type="hidden" name="nav" value="home">
		<input type="hidden" name="partner" value="40332">
		<input type="image" value="submit" src="http://vortex.accuweather.com/adc2004/pub/images/partner_signup/buttons/submit.gif" vspace="4" border="0" id=image1 name=image1>
		</td>
		</tr>
		</table>
		</form>
		<!-- End Link Graphic tag -->
		</td>
	</tr>
</table>
		
<table border="0" width="96%" id="table3">
	<tr>
		<td>
		<p align="center" style="margin-top: 0; margin-bottom: 4px"><b>
		<a href="../PC_Training.php">Sales 
		Training<br>
		Materials</a></b></p>
		<p align="center" style="margin-top: 0; margin-bottom: 4px"><b>Including 
		the PC Manual</b></p>
		<p align="center" style="margin-top: 0; margin-bottom: 4px">
		<font size="2"><b><br>
		&nbsp;</b></font></p>
		<p align="center" style="margin-top: 0; margin-bottom: 4px"><b>Admin
		Area</b></p>
		<p align="center" style="margin-top: 0; margin-bottom: 4px">
		<a target="main" href="http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/Administrative%20Links.php"> Administrative Links</a></p>
		<p align="center" style="margin-top: 0; margin-bottom: 4px">
		<a target="main" href="http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/quotes/quotes_menu.php">Quotes DBase</a></p></td>
	</tr>
</table>

</body>

</html>