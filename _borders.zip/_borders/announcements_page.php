<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>AHC Announcements</title>

<!-- <meta name="Microsoft Border" content> -->
</head>

<body topmargin="1" leftmargin="1" rightmargin="1" bottommargin="1" background="top_gradient.jpg">

<table border="0" width="100%" id="table1">
	<tr>
		<td width="412">

<p align="left" style="margin-top: 0; margin-bottom: 0"><b><i>
<font color="#000080">Announcements:</font></i></b></p>
		<p align="left" style="margin-top: 0; margin-bottom: 0"><font size="2">
To try out the new sales hypnosis recording I put on line go to:<br>
<a href="http://ahc.webexone.com/r.asp?a=306828&id=599023" target="_top">http://ahc.webexone.com/r.asp?a=306828&id=599023</a>
</font></p>
<p align="left" style="margin-top: 0; margin-bottom: 0"><font size="2">Cheers,</font></p>
<p align="left" style="margin-top: 0; margin-bottom: 0"><font size="2">Larry</font></p></td>
	</tr>
</table>

</body>

</html>
