vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Mar 2005 05:32:18 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|10 Mar 2005 05:32:18 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|10 Mar 2005 05:32:19 -0000
vti_filesize:IR|9293
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
