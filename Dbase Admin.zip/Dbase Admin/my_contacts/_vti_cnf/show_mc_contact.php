vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Apr 2006 21:56:47 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|29 Mar 2006 08:35:16 -0000
vti_title:SR|American Hypnosis Clinic Contacts: Read-only Contact Details
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|29 Mar 2006 08:35:16 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:52 -0000
vti_filesize:IR|5251
vti_cachedtitle:SR|American Hypnosis Clinic Contacts: Read-only Contact Details
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_mc_contactsbyname.php H|show_mc_contactsbycompany.php H|contact_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbyname.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbycompany.php FHUS|Dbase\\ Admin/my_contacts/contact_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
