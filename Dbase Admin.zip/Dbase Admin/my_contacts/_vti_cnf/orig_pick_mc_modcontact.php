vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|19 Apr 2006 21:59:01 -0000
vti_timecreated:TR|23 Mar 2006 19:48:32 -0000
vti_title:SR|AHC Contacts: Modify a Contact
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/my_contacts/Copy\\ of\\ contact_menu.php
vti_nexttolasttimemodified:TR|26 Mar 2006 15:59:48 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:52 -0000
vti_filesize:IR|2426
vti_cachedtitle:SR|AHC Contacts: Modify a Contact
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|contact_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/my_contacts/contact_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
