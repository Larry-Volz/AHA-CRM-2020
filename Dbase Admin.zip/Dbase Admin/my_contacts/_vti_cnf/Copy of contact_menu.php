vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:59:00 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|28 Mar 2006 01:49:00 -0000
vti_title:SR|AHC Contacts: Main Menu
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|28 Mar 2006 01:49:00 -0000
vti_cacheddtm:TX|19 Apr 2006 22:10:33 -0000
vti_filesize:IR|2552
vti_cachedtitle:SR|AHC Contacts: Main Menu
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_mc_addcontact.php H|orig_pick_mc_modcontact.php H|pick_mc_delcontact.php H|show_mc_contactsbyname.php H|show_mc_contactsbycompany.php -S|../../right_border_testimonials.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/my_contacts/show_mc_addcontact.php FHUS|Dbase\\ Admin/my_contacts/orig_pick_mc_modcontact.php FHUS|Dbase\\ Admin/my_contacts/pick_mc_delcontact.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbyname.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbycompany.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
