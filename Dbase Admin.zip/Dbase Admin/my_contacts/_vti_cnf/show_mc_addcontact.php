vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|24 Apr 2006 21:37:16 -0000
vti_timecreated:TR|23 Mar 2006 22:19:20 -0000
vti_title:SR|My Contact Management System: Add a Contact
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/my_contacts/Copy\\ of\\ contact_menu.php Dbase\\ Admin/my_contacts/contact_menu.php Dbase\\ Admin/my_contacts/do_mc_addcontact.php
vti_nexttolasttimemodified:TR|31 Mar 2006 20:27:56 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:52 -0000
vti_filesize:IR|3347
vti_cachedtitle:SR|My Contact Management System: Add a Contact
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|do_mc_addcontact.php H|contact_menu.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/my_contacts/do_mc_addcontact.php FHUS|Dbase\\ Admin/my_contacts/contact_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
