vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|19 Apr 2006 21:59:01 -0000
vti_timecreated:TR|26 Mar 2006 23:41:58 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/my_contacts/Copy\\ of\\ show_mc_modcontact.php Dbase\\ Admin/my_contacts/Copy\\ of\\ do_mc_modcontact.php Dbase\\ Admin/my_contacts/show_mc_modcontact.php
vti_title:SR|AHC Contacts: Modify a Contact
vti_nexttolasttimemodified:TR|29 Mar 2006 18:58:55 -0000
vti_cacheddtm:TX|19 Apr 2006 21:59:01 -0000
vti_filesize:IR|4295
vti_cachedtitle:SR|AHC Contacts: Modify a Contact
vti_cachedbodystyle:SR|<body bgcolor="">
vti_cachedlinkinfo:VX|H|show_mc_contactsbyname.php H|show_mc_contactsbycompany.php H|contact_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbyname.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbycompany.php FHUS|Dbase\\ Admin/my_contacts/contact_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
