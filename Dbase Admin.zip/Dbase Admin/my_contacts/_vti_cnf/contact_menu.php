vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|24 Apr 2006 21:31:54 -0000
vti_timecreated:TR|23 Mar 2006 06:41:21 -0000
vti_title:SR|AHC Contacts: Main Menu
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/my_contacts/orig_pick_mc_modcontact.php Dbase\\ Admin/my_contacts/show_mc_contactsbycompany.php Dbase\\ Admin/my_contacts/show_mc_contact.php Dbase\\ Admin/my_contacts/show_mc_addcontact.php Dbase\\ Admin/my_contacts/Copy\\ of\\ do_mc_modcontact.php Dbase\\ Admin/my_contacts/show_mc_delcontact.php Dbase\\ Admin/my_contacts/pick_mc_delcontact.php Dbase\\ Admin/my_contacts/pick_mc_modcontact.php Dbase\\ Admin/my_contacts/do_mc_addcontact.php Dbase\\ Admin/my_contacts/do_mc_delcontact.php Dbase\\ Admin/my_contacts/orig_show_mc_modcontact.php Dbase\\ Admin/my_contacts/orig_do_mc_modcontact.php Dbase\\ Admin/my_contacts/do_mc_modcontact.php Dbase\\ Admin/my_contacts/show_mc_contactsbyname.php
vti_nexttolasttimemodified:TR|18 Apr 2006 06:42:26 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:49 -0000
vti_filesize:IR|4258
vti_cachedtitle:SR|AHC Contacts: Main Menu
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_mc_addcontact.php H|pick_mc_modcontact.php H|show_mc_contactsbyname.php H|show_mc_contactsbycompany.php H|pick_mc_delcontact.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/my_contacts/show_mc_addcontact.php FHUS|Dbase\\ Admin/my_contacts/pick_mc_modcontact.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbyname.php FHUS|Dbase\\ Admin/my_contacts/show_mc_contactsbycompany.php FHUS|Dbase\\ Admin/my_contacts/pick_mc_delcontact.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
