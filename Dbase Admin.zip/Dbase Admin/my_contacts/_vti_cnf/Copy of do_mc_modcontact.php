vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:59:00 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|27 Mar 2006 07:32:02 -0000
vti_backlinkinfo:VX|
vti_title:SR|AHC Contacts: Modify a Contact
vti_cacheddtm:TX|19 Apr 2006 21:59:00 -0000
vti_filesize:IR|4562
vti_cachedtitle:SR|AHC Contacts: Modify a Contact
vti_cachedbodystyle:SR|<body bgcolor="">
vti_cachedlinkinfo:VX|A|do_mc_modcontact.php H|contact_menu.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/my_contacts/do_mc_modcontact.php FHUS|Dbase\\ Admin/my_contacts/contact_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
vti_nexttolasttimemodified:TR|27 Mar 2006 08:21:22 -0000
