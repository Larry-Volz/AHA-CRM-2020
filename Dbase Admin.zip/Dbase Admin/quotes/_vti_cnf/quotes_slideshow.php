vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:59:02 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|26 Mar 2006 07:11:49 -0000
vti_title:SR|COUNT ME!
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|26 Mar 2006 07:11:49 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:54 -0000
vti_filesize:IR|4676
vti_cachedtitle:SR|COUNT ME!
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
