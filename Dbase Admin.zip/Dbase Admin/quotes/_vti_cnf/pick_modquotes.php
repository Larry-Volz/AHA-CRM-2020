vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:59:02 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|26 Mar 2006 02:27:37 -0000
vti_title:SR|AHC Testimonials: Modify a Quote
vti_backlinkinfo:VX|Dbase\\ Admin/quotes/quotes_menu.php
vti_nexttolasttimemodified:TR|26 Mar 2006 02:27:37 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:53 -0000
vti_filesize:IR|3122
vti_cachedtitle:SR|AHC Testimonials: Modify a Quote
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|quotes_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/quotes/quotes_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
