vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Apr 2007 14:44:11 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|LarryVolzAcer\\Larry Volz
vti_timecreated:TR|16 Apr 2006 04:18:15 -0000
vti_title:SR|Store Locator Admin Panel - Add Custom Field
vti_nexttolasttimemodified:TR|08 Feb 2007 19:26:40 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|01 Apr 2007 14:44:12 -0000
vti_filesize:IR|4648
vti_cachedtitle:SR|Store Locator Admin Panel - Add Custom Field
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|images/style.css S|menu/JSCookMenu.js Q|menu/themes/Office/theme.css S|menu/themes/Office/theme.js S|images/bg_top.gif S|images/logo.gif S|images/dot.gif S|images/dot.gif S|images/dot.gif S|images/dot.gif H|http://www.ghostscripter.com
vti_cachedsvcrellinks:VX|FQUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/style.css FSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/menu/JSCookMenu.js FQUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/menu/themes/Office/theme.css FSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/menu/themes/Office/theme.js FSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/bg_top.gif FSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/logo.gif NSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/dot.gif NSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/dot.gif NSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/dot.gif NSUS|AHC\\ Intranet/Dbase\\ Admin/affiliates/store_locator/adm/images/dot.gif NHHS|http://www.ghostscripter.com
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|true
vti_cachedhasborder:BR|true
vti_themeaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=iso-8859-1
vti_charset:SR|iso-8859-1
