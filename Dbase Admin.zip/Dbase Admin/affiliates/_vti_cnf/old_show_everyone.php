vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 May 2006 18:38:55 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|03 May 2006 18:38:55 -0000
vti_cacheddtm:TX|03 May 2006 18:38:55 -0000
vti_filesize:IR|3031
vti_cachedtitle:SR|American Hypnosis Clinic: Everyone in Affiliates DB
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|affiliates_menu.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
vti_title:SR|American Hypnosis Clinic: Everyone in Affiliates DB
vti_backlinkinfo:VX|
