vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Apr 2006 04:52:01 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|04 Apr 2006 23:11:07 -0000
vti_title:SR|AHC Affiliates: Affiliate Deleted
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/pick_delaffiliate.php Dbase\\ Admin/affiliates/verify_deleteaffiliate.php
vti_nexttolasttimemodified:TR|18 Apr 2006 18:33:01 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:32 -0000
vti_filesize:IR|4792
vti_cachedtitle:SR|AHC Affiliates: Affiliate Deleted
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
