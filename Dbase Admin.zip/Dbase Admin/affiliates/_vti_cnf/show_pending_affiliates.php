vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Apr 2006 05:26:08 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|04 Apr 2006 21:23:07 -0000
vti_title:SR|American Hypnosis Clinic: Pending Affiliates Listed By Name
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/affiliates_menu2.php Dbase\\ Admin/affiliates/affiliates_menu.php
vti_nexttolasttimemodified:TR|11 Apr 2006 06:45:38 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:37 -0000
vti_filesize:IR|2984
vti_cachedtitle:SR|American Hypnosis Clinic: Pending Affiliates Listed By Name
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
