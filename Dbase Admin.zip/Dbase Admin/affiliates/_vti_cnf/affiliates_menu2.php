vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Aug 2006 17:49:27 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|22 Aug 2006 17:49:27 -0000
vti_cacheddtm:TX|22 Aug 2006 17:49:27 -0000
vti_filesize:IR|8406
vti_cachedtitle:SR|AHC Affiliates: Main Menu
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_affiliatesbystate.php H|show_affiliatesbylname.php H|show_affiliatesbyorg.php H|show_addaffiliate.php H|show_affil_leads_bystate.php H|show_affil_leads_byname.php H|show_affil_leads_bycontactnext.php H|show_affil_leads_bymodified.php H|show_pending_affiliates.php H|show_everyone.php H|pick_delaffiliate.php A|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/do_closest_therapist2.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/show_affiliatesbystate.php FHUS|Dbase\\ Admin/affiliates/show_affiliatesbylname.php FHUS|Dbase\\ Admin/affiliates/show_affiliatesbyorg.php FHUS|Dbase\\ Admin/affiliates/show_addaffiliate.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bystate.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_byname.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bycontactnext.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bymodified.php FHUS|Dbase\\ Admin/affiliates/show_pending_affiliates.php FHUS|Dbase\\ Admin/affiliates/show_everyone.php FHUS|Dbase\\ Admin/affiliates/pick_delaffiliate.php NAHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/do_closest_therapist2.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
vti_title:SR|AHC Affiliates: Main Menu
vti_backlinkinfo:VX|
