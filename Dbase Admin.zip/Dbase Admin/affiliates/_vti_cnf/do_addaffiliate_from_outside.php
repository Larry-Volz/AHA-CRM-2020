vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Aug 2006 17:46:22 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|04 Apr 2006 06:38:25 -0000
vti_title:SR|Contact Added
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|15 Apr 2006 22:56:28 -0000
vti_cacheddtm:TX|22 Aug 2006 17:46:22 -0000
vti_filesize:IR|26365
vti_cachedtitle:SR|Contact Added
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|http://www.americanhypnosisclinic.com
vti_cachedsvcrellinks:VX|NHHS|http://www.americanhypnosisclinic.com
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
