vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Jul 2006 19:50:58 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|05 Apr 2006 20:19:34 -0000
vti_title:SR|American Hypnosis Clinic Contacts: Affiliate Details
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|18 Apr 2006 18:39:49 -0000
vti_cacheddtm:TX|20 Aug 2006 15:59:51 -0000
vti_filesize:IR|12038
vti_cachedtitle:SR|American Hypnosis Clinic Contacts: Affiliate Details
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|show_modaffiliate_getmethod.php H|affiliates_menu.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/affiliates/show_modaffiliate_getmethod.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
