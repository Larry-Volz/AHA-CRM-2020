vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Jul 2006 16:23:39 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|21 Apr 2006 18:08:34 -0000
vti_title:SR|American Hypnosis Clinic Contacts: Affiliate Details
vti_backlinkinfo:VX|
vti_cacheddtm:TX|20 Aug 2006 15:59:51 -0000
vti_filesize:IR|10401
vti_cachedtitle:SR|American Hypnosis Clinic Contacts: Affiliate Details
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|show_modaffiliate.php H|affiliates_menu.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|NAUS|Dbase\\ Admin/affiliates/show_modaffiliate.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
