vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|04 Sep 2006 04:14:18 -0000
vti_timecreated:TR|04 Sep 2006 04:01:23 -0000
vti_title:SR|New Page 2
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|04 Sep 2006 04:08:09 -0000
vti_cacheddtm:TX|04 Sep 2006 04:14:18 -0000
vti_filesize:IR|1905
vti_cachedtitle:SR|New Page 2
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|do_nearest_big_city.php
vti_cachedsvcrellinks:VX|NAUS|Dbase\\ Admin/affiliates/do_nearest_big_city.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
