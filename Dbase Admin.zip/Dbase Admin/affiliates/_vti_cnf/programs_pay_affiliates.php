vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|15 Apr 2006 03:19:44 -0000
vti_timecreated:TR|14 Apr 2006 08:11:46 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|15 Apr 2006 03:13:27 -0000
vti_cacheddtm:TX|15 Apr 2006 03:19:45 -0000
vti_filesize:IR|4796
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
