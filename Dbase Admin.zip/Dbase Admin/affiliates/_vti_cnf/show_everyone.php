vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 May 2006 19:01:32 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|11 Apr 2006 06:11:22 -0000
vti_title:SR|American Hypnosis Clinic: Everyone in Affiliates DB
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/affiliates_menu2.php Dbase\\ Admin/affiliates/affiliates_menu.php Dbase\\ Admin/affiliates/verify_deleteaffiliate.php
vti_nexttolasttimemodified:TR|18 Apr 2006 18:43:33 -0000
vti_cacheddtm:TX|03 May 2006 19:01:32 -0000
vti_filesize:IR|4066
vti_cachedtitle:SR|American Hypnosis Clinic: Everyone in Affiliates DB
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|../../../FORMfields/tableHelpers.css H|affiliates_menu.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|NQUS|file:///C:/Program\\ Files/xampp/htdocs/FORMfields/tableHelpers.css FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
