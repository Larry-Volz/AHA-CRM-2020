vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:58:52 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|04 Apr 2006 22:42:06 -0000
vti_title:SR|AHC Affiliates: Delete an Affiliate
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/affiliates_menu2.php Dbase\\ Admin/affiliates/affiliates_menu.php
vti_nexttolasttimemodified:TR|18 Apr 2006 06:56:18 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:36 -0000
vti_filesize:IR|3057
vti_cachedtitle:SR|AHC Affiliates: Delete an Affiliate
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|D|affiliates_menu.php A|do_delaffiliate.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FDUS|Dbase\\ Admin/affiliates/affiliates_menu.php FAUS|Dbase\\ Admin/affiliates/do_delaffiliate.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
