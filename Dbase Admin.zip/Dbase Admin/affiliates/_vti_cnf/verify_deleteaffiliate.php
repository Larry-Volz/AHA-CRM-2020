vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 May 2006 19:11:29 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|03 May 2006 19:11:29 -0000
vti_cacheddtm:TX|03 May 2006 19:11:29 -0000
vti_filesize:IR|1024
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|do_delaffiliate.php H|show_everyone.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/affiliates/do_delaffiliate.php FHUS|Dbase\\ Admin/affiliates/show_everyone.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
vti_backlinkinfo:VX|
