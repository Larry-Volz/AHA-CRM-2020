vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Apr 2006 12:50:23 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|05 Apr 2006 06:23:44 -0000
vti_title:SR|American Hypnosis Clinic: Active Affiliates Listed By State
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/affiliates_menu2.php Dbase\\ Admin/affiliates/affiliates_menu.php
vti_nexttolasttimemodified:TR|18 Apr 2006 18:44:00 -0000
vti_cacheddtm:TX|03 May 2006 01:14:32 -0000
vti_filesize:IR|4107
vti_cachedtitle:SR|American Hypnosis Clinic: Active Affiliates Listed By State
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|../../../FORMfields/tableHelpers.css H|affiliates_menu.php H|affiliates_menu.php
vti_cachedsvcrellinks:VX|NQUS|file:///C:/Program\\ Files/xampp/htdocs/FORMfields/tableHelpers.css FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
