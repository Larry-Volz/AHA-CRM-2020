vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|21 Aug 2006 05:07:25 -0000
vti_timecreated:TR|30 Mar 2006 07:56:52 -0000
vti_title:SR|AHC Affiliates: Main Menu
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/show_affil_leads_bymodified.php Dbase\\ Admin/affiliates/old\\ -\\ show_addaffiliate.php Dbase\\ Admin/affiliates/show_pending_affiliates.php Dbase\\ Admin/affiliates/old\\ -\\ pick_modaffiliate.php Dbase\\ Admin/affiliates/old_show_everyone.php Dbase\\ Admin/affiliates/do_delaffiliate.php Dbase\\ Admin/affiliates/show_affiliatesbystate.php _borders/left.php Dbase\\ Admin/affiliates/old_do_closest_therapist.php Dbase\\ Admin/affiliates/show_affil_leads_byname.php Dbase\\ Admin/affiliates/do_addaffiliate.php Dbase\\ Admin/affiliates/pick_delaffiliate.php Dbase\\ Admin/affiliates/show_affiliate.php Dbase\\ Admin/affiliates/show_affil_leads_bystate.php Dbase\\ Admin/affiliates/show_affiliatesbylname.php Dbase\\ Admin/affiliates/show_affil_leads_bycontactnext.php Dbase\\ Admin/affiliates/show_everyone.php _borders/old-half-wrecked-left.php Dbase\\ Admin/affiliates/copy_of_show_affiliate.php Dbase\\ Admin/affiliates/show_affiliatesbyorg.php
vti_nexttolasttimemodified:TR|18 Apr 2006 19:16:59 -0000
vti_cacheddtm:TX|21 Aug 2006 05:07:25 -0000
vti_filesize:IR|8405
vti_cachedtitle:SR|AHC Affiliates: Main Menu
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_affiliatesbystate.php H|show_affiliatesbylname.php H|show_affiliatesbyorg.php H|show_addaffiliate.php H|show_affil_leads_bystate.php H|show_affil_leads_byname.php H|show_affil_leads_bycontactnext.php H|show_affil_leads_bymodified.php H|show_pending_affiliates.php H|show_everyone.php H|pick_delaffiliate.php A|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/do_closest_therapist.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/show_affiliatesbystate.php FHUS|Dbase\\ Admin/affiliates/show_affiliatesbylname.php FHUS|Dbase\\ Admin/affiliates/show_affiliatesbyorg.php FHUS|Dbase\\ Admin/affiliates/show_addaffiliate.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bystate.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_byname.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bycontactnext.php FHUS|Dbase\\ Admin/affiliates/show_affil_leads_bymodified.php FHUS|Dbase\\ Admin/affiliates/show_pending_affiliates.php FHUS|Dbase\\ Admin/affiliates/show_everyone.php FHUS|Dbase\\ Admin/affiliates/pick_delaffiliate.php NAHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/do_closest_therapist.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
