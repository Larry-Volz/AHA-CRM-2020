vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|22 Aug 2006 17:47:32 -0000
vti_timecreated:TR|30 Mar 2006 20:46:13 -0000
vti_title:SR|Contact Added
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/affiliates/old\\ -\\ show_addaffiliate.php Dbase\\ Admin/affiliates/show_addaffiliate.php Dbase\\ Admin/affiliates/AffiliateApplication.php
vti_nexttolasttimemodified:TR|18 Apr 2006 18:31:45 -0000
vti_cacheddtm:TX|22 Aug 2006 17:47:32 -0000
vti_filesize:IR|24818
vti_cachedtitle:SR|Contact Added
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|affiliates_menu.php H|show_addaffiliate.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php FHUS|Dbase\\ Admin/affiliates/show_addaffiliate.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
