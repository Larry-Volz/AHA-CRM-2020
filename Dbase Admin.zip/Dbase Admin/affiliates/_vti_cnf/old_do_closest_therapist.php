vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Aug 2006 16:40:57 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|20 Aug 2006 16:40:57 -0000
vti_cacheddtm:TX|20 Aug 2006 16:40:57 -0000
vti_filesize:IR|7426
vti_cachedtitle:SR|American Hypnosis Clinic Office Near THIS CLIENT
vti_cachedbodystyle:SR|<BODY>
vti_cachedlinkinfo:VX|H|affiliates_menu.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/affiliates/affiliates_menu.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
vti_title:SR|American Hypnosis Clinic Office Near THIS CLIENT
vti_backlinkinfo:VX|
