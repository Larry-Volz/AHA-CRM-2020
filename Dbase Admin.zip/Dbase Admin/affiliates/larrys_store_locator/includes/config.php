<?php
// Database Host
$DBHost = 'localhost';

// Database Name
$DBName = 'america2_AHC';

// Database Username
$DBUser = 'america2_larryvo';

// Database Password
$DBPass = 'magiclar';

// Radius in which a store can be counted as nearby
$store_radius = '20';

// Admin Email Address
$admin_email = 'larry@americanhypnosisclinic.com';

// Template Folder Name
$tpl_name = 'default';

DEFINE('IS_INSTALLED', 1);?>