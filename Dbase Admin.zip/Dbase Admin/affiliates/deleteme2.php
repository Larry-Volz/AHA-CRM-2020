<?

$now=time();
echo $now;
$converted = cal_from_jd($now);
echo $converted;
 
?>