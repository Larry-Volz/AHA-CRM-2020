<?

$programsPayAffiliates="<table border=\"1\" width=\"74%\" id=\"table1\">
	<tr>
		<td width=\"293\" align=\"center\" bgcolor=\"#CCCCFF\"><b>Programs</b></td>
		<td width=\"140\" align=\"center\" bgcolor=\"#CCCCFF\"><b>We Pay Affiliates</b></td>
		<td width=\"138\" align=\"center\" bgcolor=\"#CCCCFF\"><b>Ave Number of 
		Sessions<br>
		for This Goal</b></td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Drug or Alcohol Self Control&nbsp; </td>
		<td width=\"140\" align=\"right\">\$1,197.00 </td>
		<td width=\"138\" align=\"center\">2-6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Emotional Self Improvement [depression] </td>
		<td width=\"140\" align=\"right\">\$720.00 </td>
		<td width=\"138\" align=\"center\">3-6</td>
	</tr>
	<tr>
		<td width=\"293\">Fibromyalgia [Single Session Hour]</td>
		<td width=\"140\" align=\"right\">\$90.00</td>
		<td width=\"138\" align=\"center\">13</td>
	</tr>
	<tr>
		<td width=\"293\">Fibromyalgia [Complete Program 13 sessions]</td>
		<td width=\"140\" align=\"right\">\$1,093.50</td>
		<td width=\"138\" align=\"center\">13</td>
	</tr>
	<tr>
		<td width=\"293\">Gambling</td>
		<td width=\"140\" align=\"right\">\$537.00</td>
		<td width=\"138\" align=\"center\">1-3</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;High Blood Pressure [Single Session]</td>
		<td width=\"140\" align=\"right\">\$90.00</td>
		<td width=\"138\" align=\"center\">6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;High Blood Pressure [Complete Program 6 sessions]</td>
		<td width=\"140\" align=\"right\">\$526.50</td>
		<td width=\"138\" align=\"center\">6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Irritable Bowel Syndrome [Single Session]</td>
		<td width=\"140\" align=\"right\">\$90.00</td>
		<td width=\"138\" align=\"center\">6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Irritable Bowel Syndrome [Complete Program 6 
		sessions]</td>
		<td width=\"140\" align=\"right\">\$526.50</td>
		<td width=\"138\" align=\"center\">6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Learning Improvement [ADD/ADHD]</td>
		<td width=\"140\" align=\"right\">\$477.00</td>
		<td width=\"138\" align=\"center\">4-6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Memory Improvement</td>
		<td width=\"140\" align=\"right\">\$417.00</td>
		<td width=\"138\" align=\"center\">2-3</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Morning Sickness</td>
		<td width=\"140\" align=\"right\">\$357.00</td>
		<td width=\"138\" align=\"center\">1-2</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Motivation </td>
		<td width=\"140\" align=\"right\">\$477.00</td>
		<td width=\"138\" align=\"center\">3-4</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Impulse Control [Obsessive Compulsive] </td>
		<td width=\"140\" align=\"right\">\$537.00</td>
		<td width=\"138\" align=\"center\">2-5</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Pain Management</td>
		<td width=\"140\" align=\"right\">\$417.00</td>
		<td width=\"138\" align=\"center\">2-3</td>
	</tr>
	<tr>
		<td width=\"293\">Phobia</td>
		<td width=\"140\" align=\"right\">\$537.00</td>
		<td width=\"138\" align=\"center\">2-3</td>
	</tr>
	<tr>
		<td width=\"293\">Regression</td>
		<td width=\"140\" align=\"right\">\$135.00</td>
		<td width=\"138\" align=\"center\">1</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Self-Esteem</td>
		<td width=\"140\" align=\"right\">\$477.00</td>
		<td width=\"138\" align=\"center\">3-4</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Sexual issues</td>
		<td width=\"140\" align=\"right\">\$537.00</td>
		<td width=\"138\" align=\"center\">2-5</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Sleep</td>
		<td width=\"140\" align=\"right\">\$357.00</td>
		<td width=\"138\" align=\"center\">2-3</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Smoking</td>
		<td width=\"140\" align=\"right\">\$297.00</td>
		<td width=\"138\" align=\"center\">1-2</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Stress/Anxiety</td>
		<td width=\"140\" align=\"right\">\$357.00</td>
		<td width=\"138\" align=\"center\">1-3</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Unusual Per-HOUR Issues [need approval]</td>
		<td width=\"140\" align=\"right\">\$90.00</td>
		<td width=\"138\" align=\"center\">1</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Unusual Per-SESSION Issues [need approval]</td>
		<td width=\"140\" align=\"right\">\$90.00</td>
		<td width=\"138\" align=\"center\">1</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Weight Loss</td>
		<td width=\"140\" align=\"right\">\$591.00</td>
		<td width=\"138\" align=\"center\">3-6</td>
	</tr>
	<tr>
		<td width=\"293\">&nbsp;Wellness</td>
		<td width=\"140\" align=\"right\">\$1,800.00</td>
		<td width=\"138\" align=\"center\">6-15</td>
	</tr>
</table>";


?>

