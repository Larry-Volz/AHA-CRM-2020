<?php


?>
<html>

<head>
  <title></title>
<meta name="Microsoft Border" content="r, default">
</head>

<body><!--msnavigation--><table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%"><tr><!--msnavigation--><td valign="top">



<table border="1" width="24%" id="table1">
	<tr>
		<td>
		<p align="center">Find The Closest Therapist</p>
		<form method="POST" action="http://www.americanhypnosisclinic.com/intranet/Dbase%20Admin/affiliates/do_closest_therapist.php">

			<input type="hidden" value="1"><!-- PUT CLIENT ID # HERE FROM SENDING PAGE!!! -->

			<p align="center">Enter State:<br>
<select name="client_state">
	<option value="">Client's State...</option>
	<option value="AL">Alabama (AL)</option>
	<option value="AK">Alaska (AK)</option>
	<option value="AZ">Arizona (AZ)</option>
	<option value="AR">Arkansas (AR)</option>
	<option value="CA">California (CA)</option>
	<option value="CO">Colorado (CO)</option>
	<option value="CT">Connecticut (CT)</option>
	<option value="DE">Delaware (DE)</option>
	<option value="DC">Washington DC</option>
	<option value="FL">Florida (FL)</option>
	<option value="GA">Georgia (GA)</option>
	<option value="HI">Hawaii (HI)</option>
	<option value="ID">Idaho (ID)</option>
	<option value="IL">Illinois (IL)</option>
	<option value="IN">Indiana (IN)</option>
	<option value="IA">Iowa (IA)</option>
	<option value="KS">Kansas (KS)</option>
	<option value="KY">Kentucky (KY)</option>
	<option value="LA">Louisiana (LA)</option>
	<option value="ME">Maine (ME)</option>
	<option value="MD">Maryland (MD)</option>
	<option value="MA">Massachusetts (MA)</option>
	<option value="MI">Michigan (MI)</option>
	<option value="MN">Minnesota (MN)</option>
	<option value="MS">Mississippi (MS)</option>
	<option value="MO">Missouri (MO)</option>
	<option value="MT">Montana (MT)</option>
	<option value="NE">Nebraska (NE)</option>
	<option value="NV">Nevada (NV)</option>
	<option value="NH">New Hampshire (NH)</option>
	<option value="NJ">New Jersey (NJ)</option>
	<option value="NM">New Mexico (NM)</option>
	<option value="NY">New York (NY)</option>
	<option value="NC">North Carolina (NC)</option>
	<option value="ND">North Dakota (ND)</option>
	<option value="OH">Ohio (OH)</option>
	<option value="OK">Oklahoma (OK)</option>
	<option value="OR">Oregon (OR)</option>
	<option value="PA">Pennsylvania (PA)</option>
	<option value="RI">Rhode Island (RI)</option>
	<option value="SC">South Carolina (SC)</option>
	<option value="SD">South Dakota (SD)</option>
	<option value="TN">Tennessee (TN)</option>
	<option value="TX">Texas (TX)</option>
	<option value="UT">Utah (UT)</option>
	<option value="VT">Vermont (VT)</option>
	<option value="VA" >Virginia (VA)</option>
	<option value="WA">Washington (WA)</option>
	<option value="WV">West Virginia (WV)</option>
	<option value="WI">Wisconsin (WI)</option>
	<option value="WY">Wyoming (WY)</option>
</select>
			</p>

			<p align="center">and Zip Code:<br>
			<input type="text" name="client_zip" size="20" maxlength="5"></p>

			<p align="center"><input type="submit" value="Submit" name="B1"></p>

		</form>

		<p align="center">&nbsp;</td>
	</tr>
</table>



<!--msnavigation--></td><td valign="top" width="24"></td><td valign="top" width="1%">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table></body>

</html>