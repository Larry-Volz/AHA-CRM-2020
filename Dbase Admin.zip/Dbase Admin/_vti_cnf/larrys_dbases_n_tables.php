vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Oct 2006 16:27:07 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TR|19 Apr 2006 00:18:39 -0000
vti_timecreated:TR|20 Mar 2006 05:56:08 -0000
vti_title:SR|My SQL Tables
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_cacheddtm:TX|01 Oct 2006 16:27:07 -0000
vti_filesize:IR|2328
vti_cachedtitle:SR|My SQL Tables
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|Administrative\\ Links.php H|../index.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/Administrative\\ Links.php NHUS|index.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
