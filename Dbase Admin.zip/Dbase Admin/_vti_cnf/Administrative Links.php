vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Oct 2006 16:27:07 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|18 Apr 2006 17:11:40 -0000
vti_title:SR|Links to Dbas Administrative Tools
vti_backlinkinfo:VX|Dbase\\ Admin/larrys_dbases_n_tables.php Dbase\\ Admin/User\\ Authentication/no_permission.htm
vti_nexttolasttimemodified:TR|18 Apr 2006 17:11:40 -0000
vti_cacheddtm:TX|01 Oct 2006 16:27:07 -0000
vti_filesize:IR|2905
vti_cachedtitle:SR|Links to Dbas Administrative Tools
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/ H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/larrys_dbases_n_tables.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/Create\\ Table\\ and\\ field\\ defs/show_createtable.htm H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/view_all_clients_field_defs.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/User\\ Authentication/show_adduser.htm H|User\\ Authentication/show_modpasswords.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/financial/show_programfinancial.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/auth_users/pick_member_activities.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/all_clients/show_createview.php H|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/show_e-mail_affiliates.htm
vti_cachedsvcrellinks:VX|NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/ NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/larrys_dbases_n_tables.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/Create\\ Table\\ and\\ field\\ defs/show_createtable.htm NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/view_all_clients_field_defs.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/User\\ Authentication/show_adduser.htm FHUS|Dbase\\ Admin/User\\ Authentication/show_modpasswords.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/financial/show_programfinancial.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/auth_users/pick_member_activities.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/all_clients/show_createview.php NHHS|http://www.americanhypnosisclinic.com/intranet/Dbase\\ Admin/affiliates/show_e-mail_affiliates.htm
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
