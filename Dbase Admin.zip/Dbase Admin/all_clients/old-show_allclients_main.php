<?
if ($_POST['f_name']){

$f_name=$_POST['f_name'];

}

?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="Microsoft Border" content="r, default">
</head>

<body bgcolor="#CCCCFF"><!--msnavigation--><table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%"><tr><!--msnavigation--><td valign="top">

<table border="0" width="100%" id="table1">
	<tr>
		<td width="489"><b><font size="6">All Clients</font></b><i><br>
		<b><font size="5" color="#000080">Main Control Panel</font></b></i></td>
		<td>&nbsp;</td>
	</tr>
</table>
<p style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
<table border="0" width="770" id="table3">
	<tr>
		<td>
		<p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;</p>
		<p align="center" style="margin-top: 0; margin-bottom: 0"><b><i>
		<font color="#000080" style="font-size: 20pt">Vital Information<br>
		</font></i></b><strong><font color="#FF0000">*NOT SAVED*</font></strong></td>
	</tr>
</table>
<p style="margin-top: 0; margin-bottom: 0">
<iframe name="show_vitalinfo" src="show_modclient.php" width="765" height="785">
Your browser does not support inline frames or is currently configured not to display inline frames.
</iframe></p>
<div align="center">

<table border="0" width="762" id="table2">
	<tr>
		<td>
		<p align="center" style="margin-top: 0; margin-bottom: 0">
		<font color="#000080"><span style="font-size: 20pt; font-style: italic">
		Financial Planning<br>
		</span></font><font color="#FF0000"><b>* NOT SAVED *</b></font></td>
	</tr>
</table>

</div>
<p style="margin-top: 0; margin-bottom: 0">
<iframe name="I3" src="show_financial.php" width="763" height="518" scrolling="no">
Your browser does not support inline frames or is currently configured not to display inline frames.
</iframe></p>
<table border="0" width="768" id="table4">
	<tr>
		<td>&nbsp;</td>
		<td>
		<p align="center">
		<font color="#000080" style="font-size: 20pt; font-weight: 700"><i>Scheduling<br>
		</i></font><font color="#FF0000"><b>* NOT SAVED *</b></font></td>
		<td>
		<p style="margin-top: 0; margin-bottom: 0">&nbsp;</td>
	</tr>
</table>
<p style="margin-top: 0; margin-bottom: 0">
<iframe name="I2" src="show_scheduling.php" width="764" height="465">
Your browser does not support inline frames or is currently configured not to display inline frames.
</iframe></p>

<!--msnavigation--></td><td valign="top" width="24"></td><td valign="top" width="1%">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table></body>

</html>