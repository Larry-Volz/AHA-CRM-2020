vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:47 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TR|12 Apr 2006 07:41:54 -0000
vti_timecreated:TR|20 Mar 2006 06:35:34 -0000
vti_title:SR|Add a Client
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_cacheddtm:TX|08 Feb 2007 19:23:47 -0000
vti_filesize:IR|24485
vti_cachedtitle:SR|Add a Client
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|http://www.americanhypnosisclinic.com/style.css S|filterlist.js A|do_addrecord.php H|javascript:myfilter.set('^A') H|javascript:myfilter.set('^B') H|javascript:myfilter.set('^C') H|javascript:myfilter.set('^D') H|javascript:myfilter.set('^E') H|javascript:myfilter.set('^F') H|javascript:myfilter.set('^G') H|javascript:myfilter.set('^H') H|javascript:myfilter.set('^I') H|javascript:myfilter.set('^J') H|javascript:myfilter.set('^K') H|javascript:myfilter.set('^L') H|javascript:myfilter.set('^M') H|javascript:myfilter.set('^N') H|javascript:myfilter.set('^O') H|javascript:myfilter.set('^P') H|javascript:myfilter.set('^Q') H|javascript:myfilter.set('^R') H|javascript:myfilter.set('^S') H|javascript:myfilter.set('^T') H|javascript:myfilter.set('^U') H|javascript:myfilter.set('^V') H|javascript:myfilter.set('^W') H|javascript:myfilter.set('^X') H|javascript:myfilter.set('^Y') H|javascript:myfilter.set('^Z') H|javascript:myfilter.reset()
vti_cachedsvcrellinks:VX|NQHS|http://www.americanhypnosisclinic.com/style.css FSUS|Dbase\\ Admin/all_clients/filterlist.js NAUS|Dbase\\ Admin/all_clients/do_addrecord.php SHUS|javascript:myfilter.set('^A') SHUS|javascript:myfilter.set('^B') SHUS|javascript:myfilter.set('^C') SHUS|javascript:myfilter.set('^D') SHUS|javascript:myfilter.set('^E') SHUS|javascript:myfilter.set('^F') SHUS|javascript:myfilter.set('^G') SHUS|javascript:myfilter.set('^H') SHUS|javascript:myfilter.set('^I') SHUS|javascript:myfilter.set('^J') SHUS|javascript:myfilter.set('^K') SHUS|javascript:myfilter.set('^L') SHUS|javascript:myfilter.set('^M') SHUS|javascript:myfilter.set('^N') SHUS|javascript:myfilter.set('^O') SHUS|javascript:myfilter.set('^P') SHUS|javascript:myfilter.set('^Q') SHUS|javascript:myfilter.set('^R') SHUS|javascript:myfilter.set('^S') SHUS|javascript:myfilter.set('^T') SHUS|javascript:myfilter.set('^U') SHUS|javascript:myfilter.set('^V') SHUS|javascript:myfilter.set('^W') SHUS|javascript:myfilter.set('^X') SHUS|javascript:myfilter.set('^Y') SHUS|javascript:myfilter.set('^Z') SHUS|javascript:myfilter.reset()
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
