vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:51 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|08 Feb 2007 19:23:51 -0000
vti_cacheddtm:TX|08 Feb 2007 20:13:44 -0000
vti_filesize:IR|59804
vti_cachedtitle:SR|Create a view
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|S|../../includes/showhide_layers.js S|../../includes/calendarpopup.js S|../../images/spacer.gif S|../../images/spacer.gif S|../../images/spacer.gif S|../../images/spacer.gif S|../../images/spacer.gif S|../../images/spacer.gif K|show_createview_edit.php S|../../images/calendar_mic.gif
vti_cachedsvcrellinks:VX|FSUS|includes/showhide_layers.js FSUS|includes/calendarpopup.js NSUS|images/spacer.gif NSUS|images/spacer.gif NSUS|images/spacer.gif NSUS|images/spacer.gif NSUS|images/spacer.gif NSUS|images/spacer.gif FKUS|Dbase\\ Admin/all_clients/show_createview_edit.php FSUS|images/calendar_mic.gif
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
vti_title:SR|Create a view
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_createview_edit.php
