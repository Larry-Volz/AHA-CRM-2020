vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|08 Feb 2007 19:23:49 -0000
vti_timecreated:TR|26 Apr 2006 05:43:52 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_allclients_main.php _borders/left.php Dbase\\ Admin/all_clients/deleteme.php _borders/old-half-wrecked-left.php Dbase\\ Admin/all_clients/show_financial.php Dbase\\ Admin/all_clients/show_single_client.php Dbase\\ Admin/all_clients/show_scheduling.php
vti_nexttolasttimemodified:TW|30 Apr 2006 07:35:46 -0000
vti_cacheddtm:TX|08 Feb 2007 20:13:44 -0000
vti_filesize:IR|43408
vti_cachedtitle:SR|New Page 1
vti_cachedbodystyle:SR|<body onload="FP_preloadImgs(/*url*/'../../images/button11.jpg', /*url*/'../../images/button12.jpg', /*url*/'../../images/button19.jpg', /*url*/'../../images/button1A.jpg', /*url*/'../../images/button13.jpg', /*url*/'../../images/button14.jpg')">
vti_cachedlinkinfo:VX|S|../../includes/calendarpopup.js S|../../images/button11.jpg S|../../images/button12.jpg S|../../images/button19.jpg S|../../images/button1A.jpg S|../../images/button13.jpg S|../../images/button14.jpg Q|../../../FORMfields/tableHelpers.css H|show_addclient.php S|../../images/button11.jpg S|../../images/button10.jpg S|../../images/button12.jpg S|../../images/button11.jpg S|../../images/button10.jpg H|show_manage_allclients.php S|../../images/button19.jpg S|../../images/button18.jpg S|../../images/button1A.jpg S|../../images/button19.jpg S|../../images/button18.jpg A|show_allclients_main.php A|< A|<
vti_cachedsvcrellinks:VX|FSUS|includes/calendarpopup.js FSUS|images/button11.jpg FSUS|images/button12.jpg FSUS|images/button19.jpg FSUS|images/button1A.jpg FSUS|images/button13.jpg FSUS|images/button14.jpg NQUS|file:///C:/Documents\\ and\\ Settings/Larry\\ Volz/My\\ Documents/My\\ Web\\ Sites/FORMfields/tableHelpers.css FHUS|Dbase\\ Admin/all_clients/show_addclient.php FSUS|images/button11.jpg FSUS|images/button10.jpg FSUS|images/button12.jpg FSUS|images/button11.jpg FSUS|images/button10.jpg FHUS|Dbase\\ Admin/all_clients/show_manage_allclients.php FSUS|images/button19.jpg FSUS|images/button18.jpg FSUS|images/button1A.jpg FSUS|images/button19.jpg FSUS|images/button18.jpg FAUS|Dbase\\ Admin/all_clients/show_allclients_main.php DAUS|Dbase\\ Admin/all_clients/< DAUS|Dbase\\ Admin/all_clients/<
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
