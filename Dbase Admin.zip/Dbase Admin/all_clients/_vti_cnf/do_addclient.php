vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:43 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|02 May 2006 08:05:48 -0000
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_addclient.php
vti_cacheddtm:TX|08 Feb 2007 19:23:43 -0000
vti_filesize:IR|6314
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
