vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:47 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TR|26 Apr 2006 05:43:47 -0000
vti_timecreated:TR|12 Apr 2006 07:41:43 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_cacheddtm:TX|08 Feb 2007 19:23:47 -0000
vti_filesize:IR|2783
vti_cachedbodystyle:SR|<body bgcolor="#CCCCFF">
vti_cachedlinkinfo:VX|S|show_modclient.php S|show_financial.php S|show_scheduling.php
vti_cachedsvcrellinks:VX|FSUS|Dbase\\ Admin/all_clients/show_modclient.php FSUS|Dbase\\ Admin/all_clients/show_financial.php FSUS|Dbase\\ Admin/all_clients/show_scheduling.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
