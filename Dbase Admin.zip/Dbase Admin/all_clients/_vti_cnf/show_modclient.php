vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 20:51:02 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TW|30 Apr 2006 20:43:08 -0000
vti_timecreated:TR|12 Apr 2006 07:41:43 -0000
vti_title:SR|Modify Clients Record
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/old-show_allclients_main.php Dbase\\ Admin/all_clients/show_scheduling.php Dbase\\ Admin/all_clients/show_single_client.php Dbase\\ Admin/all_clients/show_financial.php
vti_cacheddtm:TX|08 Feb 2007 20:51:02 -0000
vti_filesize:IR|22280
vti_cachedtitle:SR|Modify Clients Record
vti_cachedbodystyle:SR|<body bgcolor="#FFFFFF">
vti_cachedlinkinfo:VX|A|do_modclient.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/all_clients/do_modclient.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
