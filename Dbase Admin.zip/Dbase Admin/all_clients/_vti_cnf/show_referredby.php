vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:55 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TW|25 Apr 2006 21:07:59 -0000
vti_timecreated:TR|12 Apr 2006 07:41:43 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_cacheddtm:TX|08 Feb 2007 19:23:55 -0000
vti_filesize:IR|1145
vti_cachedtitle:SR|New Page 1
vti_cachedbodystyle:SR|<body bgcolor="#FFFFFF">
vti_cachedlinkinfo:VX|A|do_referredby.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/all_clients/do_referredby.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
