vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|08 Feb 2007 19:23:56 -0000
vti_timecreated:TR|30 Apr 2006 20:22:21 -0000
vti_title:SR|New Page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_scheduling.php Dbase\\ Admin/all_clients/show_financial.php
vti_nexttolasttimemodified:TW|30 Apr 2006 20:59:45 -0000
vti_cacheddtm:TX|08 Feb 2007 20:13:45 -0000
vti_filesize:IR|12962
vti_cachedtitle:SR|New Page 1
vti_cachedbodystyle:SR|<body onload="FP_preloadImgs(/*url*/'../../images/buttonA.jpg', /*url*/'../../images/buttonB.jpg', /*url*/'../../images/buttonD.jpg', /*url*/'../../images/buttonE.jpg', /*url*/'../../images/button16.jpg', /*url*/'../../images/button17.jpg', /*url*/'../../images/button20.jpg', /*url*/'../../images/button21.jpg')">
vti_cachedlinkinfo:VX|S|../../images/buttonA.jpg S|../../images/buttonB.jpg S|../../images/buttonD.jpg S|../../images/buttonE.jpg S|../../images/button16.jpg S|../../images/button17.jpg S|../../images/button20.jpg S|../../images/button21.jpg H|show_financial.php S|../../images/buttonA.jpg S|../../images/button9.jpg S|../../images/buttonB.jpg S|../../images/buttonA.jpg S|../../images/button9.jpg H|show_scheduling.php S|../../images/buttonD.jpg S|../../images/buttonC.jpg S|../../images/buttonE.jpg S|../../images/buttonD.jpg S|../../images/buttonC.jpg H|show_modclient.php S|../../images/button16.jpg S|../../images/buttonF.jpg S|../../images/button17.jpg S|../../images/button16.jpg S|../../images/buttonF.jpg H|show_allclients_main.php S|../../images/button20.jpg S|../../images/button22.jpg S|../../images/button21.jpg S|../../images/button20.jpg S|../../images/button22.jpg
vti_cachedsvcrellinks:VX|FSUS|images/buttonA.jpg FSUS|images/buttonB.jpg FSUS|images/buttonD.jpg FSUS|images/buttonE.jpg FSUS|images/button16.jpg FSUS|images/button17.jpg FSUS|images/button20.jpg FSUS|images/button21.jpg FHUS|Dbase\\ Admin/all_clients/show_financial.php FSUS|images/buttonA.jpg FSUS|images/button9.jpg FSUS|images/buttonB.jpg FSUS|images/buttonA.jpg FSUS|images/button9.jpg FHUS|Dbase\\ Admin/all_clients/show_scheduling.php FSUS|images/buttonD.jpg FSUS|images/buttonC.jpg FSUS|images/buttonE.jpg FSUS|images/buttonD.jpg FSUS|images/buttonC.jpg FHUS|Dbase\\ Admin/all_clients/show_modclient.php FSUS|images/button16.jpg FSUS|images/buttonF.jpg FSUS|images/button17.jpg FSUS|images/button16.jpg FSUS|images/buttonF.jpg FHUS|Dbase\\ Admin/all_clients/show_allclients_main.php FSUS|images/button20.jpg FSUS|images/button22.jpg FSUS|images/button21.jpg FSUS|images/button20.jpg FSUS|images/button22.jpg
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252 GENERATOR Microsoft\\ FrontPage\\ 6.0 ProgId FrontPage.Editor.Document
vti_charset:SR|windows-1252
vti_language:SR|en-us
vti_progid:SR|FrontPage.Editor.Document
vti_generator:SR|Microsoft FrontPage 6.0
