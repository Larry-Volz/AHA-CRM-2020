vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Feb 2007 19:23:48 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|04 Oct 2006 06:43:07 -0000
vti_title:SR|Recent AHC Leads
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_all_leads.php Dbase\\ Admin/all_clients/show_paperwork_received.php
vti_nexttolasttimemodified:TW|04 Oct 2006 06:43:07 -0000
vti_cacheddtm:TX|08 Feb 2007 19:23:48 -0000
vti_filesize:IR|7461
vti_cachedtitle:SR|Recent AHC Leads
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|A|show_all_leads.php
vti_cachedsvcrellinks:VX|FAUS|Dbase\\ Admin/all_clients/show_all_leads.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
