vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Aug 2006 13:56:45 -0000
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_nexttolasttimemodified:TW|09 Mar 2006 21:29:02 -0000
vti_timecreated:TR|12 Apr 2006 07:44:00 -0000
vti_cacheddtm:TX|12 Apr 2006 07:44:00 -0000
vti_filesize:IR|9551
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|Dbase\\ Admin/all_clients/show_financial.php
