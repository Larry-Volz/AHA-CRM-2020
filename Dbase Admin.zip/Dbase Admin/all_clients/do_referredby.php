<?
//STRATEGY: Use if block to include a different file depending on the answer
// - if doc or client include a search block for the database to find him quickly
// - if advertising venue, just create an html select box from database to give all current options
// - in any case, include a details box
// - in the case of a person, set up auto e-mailed thank you letter and/or a note + generated letter
// - to be e-mailed to office manager to print out and mail in regular post
// - include an e-mail to Larry to remind him to write a $25 referral check to clients or
//	 possibly a free coupon to docs?

?><html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>

<meta name="Microsoft Border" content="r, default">
</head>

<body><!--msnavigation--><table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%"><tr><!--msnavigation--><td valign="top">

<!--msnavigation--></td><td valign="top" width="24"></td><td valign="top" width="1%">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table></body>

</html>
