<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Contact Log Frame</title>


<meta name="Microsoft Border" content="r, default">
</head>

<body bgcolor="#FFFFFF"><!--msnavigation--><table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%"><tr><!--msnavigation--><td valign="top">
<form method="POST" action="show_contactlog.php" target="_self" enctype="application/x-www-form-urlencoded">
<table border="0" width="48%" id="table1">
	<tr>
		<td>
		<p style="margin-top: 2px; margin-bottom: 2px">
<font face="Arial"><strong style="font-weight: 400"><font size="2">Additional Information:</font></strong><font size="2"><br />
</font><font face="Arial" size="3">
<textarea name="additional_information" cols=41 rows=5 wrap=virtual></textarea></font></font><p style="margin-top: 2px; margin-bottom: 2px; text-align:center">
<font face="Arial" size="3">
<input type="submit" name="submit0" value="Add Contact Log"</p></font><p style="margin-top: 2px; margin-bottom: 2px">
<font face="Arial" size="2">Most Recent Contacts: </font>
<p style="margin-top: 2px; margin-bottom: 2px">
<font face="Arial" size="3">
<textarea name="contact_logs" cols=41 rows=9 wrap=virtual></textarea></font></td>
	</tr>
</table>
<p style="margin-top: 2px; margin-bottom: 2px">
&nbsp;

<!--msnavigation--></td><td valign="top" width="24"></td><td valign="top" width="1%">
<p>&nbsp;</p>

</td></tr><!--msnavigation--></table></body>

</html>
