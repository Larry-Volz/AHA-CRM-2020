<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="Microsoft Border" content="none">
</head>

<body bgcolor="#FFFFFF">
<form method="post" action="do_referredby.php" target="_self">
<p style="margin-top: 2px; margin-bottom: 2px; text-align:center"><font face="Arial">
<font size="2">Referred By: 
</font> 
<i>
<font size="2">
<br>
<br>
<input type="radio" value="Advertising" name="referral_category" checked> Advertising? 
<input type="radio" value="Client" name="referral_category" checked>A Client?&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" value="Physician" checked name="referral_category">A Physician?</font></i></font></p>
<p style="margin-top: 2px; margin-bottom: 2px; text-align:center">
<font size="3" face="Arial">
<br>
<input type="submit" value="Give Details" name="referral_details_button"></font></p>
<p style="margin-top: 2px; margin-bottom: 2px; text-align:center">
&nbsp;

</form>

</body>

</html>
