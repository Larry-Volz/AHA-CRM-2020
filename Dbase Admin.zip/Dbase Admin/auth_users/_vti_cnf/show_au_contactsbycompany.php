vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2006 21:58:59 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timecreated:TR|28 Mar 2006 08:30:00 -0000
vti_backlinkinfo:VX|Dbase\\ Admin/auth_users/members_menu.php Dbase\\ Admin/auth_users/members_menu2.htm Dbase\\ Admin/auth_users/Copy\\ of\\ members_menu.php
vti_nexttolasttimemodified:TR|28 Mar 2006 08:30:00 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:47 -0000
vti_filesize:IR|437
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_charset:SR|windows-1252
