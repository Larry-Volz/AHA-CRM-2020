vti_encoding:SR|utf8-nl
vti_author:SR|ZAPHOD\\Larry Volz
vti_modifiedby:SR|ZAPHOD\\Larry Volz
vti_timelastmodified:TR|24 Apr 2006 22:03:54 -0000
vti_timecreated:TR|28 Mar 2006 08:18:23 -0000
vti_title:SR|American Hypnosis Clinic Members: Main Menu
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|_borders/left.php _borders/old-half-wrecked-left.php
vti_nexttolasttimemodified:TR|18 Apr 2006 18:56:48 -0000
vti_cacheddtm:TX|25 Apr 2006 21:21:46 -0000
vti_filesize:IR|6228
vti_cachedtitle:SR|American Hypnosis Clinic Members: Main Menu
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|H|show_au_addcontact.php H|pick_au_modcontact.php H|pick_au_delcontact.php H|show_au_contactsbyname.php H|show_au_contactsbycompany.php
vti_cachedsvcrellinks:VX|FHUS|Dbase\\ Admin/auth_users/show_au_addcontact.php FHUS|Dbase\\ Admin/auth_users/pick_au_modcontact.php FHUS|Dbase\\ Admin/auth_users/pick_au_delcontact.php FHUS|Dbase\\ Admin/auth_users/show_au_contactsbyname.php FHUS|Dbase\\ Admin/auth_users/show_au_contactsbycompany.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|true
vti_borderaggregate:SR|default
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
