<?php
# updated via install/index.php on Sun, 24 Sep 2006 13:17:01 -0700
db_type: mysql
db_host: mysql.secureserver.net
db_database: AHC_calendar
db_login: AHC_calendar
db_password: Zachary727
db_persistent: true
single_user_login: 
readonly: false
use_http_auth: false
single_user: false
user_inc: user.php
# end settings.php
?>
<?php
install_password: 36d39bb69afdbcbb54bdc24f601e1cfe
?>
